"""
Main Window Module v3.0
Главное окно приложения Threads Automation Bot.
"""

import sys
import asyncio
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from loguru import logger

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
    QLabel, QLineEdit, QTextEdit, QComboBox, QSpinBox,
    QGroupBox, QFormLayout, QMessageBox, QFileDialog,
    QHeaderView, QMenu, QSystemTrayIcon, QStyle,
    QProgressBar, QCheckBox, QDialog, QDialogButtonBox,
    QListWidget, QListWidgetItem, QSplitter, QFrame,
    QScrollArea, QGridLayout, QTimeEdit, QInputDialog,
    QPlainTextEdit, QStatusBar
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QTime, QSettings, QSize
from PyQt6.QtGui import QAction, QIcon, QFont, QColor, QPalette

# Добавляем родительский путь
sys.path.insert(0, str(Path(__file__).parent.parent))

from core import (
    get_account_manager,
    get_openrouter_client,
    get_proxy_checker,
    get_profile_manager,
    get_global_registry,
    get_scheduler,
    ProxyConfig,
    Account,
    ProxyType,
    TaskType,
)


# =============================================================================
# Рабочие потоки
# =============================================================================

class ProxyCheckThread(QThread):
    """Поток для проверки прокси в фоне."""
    finished = pyqtSignal(dict)
    
    def __init__(self, proxy_config):
        super().__init__()
        self.proxy_config = proxy_config
    
    def run(self):
        try:
            async def run_check():
                checker = get_proxy_checker()
                return await checker.test_proxy(self.proxy_config)
            
            result = asyncio.run(run_check())
            self.finished.emit(result.to_dict())
        except Exception as e:
            logger.exception("Ошибка в потоке проверки прокси")
            self.finished.emit({
                "success": False,
                "error_message": str(e)
            })


class GenerateContentThread(QThread):
    """Поток для генерации контента."""
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    
    def __init__(self, client, profile, topic):
        super().__init__()
        self.client = client
        self.profile = profile
        self.topic = topic
    
    def run(self):
        try:
            async def run_generate():
                return await self.client.generate_post(self.profile, self.topic)
            
            result = asyncio.run(run_generate())
            if result.success:
                self.finished.emit(result.content)
            else:
                self.error.emit(result.error or "Неизвестная ошибка")
        except Exception as e:
            self.error.emit(str(e))


class PostThread(QThread):
    """Поток для публикации поста."""
    finished = pyqtSignal(bool, str, str)
    progress = pyqtSignal(str)
    
    def __init__(self, account, content, api_key):
        super().__init__()
        self.account = account
        self.content = content
        self.api_key = api_key
    
    def run(self):
        try:
            async def run_post():
                from core.engines.uc_engine import UCEngine, BrowserConfig
                from core.poster import Poster
                
                self.progress.emit("Запуск браузера...")
                config = BrowserConfig(
                    proxy=self.account.proxy.to_url() if self.account.proxy else None,
                    language="ru-RU"
                )
                engine = UCEngine(config)
                
                if not engine.start():
                    return (False, "Не удалось запустить браузер", "")
                
                self.progress.emit("Публикация поста...")
                ai_client = get_openrouter_client(self.api_key) if self.api_key else None
                poster = Poster(
                    account=self.account,
                    engine=engine,
                    ai_client=ai_client
                )
                
                result = await poster.create_post(self.content)
                engine.stop()
                
                if result.success:
                    return (True, "Пост успешно опубликован!", result.post_url or "")
                else:
                    return (False, result.error_message or "Неизвестная ошибка", "")
            
            success, message, url = asyncio.run(run_post())
            self.finished.emit(success, message, url)
        except Exception as e:
            logger.exception("Ошибка публикации")
            self.finished.emit(False, f"Ошибка: {str(e)}", "")


class CommentCycleThread(QThread):
    """Поток для цикла комментирования."""
    finished = pyqtSignal(list)
    progress = pyqtSignal(str)
    
    def __init__(self, account, keywords, max_comments, api_key):
        super().__init__()
        self.account = account
        self.keywords = keywords
        self.max_comments = max_comments
        self.api_key = api_key
    
    def run(self):
        try:
            async def run_comment():
                from core.engines.uc_engine import UCEngine, BrowserConfig
                from core.commenter import Commenter
                
                self.progress.emit("Запуск браузера...")
                config = BrowserConfig(
                    proxy=self.account.proxy.to_url() if self.account.proxy else None,
                    language="ru-RU"
                )
                engine = UCEngine(config)
                
                if not engine.start():
                    return [{"success": False, "error": "Не удалось запустить браузер"}]
                
                self.progress.emit("Запуск цикла комментирования...")
                ai_client = get_openrouter_client(self.api_key) if self.api_key else None
                commenter = Commenter(
                    account=self.account,
                    engine=engine,
                    ai_client=ai_client
                )
                
                results = await commenter.run_comment_cycle(self.keywords, self.max_comments)
                engine.stop()
                
                return [
                    {
                        "success": r.success,
                        "post_id": r.post_id,
                        "comment_text": r.comment_text,
                        "error": r.error_message
                    }
                    for r in results
                ]
            
            results = asyncio.run(run_comment())
            self.finished.emit(results)
        except Exception as e:
            logger.exception("Ошибка комментирования")
            self.finished.emit([{"success": False, "error": str(e)}])


# =============================================================================
# Диалоги
# =============================================================================

class AddAccountDialog(QDialog):
    """Диалог добавления/редактирования аккаунта."""
    
    def __init__(self, account: Optional[Account] = None, parent=None):
        super().__init__(parent)
        self.account = account
        self.setWindowTitle("Редактирование аккаунта" if account else "Добавление аккаунта")
        self.setMinimumWidth(500)
        self.setup_ui()
        
        if account:
            self.load_account_data()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Основная информация
        form = QFormLayout()
        
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("username")
        form.addRow("Имя пользователя:", self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Пароль:", self.password_input)
        
        # Контентный профиль
        self.profile_combo = QComboBox()
        profile_manager = get_profile_manager()
        for key, name in profile_manager.get_profile_names().items():
            self.profile_combo.addItem(name, key)
        form.addRow("Контентный профиль:", self.profile_combo)
        
        layout.addLayout(form)
        
        # Настройки прокси
        proxy_group = QGroupBox("Настройки прокси (опционально)")
        proxy_layout = QFormLayout()
        
        self.proxy_host = QLineEdit()
        self.proxy_host.setPlaceholderText("proxy.example.com")
        proxy_layout.addRow("Хост:", self.proxy_host)
        
        self.proxy_port = QSpinBox()
        self.proxy_port.setRange(1, 65535)
        self.proxy_port.setValue(8080)
        proxy_layout.addRow("Порт:", self.proxy_port)
        
        self.proxy_user = QLineEdit()
        proxy_layout.addRow("Пользователь:", self.proxy_user)
        
        self.proxy_pass = QLineEdit()
        self.proxy_pass.setEchoMode(QLineEdit.EchoMode.Password)
        proxy_layout.addRow("Пароль:", self.proxy_pass)
        
        self.proxy_type = QComboBox()
        self.proxy_type.addItems(["http", "https", "socks4", "socks5"])
        proxy_layout.addRow("Протокол:", self.proxy_type)
        
        # Кнопка проверки прокси
        self.check_proxy_btn = QPushButton("Проверить прокси")
        self.check_proxy_btn.clicked.connect(self.check_proxy)
        proxy_layout.addRow(self.check_proxy_btn)
        
        self.proxy_status_label = QLabel("Статус: не проверено")
        proxy_layout.addRow(self.proxy_status_label)
        
        proxy_group.setLayout(proxy_layout)
        layout.addWidget(proxy_group)
        
        # Заметки
        self.notes_input = QTextEdit()
        self.notes_input.setMaximumHeight(80)
        self.notes_input.setPlaceholderText("Заметки о персоне для AI генерации...")
        layout.addWidget(QLabel("Заметки:"))
        layout.addWidget(self.notes_input)
        
        # Кнопки
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def load_account_data(self):
        """Загрузка данных существующего аккаунта."""
        self.username_input.setText(self.account.username)
        self.password_input.setText(self.account.password)
        self.notes_input.setPlainText(self.account.notes or "")
        
        # Установка профиля
        profile_index = self.profile_combo.findData(self.account.content_profile)
        if profile_index >= 0:
            self.profile_combo.setCurrentIndex(profile_index)
        
        if self.account.proxy:
            self.proxy_host.setText(self.account.proxy.host or "")
            self.proxy_port.setValue(self.account.proxy.port or 8080)
            self.proxy_user.setText(self.account.proxy.username or "")
            self.proxy_pass.setText(self.account.proxy.password or "")
            self.proxy_type.setCurrentText(self.account.proxy.protocol or "http")
    
    def check_proxy(self):
        """Проверка конфигурации прокси."""
        if not self.proxy_host.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите хост прокси")
            return
        
        proxy = ProxyConfig(
            host=self.proxy_host.text().strip(),
            port=self.proxy_port.value(),
            username=self.proxy_user.text().strip() or None,
            password=self.proxy_pass.text().strip() or None,
            protocol=self.proxy_type.currentText()
        )
        
        self.proxy_status_label.setText("Статус: проверка...")
        self.check_proxy_btn.setEnabled(False)
        
        self.check_thread = ProxyCheckThread(proxy)
        self.check_thread.finished.connect(self._on_proxy_check_finished)
        self.check_thread.start()
    
    def _on_proxy_check_finished(self, result: dict):
        """Обработка результата проверки прокси."""
        self.check_proxy_btn.setEnabled(True)
        
        if result.get("success"):
            country = result.get("country", "Неизвестно")
            city = result.get("city", "")
            ip = result.get("external_ip", "N/A")
            proxy_type = result.get("proxy_type", "unknown")
            warning = result.get("proxy_type_warning", False)
            
            status_text = f"✅ OK - {city}, {country} ({ip})"
            if warning:
                status_text += f"\n⚠️ Тип прокси: {proxy_type} (не рекомендуется для Threads)"
            else:
                status_text += f"\n✅ Тип прокси: {proxy_type}"
            
            self.proxy_status_label.setStyleSheet("color: green;")
        else:
            status_text = f"❌ Ошибка - {result.get('error_message', 'Неизвестная ошибка')}"
            self.proxy_status_label.setStyleSheet("color: red;")
        
        self.proxy_status_label.setText(f"Статус: {status_text}")
    
    def save(self):
        """Сохранение аккаунта."""
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()
        
        if not username or not password:
            QMessageBox.warning(self, "Ошибка", "Имя пользователя и пароль обязательны")
            return
        
        proxy = None
        if self.proxy_host.text().strip():
            proxy = ProxyConfig(
                host=self.proxy_host.text().strip(),
                port=self.proxy_port.value(),
                username=self.proxy_user.text().strip() or None,
                password=self.proxy_pass.text().strip() or None,
                protocol=self.proxy_type.currentText()
            )
        
        notes = self.notes_input.toPlainText().strip()
        content_profile = self.profile_combo.currentData()
        
        account_manager = get_account_manager()
        
        if self.account:
            account_manager.update_account(
                self.account.id,
                username=username,
                password=password,
                proxy=proxy,
                notes=notes,
                content_profile=content_profile
            )
        else:
            account = Account(
                id=0,
                username=username,
                password=password,
                proxy=proxy,
                notes=notes,
                content_profile=content_profile,
                is_active=True
            )
            account_manager.add_account(account)
        
        self.accept()


# =============================================================================
# Вкладки
# =============================================================================

class AccountsTab(QWidget):
    """Вкладка управления аккаунтами."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.proxy_status: Dict[int, dict] = {}
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Панель инструментов
        toolbar = QHBoxLayout()
        
        self.add_btn = QPushButton("➕ Добавить аккаунт")
        self.add_btn.clicked.connect(self.add_account)
        toolbar.addWidget(self.add_btn)
        
        self.refresh_btn = QPushButton("🔄 Обновить")
        self.refresh_btn.clicked.connect(self.refresh)
        toolbar.addWidget(self.refresh_btn)
        
        self.check_all_btn = QPushButton("🔍 Проверить все прокси")
        self.check_all_btn.clicked.connect(self.check_all_proxies)
        toolbar.addWidget(self.check_all_btn)
        
        toolbar.addStretch()
        
        layout.addLayout(toolbar)
        
        # Таблица аккаунтов
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "ID", "Имя пользователя", "Профиль", "Прокси", "Статус прокси", "Статус сессии", "Активен", "Действия"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        layout.addWidget(self.table)
        
        # Загрузка данных
        self.refresh()
    
    def refresh(self):
        """Обновление списка аккаунтов."""
        account_manager = get_account_manager()
        accounts = account_manager.get_all_accounts()
        
        self.table.setRowCount(len(accounts))
        
        profile_manager = get_profile_manager()
        
        for row, account in enumerate(accounts):
            # ID
            self.table.setItem(row, 0, QTableWidgetItem(str(account.id)))
            
            # Имя пользователя
            self.table.setItem(row, 1, QTableWidgetItem(account.username))
            
            # Профиль
            profile = profile_manager.get_profile(account.content_profile)
            profile_name = profile.name if profile else account.content_profile
            self.table.setItem(row, 2, QTableWidgetItem(profile_name))
            
            # Прокси
            proxy_text = "Нет"
            if account.proxy:
                proxy_text = f"{account.proxy.protocol}://{account.proxy.host}:{account.proxy.port}"
            self.table.setItem(row, 3, QTableWidgetItem(proxy_text))
            
            # Статус прокси
            status_item = QTableWidgetItem()
            if account.id in self.proxy_status:
                status = self.proxy_status[account.id]
                if status.get("success"):
                    status_item.setText("✅ " + (status.get("country") or "OK"))
                    status_item.setForeground(QColor("green"))
                else:
                    status_item.setText("❌ Ошибка")
                    status_item.setForeground(QColor("red"))
            else:
                status_item.setText("⏳ Не проверено")
            self.table.setItem(row, 4, status_item)
            
            # Статус сессии
            session_item = QTableWidgetItem()
            if account.session_valid:
                session_item.setText("✅ Активна")
                session_item.setForeground(QColor("green"))
            elif account_manager.has_valid_cookies(account.id):
                session_item.setText("🍪 Есть cookies")
                session_item.setForeground(QColor("orange"))
            else:
                session_item.setText("❌ Нет сессии")
                session_item.setForeground(QColor("red"))
            self.table.setItem(row, 5, session_item)
            
            # Активен
            active_item = QTableWidgetItem("Да" if account.is_active else "Нет")
            active_item.setForeground(QColor("green") if account.is_active else QColor("red"))
            self.table.setItem(row, 6, active_item)
            
            # Кнопки действий
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(2, 2, 2, 2)
            
            edit_btn = QPushButton("Изменить")
            edit_btn.setMaximumWidth(70)
            edit_btn.clicked.connect(lambda checked, a=account.id: self.edit_account(a))
            actions_layout.addWidget(edit_btn)
            
            check_btn = QPushButton("Проверить")
            check_btn.setMaximumWidth(70)
            check_btn.clicked.connect(lambda checked, a=account.id: self.check_proxy(a))
            actions_layout.addWidget(check_btn)
            
            # Новая кнопка удаления
            delete_btn = QPushButton("Удалить")
            delete_btn.setMaximumWidth(70)
            delete_btn.clicked.connect(lambda checked, a=account.id: self.delete_account_by_id(a))
            actions_layout.addWidget(delete_btn)
            
            self.table.setCellWidget(row, 7, actions_widget)
    
    def delete_account_by_id(self, account_id: int):
        """Удаление аккаунта по ID (для кнопки)."""
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        if account:
            self.delete_account(account)
    
    def add_account(self):
        """Добавление нового аккаунта."""
        dialog = AddAccountDialog(parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh()
    
    def edit_account(self, account_id: int):
        """Редактирование аккаунта."""
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        if account:
            dialog = AddAccountDialog(account=account, parent=self)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                self.refresh()
    
    def check_proxy(self, account_id: int):
        """Проверка прокси для аккаунта."""
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        
        if not account or not account.proxy:
            QMessageBox.information(self, "Информация", "Прокси не настроен для этого аккаунта")
            return
        
        self.proxy_status[account_id] = {"success": False, "checking": True}
        self.refresh()
        
        self.check_thread = ProxyCheckThread(account.proxy)
        self.check_thread.finished.connect(lambda result: self._on_proxy_check_finished(account_id, result))
        self.check_thread.start()
    
    def _on_proxy_check_finished(self, account_id: int, result: dict):
        """Обработка результата проверки прокси."""
        self.proxy_status[account_id] = result
        self.refresh()
        
        if result.get("success"):
            msg = f"Прокси работает!\nIP: {result.get('external_ip')}\nМестоположение: {result.get('city')}, {result.get('country')}\nТип: {result.get('proxy_type')}"
            if result.get("proxy_type_warning"):
                msg += "\n\n⚠️ Предупреждение: дата-центровые прокси не рекомендуются для работы с Threads!"
            QMessageBox.information(self, "Проверка прокси", msg)
        else:
            QMessageBox.warning(self, "Ошибка прокси", result.get('error_message', 'Неизвестная ошибка'))
    
    def check_all_proxies(self):
        """Проверка всех прокси."""
        account_manager = get_account_manager()
        accounts = account_manager.get_all_accounts()
        
        for account in accounts:
            if account.proxy:
                self.check_proxy(account.id)
    
    def show_context_menu(self, position):
        """Контекстное меню для строки аккаунта."""
        row = self.table.rowAt(position.y())
        if row < 0:
            return
        
        account_id = int(self.table.item(row, 0).text())
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        
        if not account:
            return
        
        menu = QMenu(self)
        
        edit_action = QAction("Изменить", self)
        edit_action.triggered.connect(lambda: self.edit_account(account_id))
        menu.addAction(edit_action)
        
        toggle_action = QAction(
            "Деактивировать" if account.is_active else "Активировать", self
        )
        toggle_action.triggered.connect(lambda: self.toggle_account(account))
        menu.addAction(toggle_action)
        
        menu.addSeparator()
        
        check_proxy_action = QAction("Проверить прокси", self)
        check_proxy_action.triggered.connect(lambda: self.check_proxy(account_id))
        menu.addAction(check_proxy_action)
        
        menu.addSeparator()
        
        delete_action = QAction("Удалить", self)
        delete_action.triggered.connect(lambda: self.delete_account(account))
        menu.addAction(delete_action)
        
        menu.exec(self.table.mapToGlobal(position))
    
    def toggle_account(self, account: Account):
        """Переключение статуса активности аккаунта."""
        account_manager = get_account_manager()
        account_manager.update_account(account.id, is_active=not account.is_active)
        self.refresh()
    
    def delete_account(self, account: Account):
        """Удаление аккаунта."""
        reply = QMessageBox.question(
            self,
            "Подтверждение удаления",
            f"Удалить аккаунт '{account.username}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            account_manager = get_account_manager()
            account_manager.delete_account(account.id)
            self.refresh()


class PostingTab(QWidget):
    """Вкладка публикации постов."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.generate_thread = None
        self.post_thread = None
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # Левая панель - настройки
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        
        form = QFormLayout()
        
        self.account_combo = QComboBox()
        self.load_accounts()
        self.account_combo.currentIndexChanged.connect(self.on_account_changed)
        form.addRow("Аккаунт:", self.account_combo)
        
        self.profile_combo = QComboBox()
        self.load_profiles()
        form.addRow("Профиль контента:", self.profile_combo)
        
        self.topic_input = QLineEdit()
        self.topic_input.setPlaceholderText("Введите тему поста...")
        form.addRow("Тема:", self.topic_input)
        
        left_layout.addLayout(form)
        
        # Кнопки действий
        buttons = QHBoxLayout()
        
        self.generate_btn = QPushButton("✨ Сгенерировать контент")
        self.generate_btn.clicked.connect(self.generate_content)
        buttons.addWidget(self.generate_btn)
        
        self.post_btn = QPushButton("📤 Опубликовать в Threads")
        self.post_btn.clicked.connect(self.post_content)
        self.post_btn.setEnabled(False)
        buttons.addWidget(self.post_btn)
        
        left_layout.addLayout(buttons)
        
        # Настройки расписания
        schedule_group = QGroupBox("Настройки расписания")
        schedule_layout = QFormLayout()
        
        self.schedule_enabled = QCheckBox("Включить публикацию по расписанию")
        schedule_layout.addRow(self.schedule_enabled)
        
        self.post_times = QLineEdit()
        self.post_times.setText("10:00, 15:00, 20:00")
        self.post_times.setPlaceholderText("Время через запятую (например, 10:00, 15:00)")
        schedule_layout.addRow("Время публикации:", self.post_times)
        
        schedule_group.setLayout(schedule_layout)
        left_layout.addWidget(schedule_group)
        
        # Кнопка сохранения расписания
        self.save_schedule_btn = QPushButton("💾 Сохранить расписание")
        self.save_schedule_btn.clicked.connect(self.save_schedule)
        left_layout.addWidget(self.save_schedule_btn)
        
        left_layout.addStretch()
        splitter.addWidget(left_panel)
        
        # Правая панель - предпросмотр
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        right_layout.addWidget(QLabel("Предпросмотр контента:"))
        
        self.content_preview = QTextEdit()
        self.content_preview.setReadOnly(False)
        self.content_preview.setPlaceholderText("Нажмите 'Сгенерировать контент' для создания поста...")
        self.content_preview.setMinimumHeight(200)
        right_layout.addWidget(self.content_preview)
        
        self.char_count = QLabel("0 / 500 символов")
        right_layout.addWidget(self.char_count)
        
        self.content_preview.textChanged.connect(self.update_char_count)
        
        splitter.addWidget(right_panel)
        splitter.setSizes([350, 450])
        
        layout.addWidget(splitter)
        
        # Прогресс
        self.progress_label = QLabel("")
        layout.addWidget(self.progress_label)
    
    def load_accounts(self):
        """Загрузка списка аккаунтов."""
        account_manager = get_account_manager()
        accounts = account_manager.get_active_accounts()
        self.account_combo.clear()
        for account in accounts:
            self.account_combo.addItem(
                f"{account.username} (ID: {account.id})",
                account.id
            )
    
    def load_profiles(self):
        """Загрузка списка профилей."""
        profile_manager = get_profile_manager()
        self.profile_combo.clear()
        for key, name in profile_manager.get_profile_names().items():
            self.profile_combo.addItem(name, key)
    
    def on_account_changed(self):
        """Обработка смены аккаунта."""
        account_id = self.account_combo.currentData()
        if account_id:
            account_manager = get_account_manager()
            account = account_manager.get_account(account_id)
            if account:
                # Устанавливаем профиль аккаунта
                profile_index = self.profile_combo.findData(account.content_profile)
                if profile_index >= 0:
                    self.profile_combo.setCurrentIndex(profile_index)
    
    def refresh_accounts(self):
        """Обновление списка аккаунтов (вызывается при переключении на вкладку)."""
        self.load_accounts()
        self.on_account_changed()
    
    def generate_content(self):
        """Генерация контента."""
        topic = self.topic_input.text().strip()
        if not topic:
            QMessageBox.warning(self, "Ошибка", "Введите тему")
            return
        
        settings = QSettings("ThreadsBot", "Settings")
        api_key = settings.value("openrouter_key", "")
        if not api_key:
            QMessageBox.warning(
                self,
                "Отсутствует API ключ",
                "Ключ OpenRouter не настроен. Добавьте его во вкладке Настройки."
            )
            return
        
        profile_id = self.profile_combo.currentData()
        profile_manager = get_profile_manager()
        profile = profile_manager.get_profile(profile_id)
        
        if not profile:
            QMessageBox.critical(self, "Ошибка", "Профиль не найден")
            return
        
        client = get_openrouter_client(api_key)
        if not client:
            QMessageBox.critical(self, "Ошибка", "Не удалось инициализировать OpenRouter клиент")
            return
        
        self.generate_btn.setEnabled(False)
        self.generate_btn.setText("⏳ Генерация...")
        
        self.generate_thread = GenerateContentThread(client, profile, topic)
        self.generate_thread.finished.connect(self._on_generation_finished)
        self.generate_thread.error.connect(self._on_generation_error)
        self.generate_thread.start()
    
    def _on_generation_finished(self, content):
        """Обработка успешной генерации."""
        self.content_preview.setText(content)
        self.post_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)
        self.generate_btn.setText("✨ Сгенерировать контент")
        self.update_char_count()
    
    def _on_generation_error(self, error_message):
        """Обработка ошибки генерации."""
        QMessageBox.critical(self, "Ошибка генерации", f"Ошибка: {error_message}")
        self.generate_btn.setEnabled(True)
        self.generate_btn.setText("✨ Сгенерировать контент")
    
    def post_content(self):
        """Публикация контента."""
        content = self.content_preview.toPlainText().strip()
        if not content:
            QMessageBox.warning(self, "Ошибка", "Нет контента для публикации")
            return
        
        account_id = self.account_combo.currentData()
        account_name = self.account_combo.currentText()
        
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        if not account:
            QMessageBox.critical(self, "Ошибка", "Аккаунт не найден")
            return
        
        reply = QMessageBox.question(
            self,
            "Подтверждение публикации",
            f"Опубликовать этот контент от имени {account_name}?\n\n{content[:100]}...",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        
        settings = QSettings("ThreadsBot", "Settings")
        api_key = settings.value("openrouter_key", "")
        
        self.post_btn.setEnabled(False)
        self.post_btn.setText("⏳ Публикация...")
        self.generate_btn.setEnabled(False)
        self.progress_label.setText("Инициализация...")
        
        self.post_thread = PostThread(account, content, api_key)
        self.post_thread.finished.connect(self._on_post_finished)
        self.post_thread.progress.connect(self._on_post_progress)
        self.post_thread.start()
    
    def _on_post_progress(self, message):
        """Обновление прогресса публикации."""
        self.progress_label.setText(message)
    
    def _on_post_finished(self, success, message, url):
        """Обработка завершения публикации."""
        self.post_btn.setEnabled(True)
        self.post_btn.setText("📤 Опубликовать в Threads")
        self.generate_btn.setEnabled(True)
        self.progress_label.setText("")
        
        if success:
            QMessageBox.information(self, "Успех", f"{message}\nURL: {url}")
            self.content_preview.clear()
            self.post_btn.setEnabled(False)
        else:
            QMessageBox.critical(self, "Ошибка", f"Ошибка публикации: {message}")
    
    def save_schedule(self):
        """Сохранение расписания."""
        account_id = self.account_combo.currentData()
        if not account_id:
            QMessageBox.warning(self, "Ошибка", "Выберите аккаунт")
            return
        
        from core.scheduler import ScheduleConfig
        
        config = ScheduleConfig(
            post_times=[t.strip() for t in self.post_times.text().split(",")],
            post_topic=self.topic_input.text().strip(),
            post_enabled=self.schedule_enabled.isChecked()
        )
        
        scheduler = get_scheduler()
        scheduler.setup_schedule(account_id, config)
        
        if self.schedule_enabled.isChecked():
            QMessageBox.information(
                self,
                "Расписание сохранено",
                f"Публикация запланирована на: {', '.join(config.post_times)}"
            )
        else:
            QMessageBox.information(self, "Расписание сохранено", "Публикация по расписанию отключена")
    
    def update_char_count(self):
        """Обновление счетчика символов."""
        text = self.content_preview.toPlainText() or ""
        count = len(text)
        self.char_count.setText(f"{count} / 500 символов")


class CommentingTab(QWidget):
    """Вкладка комментирования."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.comment_thread = None
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Источники поиска
        sources_group = QGroupBox("Источники поиска")
        sources_layout = QFormLayout()
        
        self.account_combo = QComboBox()
        self.load_accounts()
        sources_layout.addRow("Аккаунт:", self.account_combo)
        
        self.keywords_input = QLineEdit()
        self.keywords_input.setPlaceholderText("Ключевые слова через запятую")
        sources_layout.addRow("Ключевые слова:", self.keywords_input)
        
        sources_group.setLayout(sources_layout)
        layout.addWidget(sources_group)
        
        # Фильтры
        filters_group = QGroupBox("Фильтры")
        filters_layout = QFormLayout()
        
        self.min_likes = QSpinBox()
        self.min_likes.setRange(0, 10000)
        self.min_likes.setValue(10)
        filters_layout.addRow("Мин. лайков:", self.min_likes)
        
        self.max_age = QSpinBox()
        self.max_age.setRange(1, 168)
        self.max_age.setValue(72)
        self.max_age.setSuffix(" часов")
        filters_layout.addRow("Макс. возраст поста:", self.max_age)
        
        filters_group.setLayout(filters_layout)
        layout.addWidget(filters_group)
        
        # Лимиты
        limits_group = QGroupBox("Лимиты")
        limits_layout = QFormLayout()
        
        self.max_comments = QSpinBox()
        self.max_comments.setRange(1, 50)
        self.max_comments.setValue(5)
        limits_layout.addRow("Макс. за цикл:", self.max_comments)
        
        limits_group.setLayout(limits_layout)
        layout.addWidget(limits_group)
        
        # Расписание
        schedule_group = QGroupBox("Расписание")
        schedule_layout = QFormLayout()
        
        self.schedule_enabled = QCheckBox("Включить автоматическое комментирование")
        schedule_layout.addRow(self.schedule_enabled)
        
        self.interval_hours = QSpinBox()
        self.interval_hours.setRange(1, 24)
        self.interval_hours.setValue(3)
        self.interval_hours.setSuffix(" часов")
        schedule_layout.addRow("Интервал:", self.interval_hours)
        
        schedule_group.setLayout(schedule_layout)
        layout.addWidget(schedule_group)
        
        # Кнопки
        self.run_btn = QPushButton("▶️ Запустить цикл комментирования")
        self.run_btn.clicked.connect(self.run_cycle)
        layout.addWidget(self.run_btn)
        
        self.save_schedule_btn = QPushButton("💾 Сохранить расписание")
        self.save_schedule_btn.clicked.connect(self.save_schedule)
        layout.addWidget(self.save_schedule_btn)
        
        # Прогресс
        self.progress_label = QLabel("")
        layout.addWidget(self.progress_label)
        
        # Результаты
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setPlaceholderText("Результаты комментирования будут отображены здесь...")
        self.results_text.setMaximumHeight(150)
        layout.addWidget(self.results_text)
        
        layout.addStretch()
    
    def load_accounts(self):
        """Загрузка списка аккаунтов."""
        account_manager = get_account_manager()
        accounts = account_manager.get_active_accounts()
        self.account_combo.clear()
        for account in accounts:
            self.account_combo.addItem(
                f"{account.username} (ID: {account.id})",
                account.id
            )
    
    def refresh_accounts(self):
        """Обновление списка аккаунтов."""
        self.load_accounts()
    
    def run_cycle(self):
        """Запуск цикла комментирования."""
        account_id = self.account_combo.currentData()
        if not account_id:
            QMessageBox.warning(self, "Ошибка", "Выберите аккаунт")
            return
        
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        if not account:
            QMessageBox.critical(self, "Ошибка", "Аккаунт не найден")
            return
        
        # Получаем ключевые слова
        keywords_text = self.keywords_input.text().strip()
        if keywords_text:
            keywords = [k.strip() for k in keywords_text.split(",")]
        else:
            # Используем ключевые слова из профиля
            profile_manager = get_profile_manager()
            profile = profile_manager.get_profile(account.content_profile)
            keywords = profile.keywords if profile else []
        
        if not keywords:
            QMessageBox.warning(self, "Ошибка", "Укажите ключевые слова")
            return
        
        settings = QSettings("ThreadsBot", "Settings")
        api_key = settings.value("openrouter_key", "")
        
        self.run_btn.setEnabled(False)
        self.run_btn.setText("⏳ Выполнение...")
        self.progress_label.setText("Запуск браузера...")
        self.results_text.clear()
        
        self.comment_thread = CommentCycleThread(
            account,
            keywords,
            self.max_comments.value(),
            api_key
        )
        self.comment_thread.finished.connect(self._on_cycle_finished)
        self.comment_thread.progress.connect(self._on_cycle_progress)
        self.comment_thread.start()
    
    def _on_cycle_progress(self, message):
        """Обновление прогресса."""
        self.progress_label.setText(message)
    
    def _on_cycle_finished(self, results):
        """Обработка завершения цикла."""
        self.run_btn.setEnabled(True)
        self.run_btn.setText("▶️ Запустить цикл комментирования")
        self.progress_label.setText("")
        
        success_count = sum(1 for r in results if r.get("success"))
        fail_count = len(results) - success_count
        
        result_text = f"Результаты:\n"
        result_text += f"✅ Успешно: {success_count}\n"
        result_text += f"❌ Ошибок: {fail_count}\n\n"
        
        for i, result in enumerate(results, 1):
            if result.get("success"):
                result_text += f"{i}. ✅ Пост {result.get('post_id', 'N/A')}: {result.get('comment_text', '')[:50]}...\n"
            else:
                result_text += f"{i}. ❌ Ошибка: {result.get('error', 'Неизвестная ошибка')}\n"
        
        self.results_text.setText(result_text)
        
        QMessageBox.information(
            self,
            "Цикл завершен",
            f"Цикл комментирования завершен.\nУспешно: {success_count}, Ошибок: {fail_count}"
        )
    
    def save_schedule(self):
        """Сохранение расписания комментирования."""
        account_id = self.account_combo.currentData()
        if not account_id:
            QMessageBox.warning(self, "Ошибка", "Выберите аккаунт")
            return
        
        from core.scheduler import ScheduleConfig
        
        config = ScheduleConfig(
            comment_interval_hours=self.interval_hours.value(),
            comment_enabled=self.schedule_enabled.isChecked()
        )
        
        scheduler = get_scheduler()
        scheduler.setup_schedule(account_id, config)
        
        if self.schedule_enabled.isChecked():
            QMessageBox.information(
                self,
                "Расписание сохранено",
                f"Комментирование запланировано каждые {config.comment_interval_hours} часа"
            )
        else:
            QMessageBox.information(self, "Расписание сохранено", "Автоматическое комментирование отключено")


class ContentProfilesTab(QWidget):
    """Вкладка управления контентными профилями."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Выбор профиля
        profile_layout = QHBoxLayout()
        profile_layout.addWidget(QLabel("Редактируемый профиль:"))
        
        self.profile_combo = QComboBox()
        self.load_profiles()
        self.profile_combo.currentIndexChanged.connect(self.on_profile_changed)
        profile_layout.addWidget(self.profile_combo)
        
        profile_layout.addStretch()
        layout.addLayout(profile_layout)
        
        # Поля редактирования
        self.system_prompt = QTextEdit()
        self.system_prompt.setPlaceholderText("System Prompt...")
        self.system_prompt.setMaximumHeight(150)
        layout.addWidget(QLabel("System Prompt:"))
        layout.addWidget(self.system_prompt)
        
        self.post_template = QTextEdit()
        self.post_template.setPlaceholderText("Post Prompt Template (используйте {topic} для подстановки темы)...")
        self.post_template.setMaximumHeight(100)
        layout.addWidget(QLabel("Post Prompt Template:"))
        layout.addWidget(self.post_template)
        
        self.comment_template = QTextEdit()
        self.comment_template.setPlaceholderText("Comment Prompt Template (используйте {post_content} для подстановки текста поста)...")
        self.comment_template.setMaximumHeight(100)
        layout.addWidget(QLabel("Comment Prompt Template:"))
        layout.addWidget(self.comment_template)
        
        # Ключевые слова
        self.keywords_input = QLineEdit()
        self.keywords_input.setPlaceholderText("Ключевые слова через запятую...")
        layout.addWidget(QLabel("Ключевые слова:"))
        layout.addWidget(self.keywords_input)
        
        # Кнопки
        buttons = QHBoxLayout()
        
        self.save_btn = QPushButton("💾 Сохранить профиль")
        self.save_btn.clicked.connect(self.save_profile)
        buttons.addWidget(self.save_btn)
        
        self.reset_btn = QPushButton("🔄 Сбросить к значениям по умолчанию")
        self.reset_btn.clicked.connect(self.reset_profile)
        buttons.addWidget(self.reset_btn)
        
        buttons.addStretch()
        layout.addLayout(buttons)
        
        # Загрузка текущего профиля
        self.on_profile_changed()
    
    def load_profiles(self):
        """Загрузка списка профилей."""
        profile_manager = get_profile_manager()
        for key, name in profile_manager.get_profile_names().items():
            self.profile_combo.addItem(name, key)
    
    def on_profile_changed(self):
        """Обработка смены профиля."""
        profile_id = self.profile_combo.currentData()
        if not profile_id:
            return
        
        profile_manager = get_profile_manager()
        profile = profile_manager.get_profile(profile_id)
        
        if profile:
            self.system_prompt.setText(profile.system_prompt)
            self.post_template.setText(profile.post_prompt_template)
            self.comment_template.setText(profile.comment_prompt_template)
            self.keywords_input.setText(", ".join(profile.keywords))
    
    def save_profile(self):
        """Сохранение профиля."""
        profile_id = self.profile_combo.currentData()
        if not profile_id:
            return
        
        profile_manager = get_profile_manager()
        
        keywords = [k.strip() for k in self.keywords_input.text().split(",") if k.strip()]
        
        success = profile_manager.update_profile(
            profile_id=profile_id,
            system_prompt=self.system_prompt.toPlainText().strip(),
            post_prompt_template=self.post_template.toPlainText().strip(),
            comment_prompt_template=self.comment_template.toPlainText().strip(),
            keywords=keywords
        )
        
        if success:
            QMessageBox.information(self, "Успех", "Профиль сохранен")
        else:
            QMessageBox.critical(self, "Ошибка", "Не удалось сохранить профиль")
    
    def reset_profile(self):
        """Сброс профиля к значениям по умолчанию."""
        reply = QMessageBox.question(
            self,
            "Подтверждение",
            "Сбросить ВСЕ профили к значениям по умолчанию?\nЭто действие нельзя отменить.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            profile_manager = get_profile_manager()
            profile_manager.reset_to_defaults()
            self.on_profile_changed()
            QMessageBox.information(self, "Успех", "Профили сброшены к значениям по умолчанию")


class SettingsTab(QWidget):
    """Вкладка настроек."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.load_settings()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # API ключи
        api_group = QGroupBox("API Ключи")
        api_layout = QFormLayout()
        
        self.api_key_input = QLineEdit()
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_input.setPlaceholderText("sk-or-v1-...")
        api_layout.addRow("OpenRouter API Key:", self.api_key_input)
        
        self.test_key_btn = QPushButton("Проверить ключ")
        self.test_key_btn.clicked.connect(self.test_api_key)
        api_layout.addRow(self.test_key_btn)
        
        api_group.setLayout(api_layout)
        layout.addWidget(api_group)
        
        # Настройки браузера
        browser_group = QGroupBox("Настройки браузера")
        browser_layout = QFormLayout()
        
        self.headless_check = QCheckBox("Запускать браузер в фоновом режиме (headless)")
        browser_layout.addRow(self.headless_check)
        
        self.window_width = QSpinBox()
        self.window_width.setRange(800, 1920)
        self.window_width.setValue(1280)
        browser_layout.addRow("Ширина окна:", self.window_width)
        
        self.window_height = QSpinBox()
        self.window_height.setRange(600, 1080)
        self.window_height.setValue(720)
        browser_layout.addRow("Высота окна:", self.window_height)
        
        browser_group.setLayout(browser_layout)
        layout.addWidget(browser_group)
        
        # Настройки поведения
        behavior_group = QGroupBox("Настройки поведения")
        behavior_layout = QFormLayout()
        
        self.typing_delay_min = QSpinBox()
        self.typing_delay_min.setRange(10, 500)
        self.typing_delay_min.setValue(50)
        self.typing_delay_min.setSuffix(" мс")
        behavior_layout.addRow("Мин. задержка печати:", self.typing_delay_min)
        
        self.typing_delay_max = QSpinBox()
        self.typing_delay_max.setRange(50, 1000)
        self.typing_delay_max.setValue(200)
        self.typing_delay_max.setSuffix(" мс")
        behavior_layout.addRow("Макс. задержка печати:", self.typing_delay_max)
        
        self.typo_probability = QSpinBox()
        self.typo_probability.setRange(0, 20)
        self.typo_probability.setValue(5)
        self.typo_probability.setSuffix("%")
        behavior_layout.addRow("Вероятность опечатки:", self.typo_probability)
        
        behavior_group.setLayout(behavior_layout)
        layout.addWidget(behavior_group)
        
        # Кнопки
        buttons = QHBoxLayout()
        
        self.save_btn = QPushButton("💾 Сохранить настройки")
        self.save_btn.clicked.connect(self.save_settings)
        buttons.addWidget(self.save_btn)
        
        buttons.addStretch()
        layout.addLayout(buttons)
        
        layout.addStretch()
    
    def load_settings(self):
        """Загрузка настроек."""
        settings = QSettings("ThreadsBot", "Settings")
        self.api_key_input.setText(settings.value("openrouter_key", ""))
        self.headless_check.setChecked(settings.value("headless", False) in [True, "true", "True"])
    
    def save_settings(self):
        """Сохранение настроек."""
        settings = QSettings("ThreadsBot", "Settings")
        settings.setValue("openrouter_key", self.api_key_input.text().strip())
        settings.setValue("headless", self.headless_check.isChecked())
        
        QMessageBox.information(self, "Успех", "Настройки сохранены")
    
    def test_api_key(self):
        """Проверка API ключа."""
        api_key = self.api_key_input.text().strip()
        if not api_key:
            QMessageBox.warning(self, "Ошибка", "Введите API ключ")
            return
        
        client = get_openrouter_client(api_key)
        
        # Запускаем проверку в отдельном потоке
        class TestThread(QThread):
            finished = pyqtSignal(dict)
            
            def __init__(self, client):
                super().__init__()
                self.client = client
            
            def run(self):
                async def run_test():
                    return await self.client.test_api_key()
                result = asyncio.run(run_test())
                self.finished.emit(result)
        
        self.test_thread = TestThread(client)
        self.test_thread.finished.connect(self._on_test_finished)
        self.test_thread.start()
        
        self.test_key_btn.setEnabled(False)
        self.test_key_btn.setText("Проверка...")
    
    def _on_test_finished(self, result):
        """Обработка результата проверки."""
        self.test_key_btn.setEnabled(True)
        self.test_key_btn.setText("Проверить ключ")
        
        if result.get("success"):
            QMessageBox.information(self, "Успех", "API ключ валиден!")
        else:
            QMessageBox.critical(self, "Ошибка", result.get("message", "Неизвестная ошибка"))


class LogTab(QWidget):
    """Вкладка логов."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Панель инструментов
        toolbar = QHBoxLayout()
        
        self.clear_btn = QPushButton("🗑️ Очистить")
        self.clear_btn.clicked.connect(self.clear_logs)
        toolbar.addWidget(self.clear_btn)
        
        self.export_btn = QPushButton("📤 Экспорт")
        self.export_btn.clicked.connect(self.export_logs)
        toolbar.addWidget(self.export_btn)
        
        toolbar.addStretch()
        layout.addLayout(toolbar)
        
        # Текстовое поле для логов
        self.log_text = QPlainTextEdit()
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)
        
        # Таймер для обновления логов
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_logs)
        self.timer.start(1000)  # Обновление каждую секунду
    
    def update_logs(self):
        """Обновление логов."""
        # Здесь можно добавить чтение из файла логов
        pass
    
    def clear_logs(self):
        """Очистка логов."""
        self.log_text.clear()
    
    def export_logs(self):
        """Экспорт логов."""
        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Экспорт логов",
            "threads_bot_logs.txt",
            "Text Files (*.txt)"
        )
        if filepath:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(self.log_text.toPlainText())
            QMessageBox.information(self, "Успех", "Логи экспортированы")


# =============================================================================
# Главное окно
# =============================================================================

class MainWindow(QMainWindow):
    """Главное окно приложения."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Threads Automation Bot v3.0 - Multi-Account Mastery Edition")
        self.setMinimumSize(1400, 900)
        self.setup_ui()
        self.setup_tray()
        self.setup_scheduler()
    
    def setup_ui(self):
        """Настройка интерфейса."""
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        
        # Вкладки
        self.tabs = QTabWidget()
        self.accounts_tab = AccountsTab()
        self.posting_tab = PostingTab()
        self.commenting_tab = CommentingTab()
        self.profiles_tab = ContentProfilesTab()
        self.settings_tab = SettingsTab()
        self.log_tab = LogTab()
        
        self.tabs.addTab(self.accounts_tab, "👤 Аккаунты")
        self.tabs.addTab(self.posting_tab, "📝 Публикация")
        self.tabs.addTab(self.commenting_tab, "💬 Комментирование")
        self.tabs.addTab(self.profiles_tab, "🎭 Контентные профили")
        self.tabs.addTab(self.settings_tab, "⚙️ Настройки")
        self.tabs.addTab(self.log_tab, "📋 Логи")
        
        # Подключаем сигнал смены вкладки для обновления списков аккаунтов
        self.tabs.currentChanged.connect(self.on_tab_changed)
        
        layout.addWidget(self.tabs)
        
        # Статусная строка
        self.statusBar().showMessage("Готово")
        
        # Меню
        menubar = self.menuBar()
        
        file_menu = menubar.addMenu("Файл")
        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        help_menu = menubar.addMenu("Справка")
        about_action = QAction("О программе", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def on_tab_changed(self, index):
        """При смене вкладки обновляем данные, если нужно."""
        widget = self.tabs.widget(index)
        if hasattr(widget, 'refresh_accounts'):
            widget.refresh_accounts()
    
    def setup_tray(self):
        """Настройка системного трея."""
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setToolTip("Threads Automation Bot v3.0")
        
        # Меню трея
        tray_menu = QMenu()
        show_action = QAction("Показать", self)
        show_action.triggered.connect(self.show)
        tray_menu.addAction(show_action)
        
        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        tray_menu.addAction(exit_action)
        
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.activated.connect(self.on_tray_activated)
        self.tray_icon.show()
    
    def setup_scheduler(self):
        """Настройка планировщика."""
        scheduler = get_scheduler()
        
        # Регистрируем обработчики
        scheduler.register_handler(TaskType.POST, self._handle_scheduled_post)
        scheduler.register_handler(TaskType.COMMENT, self._handle_scheduled_comment)
        
        # Запускаем планировщик
        scheduler.start()
    
    async def _handle_scheduled_post(self, account_id: int, config):
        """Обработчик запланированного поста."""
        logger.info(f"Выполнение запланированного поста для аккаунта {account_id}")
        # TODO: Реализовать публикацию по расписанию
        return {"success": True, "message": "Пост опубликован"}
    
    async def _handle_scheduled_comment(self, account_id: int, config):
        """Обработчик запланированного комментария."""
        logger.info(f"Выполнение запланированного комментирования для аккаунта {account_id}")
        # TODO: Реализовать комментирование по расписанию
        return {"success": True, "message": "Комментарии оставлены"}
    
    def on_tray_activated(self, reason):
        """Обработка активации иконки трея."""
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show()
    
    def closeEvent(self, event):
        """Обработка закрытия окна."""
        # Останавливаем планировщик
        scheduler = get_scheduler()
        scheduler.stop()
        
        event.accept()
    
    def show_about(self):
        """Показ информации о программе."""
        QMessageBox.about(
            self,
            "О программе",
            """<h2>Threads Automation Bot v3.0</h2>
            <p><b>Multi-Account Mastery Edition</b></p>
            <p>Автоматизация работы с Threads для рынков LATAM и Африки.</p>
            <p>Основные возможности:</p>
            <ul>
                <li>Генерация контента с помощью AI (OpenRouter)</li>
                <li>Автоматическая публикация по расписанию</li>
                <li>Автономное комментирование</li>
                <li>Поддержка множественных аккаунтов</li>
                <li>Интеграция с undetected-chromedriver</li>
            </ul>
            <p>Версия: 3.0.0</p>
            """
        )


def initialize_account_manager(parent=None) -> bool:
    """
    Инициализация менеджера аккаунтов с запросом мастер-пароля.
    
    Args:
        parent: Родительское окно
        
    Returns:
        True при успехе
    """
    account_manager = get_account_manager()
    accounts_file = account_manager.accounts_file

    # Если файла с аккаунтами нет - предложить создать
    if not accounts_file.exists():
        reply = QMessageBox.question(
            parent,
            "Первый запуск",
            "Аккаунты не найдены. Хотите создать мастер-пароль?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            password, ok = QInputDialog.getText(
                parent,
                "Создание мастер-пароля",
                "Введите мастер-пароль (минимум 8 символов):",
                QLineEdit.EchoMode.Password
            )
            if ok and len(password) >= 8:
                confirm, ok = QInputDialog.getText(
                    parent,
                    "Подтверждение",
                    "Подтвердите мастер-пароль:",
                    QLineEdit.EchoMode.Password
                )
                if ok and password == confirm:
                    if account_manager.initialize(password):
                        QMessageBox.information(parent, "Успех", "Мастер-пароль создан!")
                        return True
            QMessageBox.critical(parent, "Ошибка", "Пароли не совпадают или слишком короткие")
        return False

    # Файл есть - запрашиваем пароль
    password, ok = QInputDialog.getText(
        parent,
        "Мастер-пароль",
        "Введите мастер-пароль для расшифровки аккаунтов:",
        QLineEdit.EchoMode.Password
    )
    if not ok or not password:
        return False

    if account_manager.initialize(password):
        return True
    else:
        QMessageBox.critical(
            parent,
            "Ошибка",
            "Неверный пароль или поврежденные данные."
        )
        return False


def main():
    """Точка входа для GUI."""
    app = QApplication(sys.argv)
    app.setApplicationName("Threads Automation Bot")
    app.setOrganizationName("ThreadsBot")
    
    # Настройка стиля
    app.setStyle("Fusion")
    
    # Создание главного окна
    window = MainWindow()
    
    # Инициализация менеджера аккаунтов
    if not initialize_account_manager(window):
        sys.exit(1)
    
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()