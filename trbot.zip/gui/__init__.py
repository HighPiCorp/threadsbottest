"""
GUI Module v3.0
Графический интерфейс на PyQt6.
"""

from .main_window import MainWindow, main

__all__ = ["MainWindow", "main"]
