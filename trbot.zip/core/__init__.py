"""
Core Module - Threads Automation Bot v3.0
Main functionality for Multi-Account Mastery Edition.
"""

from .account_manager import (
    AccountManager,
    Account,
    ProxyConfig,
    get_account_manager,
)

from .openrouter_client import (
    OpenRouterClient,
    ModelConfig,
    GenerationResult,
    get_openrouter_client,
    DEFAULT_MODELS,
)

from .content_profiles import (
    ContentProfile,
    ContentProfileManager,
    get_profile_manager,
)

from .engines.uc_engine import (
    UCEngine,
    BrowserConfig,
)

from .proxy_checker import (
    ProxyChecker,
    ProxyCheckResult,
    ProxyType,
    get_proxy_checker,
)

from .comment_registry import (
    GlobalCommentRegistry,
    get_global_registry,
)

from .scheduler import (
    BotScheduler,
    ScheduleConfig,
    TaskType,
    TaskResult,
    get_scheduler,
)

from .poster import (
    Poster,
    PostResult,
)

from .commenter import (
    Commenter,
    CommentResult,
)

__all__ = [
    # Account Management
    "AccountManager",
    "Account",
    "ProxyConfig",
    "get_account_manager",
    
    # OpenRouter
    "OpenRouterClient",
    "ModelConfig",
    "GenerationResult",
    "get_openrouter_client",
    "DEFAULT_MODELS",
    
    # Content Profiles
    "ContentProfile",
    "ContentProfileManager",
    "get_profile_manager",
    
    # Engine (undetected-chromedriver only)
    "UCEngine",
    "BrowserConfig",
    
    # Proxy Checker
    "ProxyChecker",
    "ProxyCheckResult",
    "ProxyType",
    "get_proxy_checker",
    
    # Comment Registry
    "GlobalCommentRegistry",
    "get_global_registry",
    
    # Scheduler
    "BotScheduler",
    "ScheduleConfig",
    "TaskType",
    "TaskResult",
    "get_scheduler",
    
    # Poster
    "Poster",
    "PostResult",
    
    # Commenter
    "Commenter",
    "CommentResult",
]
