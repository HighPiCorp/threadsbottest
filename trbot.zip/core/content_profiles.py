"""
Content Profiles Module v3.0
Управление контентными профилями для разных рынков.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from loguru import logger


@dataclass
class ContentProfile:
    """Контентный профиль для генерации постов и комментариев."""
    name: str
    description: str
    language: str
    system_prompt: str
    post_prompt_template: str
    comment_prompt_template: str
    keywords: List[str]


class ContentProfileManager:
    """
    Менеджер контентных профилей.
    Управляет загрузкой, сохранением и редактированием профилей.
    """
    
    # Профили по умолчанию
    DEFAULT_PROFILES = {
        "primary": ContentProfile(
            name="Primary (EN)",
            description="Глобальный эксперт, английский язык",
            language="en",
            system_prompt="""You are a global expert in multi-accounting and affiliate marketing. You write for an audience of arbitrageurs and SMM managers. Your tone is authoritative, friendly, and data-driven. You explain complex technical concepts (anti-detect browsers, proxies, fingerprinting) in an accessible way. Language: English.""",
            post_prompt_template="""Write a Threads post about {topic}. Start with a strong hook, provide one key actionable insight, and end with a question to encourage discussion. Max 250 characters.""",
            comment_prompt_template="""Write an insightful comment in English on this post: '{post_content}'. Add a piece of advice, ask a clarifying question, or share a related personal experience. Max 120 characters.""",
            keywords=[
                "multilogin",
                "antidetect browser",
                "affiliate marketing",
                "proxy",
                "ban",
                "Facebook ads",
                "TikTok ads",
                "account suspension"
            ]
        ),
        "latam": ContentProfile(
            name="LATAM (ES/PT)",
            description="Латиноамериканский рынок, испанский/португальский",
            language="es/pt",
            system_prompt="""Eres un 'compa que sabe', un experto local en multi-cuentas para LATAM. Hablas español y portugués de forma natural. Tu tono es cálido, cercano, construyes 'confianza'. Menciona sistemas de pago locales como Pix (Brasil) y Oxxo (México). Usa emojis y un lenguaje emocional.""",
            post_prompt_template="""Escribe un post para Threads sobre {topic} en español o portugués (dependiendo del contexto del post). Empieza con una frase que enganche ('A mí me pasó lo mismo...'), comparte una anécdota personal y termina con una pregunta para la comunidad. Máx 250 caracteres.""",
            comment_prompt_template="""Responde a este post: '{post_content}'. Tu comentario debe ser de apoyo, empático y mostrar que entiendes el problema local. Ofrece una solución o pregunta. Usa español o portugués. Máx 100 caracteres.""",
            keywords=[
                "conta bloqueada",
                "pix",
                "oxxo",
                "facebook ban brasil",
                "tiktok brasil",
                "multilogin brasil"
            ]
        ),
        "africa": ContentProfile(
            name="Africa (EN)",
            description="Африканский рынок, прагматичный английский",
            language="en",
            system_prompt="""You are a top-performing affiliate marketer in Africa (Nigeria, South Africa, Kenya). Your tone is pragmatic, direct, and results-oriented. You focus on specific challenges: mobile proxies (MTN, Airtel, Safaricom), M-Pesa, data costs, and platform bans. You use data and case studies. Language: English.""",
            post_prompt_template="""Write a data-driven Threads post about {topic}. Start with a surprising statistic or a concrete problem, explain the solution in 2-3 steps, and end with a call to action (e.g., 'Check the link in bio for the full guide'). Max 250 characters.""",
            comment_prompt_template="""Write a helpful comment on this post: '{post_content}'. Be direct. Offer a specific tip, a tool name, or a counter-strategy based on your African market experience. Max 120 characters.""",
            keywords=[
                "MTN proxy",
                "Airtel",
                "M-Pesa",
                "Nigeria ads",
                "South Africa affiliate",
                "data costs",
                "mobile proxy"
            ]
        )
    }
    
    # Фильтры по умолчанию
    DEFAULT_FILTERS = {
        "min_likes": 10,
        "max_post_age_hours": 72,
        "blocked_authors": [],
        "comments_per_session": 5,
        "delay_between_comments_min": 30,
        "delay_between_comments_max": 90
    }
    
    def __init__(self, config_path: str = "config/content_profiles.json"):
        """
        Инициализация менеджера профилей.
        
        Args:
            config_path: Путь к файлу конфигурации профилей
        """
        self.config_path = Path(config_path)
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._profiles: Dict[str, ContentProfile] = {}
        self._filters: Dict[str, Any] = {}
        
        self._load_profiles()
    
    def _load_profiles(self):
        """Загрузка профилей из файла или создание по умолчанию."""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Загружаем профили
                for key, profile_data in data.get("profiles", {}).items():
                    self._profiles[key] = ContentProfile(**profile_data)
                
                # Загружаем фильтры
                self._filters = data.get("filters", self.DEFAULT_FILTERS.copy())
                
                logger.info(f"Загружено {len(self._profiles)} контентных профилей")
                
            except Exception as e:
                logger.error(f"Ошибка загрузки профилей: {e}")
                self._create_default_profiles()
        else:
            self._create_default_profiles()
    
    def _create_default_profiles(self):
        """Создание профилей по умолчанию."""
        self._profiles = self.DEFAULT_PROFILES.copy()
        self._filters = self.DEFAULT_FILTERS.copy()
        self._save_profiles()
        logger.info("Созданы профили по умолчанию")
    
    def _save_profiles(self) -> bool:
        """Сохранение профилей в файл."""
        try:
            data = {
                "profiles": {
                    key: asdict(profile)
                    for key, profile in self._profiles.items()
                },
                "filters": self._filters
            }
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.info("Профили сохранены")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка сохранения профилей: {e}")
            return False
    
    def get_profile(self, profile_id: str) -> Optional[ContentProfile]:
        """
        Получение профиля по ID.
        
        Args:
            profile_id: Идентификатор профиля (primary, latam, africa)
            
        Returns:
            Контентный профиль или None
        """
        return self._profiles.get(profile_id)
    
    def get_all_profiles(self) -> Dict[str, ContentProfile]:
        """
        Получение всех профилей.
        
        Returns:
            Словарь всех профилей
        """
        return self._profiles.copy()
    
    def update_profile(
        self,
        profile_id: str,
        system_prompt: Optional[str] = None,
        post_prompt_template: Optional[str] = None,
        comment_prompt_template: Optional[str] = None,
        keywords: Optional[List[str]] = None
    ) -> bool:
        """
        Обновление профиля.
        
        Args:
            profile_id: Идентификатор профиля
            system_prompt: Новый системный промпт
            post_prompt_template: Новый шаблон поста
            comment_prompt_template: Новый шаблон комментария
            keywords: Новый список ключевых слов
            
        Returns:
            True если обновление успешно
        """
        if profile_id not in self._profiles:
            logger.error(f"Профиль {profile_id} не найден")
            return False
        
        profile = self._profiles[profile_id]
        
        if system_prompt is not None:
            profile.system_prompt = system_prompt
        
        if post_prompt_template is not None:
            profile.post_prompt_template = post_prompt_template
        
        if comment_prompt_template is not None:
            profile.comment_prompt_template = comment_prompt_template
        
        if keywords is not None:
            profile.keywords = keywords
        
        return self._save_profiles()
    
    def get_keywords(self, profile_id: str) -> List[str]:
        """
        Получение ключевых слов для профиля.
        
        Args:
            profile_id: Идентификатор профиля
            
        Returns:
            Список ключевых слов
        """
        profile = self._profiles.get(profile_id)
        if profile:
            return profile.keywords
        return []
    
    def update_keywords(self, profile_id: str, keywords: List[str]) -> bool:
        """
        Обновление ключевых слов для профиля.
        
        Args:
            profile_id: Идентификатор профиля
            keywords: Новый список ключевых слов
            
        Returns:
            True если обновление успешно
        """
        if profile_id not in self._profiles:
            logger.error(f"Профиль {profile_id} не найден")
            return False
        
        self._profiles[profile_id].keywords = keywords
        return self._save_profiles()
    
    def get_filters(self) -> Dict[str, Any]:
        """
        Получение настроек фильтров.
        
        Returns:
            Словарь фильтров
        """
        return self._filters.copy()
    
    def update_filters(self, **kwargs) -> bool:
        """
        Обновление настроек фильтров.
        
        Args:
            **kwargs: Параметры фильтров для обновления
            
        Returns:
            True если обновление успешно
        """
        self._filters.update(kwargs)
        return self._save_profiles()
    
    def reset_to_defaults(self) -> bool:
        """Сброс всех профилей к значениям по умолчанию."""
        self._profiles = self.DEFAULT_PROFILES.copy()
        self._filters = self.DEFAULT_FILTERS.copy()
        return self._save_profiles()
    
    def get_profile_names(self) -> Dict[str, str]:
        """
        Получение словаря имен профилей для отображения.
        
        Returns:
            Словарь {id: name}
        """
        return {
            key: f"{profile.name} - {profile.description}"
            for key, profile in self._profiles.items()
        }


# Singleton instance
_profile_manager: Optional[ContentProfileManager] = None


def get_profile_manager(config_path: str = "config/content_profiles.json") -> ContentProfileManager:
    """
    Получение синглтона менеджера профилей.
    
    Args:
        config_path: Путь к файлу конфигурации
        
    Returns:
        Экземпляр ContentProfileManager
    """
    global _profile_manager
    if _profile_manager is None:
        _profile_manager = ContentProfileManager(config_path)
    return _profile_manager
