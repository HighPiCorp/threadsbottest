"""
Poster Module v3.0
Модуль публикации постов в Threads.
"""

import time
import random
from typing import Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from loguru import logger

from .engines.uc_engine import UCEngine, BrowserConfig
from .account_manager import Account
from .openrouter_client import OpenRouterClient


@dataclass
class PostResult:
    """Результат публикации поста."""
    success: bool
    post_url: Optional[str]
    post_id: Optional[str]
    error_message: Optional[str]
    published_at: Optional[datetime]


class Poster:
    """
    Публикатор постов в Threads.
    
    Features:
    - Публикация постов через UCEngine
    - Генерация контента через OpenRouter
    - Проверка успешности публикации
    - Логирование ошибок
    """
    
    def __init__(
        self,
        account: Account,
        engine: UCEngine,
        ai_client: Optional[OpenRouterClient] = None
    ):
        """
        Инициализация публикатора.
        
        Args:
            account: Аккаунт для публикации
            engine: Экземпляр UCEngine
            ai_client: Клиент OpenRouter (опционально)
        """
        self.account = account
        self.engine = engine
        self.ai_client = ai_client
        
        # Загрузка селекторов
        self.selectors = self._load_selectors()
    
    def _load_selectors(self) -> Dict[str, Any]:
        """Загрузка селекторов из файла."""
        try:
            import json
            selectors_path = Path(__file__).parent.parent / "config" / "selectors.json"
            with open(selectors_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("posting", {})
        except Exception as e:
            logger.error(f"Ошибка загрузки селекторов: {e}")
            return {}
    
    async def create_post(
        self,
        content: str,
        check_success: bool = True
    ) -> PostResult:
        """
        Создание поста в Threads.
        
        Args:
            content: Текст поста
            check_success: Проверять успешность публикации
            
        Returns:
            Результат публикации
        """
        try:
            logger.info(f"Начало публикации поста для {self.account.username}")
            
            # Переходим на Threads
            self.engine.navigate_to_threads()
            
            # Проверяем авторизацию
            if not self.engine.is_logged_in():
                logger.warning("Не авторизован, требуется вход")
                # TODO: Реализовать авторизацию
                return PostResult(
                    success=False,
                    post_url=None,
                    post_id=None,
                    error_message="Требуется авторизация",
                    published_at=None
                )
            
            # Клик по кнопке создания поста
            create_button = self.engine.find_element(
                self.selectors.get("create_button", "a[href='/compose/post']"),
                clickable=True,
                timeout=10
            )
            
            if not create_button:
                logger.error("Кнопка создания поста не найдена")
                self._save_debug_info("create_button_not_found")
                return PostResult(
                    success=False,
                    post_url=None,
                    post_id=None,
                    error_message="Кнопка создания поста не найдена",
                    published_at=None
                )
            
            self.engine.click_element(create_button)
            time.sleep(random.uniform(1, 2))
            
            # Находим поле ввода
            text_input = self.engine.find_element(
                self.selectors.get("text_input", "div[contenteditable='true'][role='textbox']"),
                timeout=10
            )
            
            if not text_input:
                logger.error("Поле ввода текста не найдено")
                self._save_debug_info("text_input_not_found")
                return PostResult(
                    success=False,
                    post_url=None,
                    post_id=None,
                    error_message="Поле ввода текста не найдено",
                    published_at=None
                )
            
            # Вводим текст
            self.engine.type_text(text_input, content, simulate_human=True)
            time.sleep(random.uniform(0.5, 1.5))
            
            # Клик по кнопке отправки
            submit_button = self.engine.find_element(
                self.selectors.get("submit_button", "button[type='submit']"),
                clickable=True,
                timeout=10
            )
            
            if not submit_button:
                logger.error("Кнопка отправки не найдена")
                self._save_debug_info("submit_button_not_found")
                return PostResult(
                    success=False,
                    post_url=None,
                    post_id=None,
                    error_message="Кнопка отправки не найдена",
                    published_at=None
                )
            
            self.engine.click_element(submit_button)
            time.sleep(random.uniform(2, 4))
            
            # Проверка успешности
            if check_success:
                success, post_url, post_id = self._verify_post_success()
                
                if success:
                    logger.info(f"Пост успешно опубликован: {post_url}")
                    return PostResult(
                        success=True,
                        post_url=post_url,
                        post_id=post_id,
                        error_message=None,
                        published_at=datetime.now()
                    )
                else:
                    logger.error("Не удалось подтвердить успешность публикации")
                    self._save_debug_info("verification_failed")
                    return PostResult(
                        success=False,
                        post_url=None,
                        post_id=None,
                        error_message="Не удалось подтвердить публикацию",
                        published_at=None
                    )
            else:
                return PostResult(
                    success=True,
                    post_url=None,
                    post_id=None,
                    error_message=None,
                    published_at=datetime.now()
                )
            
        except Exception as e:
            logger.exception(f"Ошибка при создании поста: {e}")
            self._save_debug_info(f"exception_{type(e).__name__}")
            return PostResult(
                success=False,
                post_url=None,
                post_id=None,
                error_message=str(e),
                published_at=None
            )
    
    def _verify_post_success(self) -> tuple:
        """
        Проверка успешности публикации.
        
        Returns:
            Кортеж (success, post_url, post_id)
        """
        # Проверка 1: Появление индикатора успеха
        success_indicator = self.engine.find_element(
            self.selectors.get("success_indicator", "[data-testid='toast']"),
            timeout=10
        )
        
        if success_indicator:
            logger.debug("Обнаружен индикатор успеха")
        
        # Проверка 2: Наличие ID поста в URL
        time.sleep(2)
        current_url = self.engine.get_current_url()
        
        if "/post/" in current_url:
            post_id = current_url.split("/post/")[-1].split("/")[0]
            logger.debug(f"Обнаружен ID поста в URL: {post_id}")
            return True, current_url, post_id
        
        # Проверка 3: Поиск ссылки на пост
        post_link = self.engine.find_element(
            self.selectors.get("post_link", "a[href*='/post/']"),
            timeout=5
        )
        
        if post_link:
            href = post_link.get_attribute("href")
            if href and "/post/" in href:
                post_id = href.split("/post/")[-1].split("/")[0]
                logger.debug(f"Обнаружена ссылка на пост: {href}")
                return True, href, post_id
        
        return False, None, None
    
    def _save_debug_info(self, suffix: str):
        """Сохранение отладочной информации."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            debug_dir = Path(__file__).parent.parent / "logs" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            
            # Сохраняем HTML
            html_path = debug_dir / f"post_error_{suffix}_{timestamp}.html"
            self.engine.save_page_source(str(html_path))
            
            # Сохраняем скриншот
            screenshot_path = debug_dir / f"post_error_{suffix}_{timestamp}.png"
            self.engine.save_screenshot(str(screenshot_path))
            
            logger.info(f"Отладочная информация сохранена: {debug_dir}")
        except Exception as e:
            logger.error(f"Ошибка сохранения отладочной информации: {e}")
    
    async def generate_and_post(
        self,
        profile: Dict[str, Any],
        topic: str
    ) -> PostResult:
        """
        Генерация и публикация поста.
        
        Args:
            profile: Контентный профиль
            topic: Тема поста
            
        Returns:
            Результат публикации
        """
        if not self.ai_client:
            return PostResult(
                success=False,
                post_url=None,
                post_id=None,
                error_message="AI клиент не инициализирован",
                published_at=None
            )
        
        # Генерация контента
        result = await self.ai_client.generate_post(profile, topic)
        
        if not result.success:
            return PostResult(
                success=False,
                post_url=None,
                post_id=None,
                error_message=f"Ошибка генерации: {result.error}",
                published_at=None
            )
        
        # Публикация
        return await self.create_post(result.content)
