"""
Global Comment Registry Module v3.0
Централизованное хранилище идентификаторов прокомментированных постов.
"""

import sqlite3
import os
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from dataclasses import dataclass
from loguru import logger


@dataclass
class CommentRecord:
    """Запись о комментарии."""
    post_id: str
    account_id: int
    profile_id: str
    comment_text: str
    post_url: Optional[str]
    commented_at: datetime


class GlobalCommentRegistry:
    """
    Глобальный реестр комментариев на базе SQLite.
    Предотвращает дублирование комментариев.
    """
    
    def __init__(self, db_path: str = None):
        """
        Инициализация реестра.
        
        Args:
            db_path: Путь к файлу базы данных
        """
        if db_path is None:
            base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
            base_dir.mkdir(parents=True, exist_ok=True)
            self.db_path = base_dir / "comment_registry.db"
        else:
            self.db_path = Path(db_path)
        
        self._init_db()
    
    def _init_db(self):
        """Инициализация базы данных."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS comments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    post_id TEXT NOT NULL,
                    account_id INTEGER NOT NULL,
                    profile_id TEXT NOT NULL,
                    comment_text TEXT NOT NULL,
                    post_url TEXT,
                    commented_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(post_id, account_id)
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_post_id ON comments(post_id)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_account_id ON comments(account_id)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_commented_at ON comments(commented_at)
            """)
            
            conn.commit()
        
        logger.info(f"GlobalCommentRegistry инициализирован: {self.db_path}")
    
    def has_commented(self, post_id: str, account_id: int) -> bool:
        """
        Проверка, комментировал ли аккаунт этот пост.
        
        Args:
            post_id: ID поста
            account_id: ID аккаунта
            
        Returns:
            True если уже комментировал
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT 1 FROM comments WHERE post_id = ? AND account_id = ?",
                (post_id, account_id)
            )
            return cursor.fetchone() is not None
    
    def register_comment(
        self,
        post_id: str,
        account_id: int,
        profile_id: str,
        comment_text: str,
        post_url: Optional[str] = None
    ) -> bool:
        """
        Регистрация нового комментария.
        
        Args:
            post_id: ID поста
            account_id: ID аккаунта
            profile_id: ID контентного профиля
            comment_text: Текст комментария
            post_url: URL поста (опционально)
            
        Returns:
            True если регистрация успешна
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """INSERT INTO comments (post_id, account_id, profile_id, comment_text, post_url)
                       VALUES (?, ?, ?, ?, ?)""",
                    (post_id, account_id, profile_id, comment_text, post_url)
                )
                conn.commit()
            
            logger.info(f"Зарегистрирован комментарий: post_id={post_id}, account_id={account_id}")
            return True
            
        except sqlite3.IntegrityError:
            logger.warning(f"Комментарий уже существует: post_id={post_id}, account_id={account_id}")
            return False
        except Exception as e:
            logger.error(f"Ошибка регистрации комментария: {e}")
            return False
    
    def get_comment_history(
        self,
        account_id: Optional[int] = None,
        profile_id: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Получение истории комментариев.
        
        Args:
            account_id: Фильтр по аккаунту (опционально)
            profile_id: Фильтр по профилю (опционально)
            since: Фильтр по дате (опционально)
            limit: Максимальное количество записей
            
        Returns:
            Список записей о комментариях
        """
        query = "SELECT * FROM comments WHERE 1=1"
        params = []
        
        if account_id is not None:
            query += " AND account_id = ?"
            params.append(account_id)
        
        if profile_id is not None:
            query += " AND profile_id = ?"
            params.append(profile_id)
        
        if since is not None:
            query += " AND commented_at >= ?"
            params.append(since.isoformat())
        
        query += " ORDER BY commented_at DESC LIMIT ?"
        params.append(limit)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query, params)
            rows = cursor.fetchall()
            
            return [dict(row) for row in rows]
    
    def get_stats(self, account_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Получение статистики комментариев.
        
        Args:
            account_id: ID аккаунта (опционально)
            
        Returns:
            Словарь со статистикой
        """
        with sqlite3.connect(self.db_path) as conn:
            # Общее количество
            if account_id:
                cursor = conn.execute(
                    "SELECT COUNT(*) FROM comments WHERE account_id = ?",
                    (account_id,)
                )
            else:
                cursor = conn.execute("SELECT COUNT(*) FROM comments")
            
            total = cursor.fetchone()[0]
            
            # За сегодня
            today = datetime.now().strftime("%Y-%m-%d")
            if account_id:
                cursor = conn.execute(
                    "SELECT COUNT(*) FROM comments WHERE account_id = ? AND date(commented_at) = ?",
                    (account_id, today)
                )
            else:
                cursor = conn.execute(
                    "SELECT COUNT(*) FROM comments WHERE date(commented_at) = ?",
                    (today,)
                )
            
            today_count = cursor.fetchone()[0]
            
            # По профилям
            cursor = conn.execute(
                "SELECT profile_id, COUNT(*) FROM comments GROUP BY profile_id"
            )
            by_profile = {row[0]: row[1] for row in cursor.fetchall()}
            
            return {
                "total": total,
                "today": today_count,
                "by_profile": by_profile
            }
    
    def clear_old_records(self, days: int = 30) -> int:
        """
        Очистка старых записей.
        
        Args:
            days: Удалить записи старше N дней
            
        Returns:
            Количество удаленных записей
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM comments WHERE commented_at < datetime('now', '-{} days')".format(days)
            )
            conn.commit()
            deleted = cursor.rowcount
        
        logger.info(f"Удалено {deleted} старых записей")
        return deleted
    
    def reset(self) -> bool:
        """Полная очистка реестра."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("DELETE FROM comments")
                conn.commit()
            
            logger.info("Реестр комментариев очищен")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка очистки реестра: {e}")
            return False


# Singleton instance
_registry: Optional[GlobalCommentRegistry] = None


def get_global_registry(db_path: str = None) -> GlobalCommentRegistry:
    """
    Получение синглтона GlobalCommentRegistry.
    
    Args:
        db_path: Путь к файлу базы данных (опционально)
        
    Returns:
        Экземпляр GlobalCommentRegistry
    """
    global _registry
    if _registry is None:
        _registry = GlobalCommentRegistry(db_path)
    return _registry
