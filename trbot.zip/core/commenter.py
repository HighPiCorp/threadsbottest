"""
Commenter Module v3.0
Модуль автоматического комментирования постов в Threads.
"""

import time
import random
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from loguru import logger

try:
    from langdetect import detect
    LANGDETECT_AVAILABLE = True
except ImportError:
    LANGDETECT_AVAILABLE = False
    logger.warning("langdetect не установлен, определение языка недоступно")

from .engines.uc_engine import UCEngine
from .account_manager import Account
from .openrouter_client import OpenRouterClient
from .content_profiles import ContentProfileManager
from .comment_registry import GlobalCommentRegistry


@dataclass
class CommentResult:
    """Результат комментирования."""
    success: bool
    post_id: Optional[str]
    comment_text: Optional[str]
    error_message: Optional[str]
    commented_at: Optional[datetime]


class Commenter:
    """
    Комментатор постов в Threads.
    
    Features:
    - Поиск постов по ключевым словам
    - Фильтрация постов
    - Генерация комментариев через OpenRouter
    - Имитация человеческого поведения
    - Регистрация в GlobalCommentRegistry
    """
    
    def __init__(
        self,
        account: Account,
        engine: UCEngine,
        ai_client: Optional[OpenRouterClient] = None,
        registry: Optional[GlobalCommentRegistry] = None,
        profile_manager: Optional[ContentProfileManager] = None
    ):
        """
        Инициализация комментатора.
        
        Args:
            account: Аккаунт для комментирования
            engine: Экземпляр UCEngine
            ai_client: Клиент OpenRouter
            registry: Реестр комментариев
            profile_manager: Менеджер контентных профилей
        """
        self.account = account
        self.engine = engine
        self.ai_client = ai_client
        self.registry = registry or GlobalCommentRegistry()
        self.profile_manager = profile_manager or ContentProfileManager()
        
        # Загрузка селекторов
        self.selectors = self._load_selectors()
        
        # Загрузка фильтров
        self.filters = self.profile_manager.get_filters()
    
    def _load_selectors(self) -> Dict[str, Any]:
        """Загрузка селекторов из файла."""
        try:
            import json
            selectors_path = Path(__file__).parent.parent / "config" / "selectors.json"
            with open(selectors_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("commenting", {})
        except Exception as e:
            logger.error(f"Ошибка загрузки селекторов: {e}")
            return {}
    
    def _detect_language(self, text: str) -> str:
        """Определение языка текста."""
        if not LANGDETECT_AVAILABLE:
            return "unknown"
        
        try:
            lang = detect(text)
            return lang
        except Exception:
            return "unknown"
    
    def _should_use_latam_profile(self, post_text: str) -> bool:
        """Определить, нужно ли использовать LATAM профиль для комментария."""
        lang = self._detect_language(post_text)
        return lang in ["es", "pt", "ca", "gl"]  # Испанский, португальский и родственные
    
    async def search_posts(
        self,
        keywords: List[str],
        max_posts: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Поиск постов по ключевым словам.
        
        Args:
            keywords: Список ключевых слов
            max_posts: Максимальное количество постов
            
        Returns:
            Список найденных постов
        """
        posts = []
        
        for keyword in keywords:
            try:
                logger.info(f"Поиск постов по ключевому слову: {keyword}")
                
                # Переходим на страницу поиска
                search_url = f"https://www.threads.net/search?q={keyword.replace(' ', '%20')}"
                self.engine.navigate_to(search_url)
                time.sleep(random.uniform(3, 5))
                
                # Ищем посты
                post_elements = self.engine.find_elements(
                    self.selectors.get("post_articles", "article[data-testid='post']")
                )
                
                logger.info(f"Найдено {len(post_elements)} постов по ключевому слову '{keyword}'")
                
                for element in post_elements[:max_posts]:
                    try:
                        # Извлекаем информацию о посте
                        post_data = self._extract_post_data(element)
                        if post_data:
                            posts.append(post_data)
                    except Exception as e:
                        logger.warning(f"Ошибка извлечения данных поста: {e}")
                
                # Пауза между поисками
                time.sleep(random.uniform(2, 4))
                
            except Exception as e:
                logger.error(f"Ошибка поиска по ключевому слову '{keyword}': {e}")
        
        return posts
    
    def _extract_post_data(self, element) -> Optional[Dict[str, Any]]:
        """Извлечение данных о посте из элемента."""
        try:
            # Текст поста
            text_element = element.find_element(
                "css selector",
                self.selectors.get("post_text", "div[data-testid='post-text']")
            )
            post_text = text_element.text if text_element else ""
            
            # Количество лайков
            likes_element = element.find_element(
                "css selector",
                self.selectors.get("like_count", "span[data-testid='like-count']")
            )
            likes_text = likes_element.text if likes_element else "0"
            likes = self._parse_likes(likes_text)
            
            # Время публикации
            time_element = element.find_element(
                "css selector",
                self.selectors.get("post_timestamp", "time[datetime]")
            )
            timestamp = time_element.get_attribute("datetime") if time_element else None
            
            # ID поста (извлекаем из ссылки)
            link_element = element.find_element("css selector", "a[href*='/post/']")
            href = link_element.get_attribute("href") if link_element else ""
            post_id = href.split("/post/")[-1].split("/")[0] if "/post/" in href else None
            
            return {
                "id": post_id,
                "text": post_text,
                "likes": likes,
                "timestamp": timestamp,
                "url": href,
                "element": element
            }
            
        except Exception as e:
            logger.warning(f"Ошибка извлечения данных поста: {e}")
            return None
    
    def _parse_likes(self, likes_text: str) -> int:
        """Парсинг количества лайков из текста."""
        try:
            # Убираем запятые и пробелы
            likes_text = likes_text.replace(",", "").replace(" ", "")
            
            # Обрабатываем K и M
            if "K" in likes_text.upper():
                return int(float(likes_text.upper().replace("K", "")) * 1000)
            elif "M" in likes_text.upper():
                return int(float(likes_text.upper().replace("M", "")) * 1000000)
            else:
                return int(likes_text)
        except ValueError:
            return 0
    
    def _filter_posts(
        self,
        posts: List[Dict[str, Any]],
        blocked_authors: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Фильтрация постов по критериям.
        
        Args:
            posts: Список постов
            blocked_authors: Список заблокированных авторов
            
        Returns:
            Отфильтрованный список постов
        """
        filtered = []
        blocked_authors = blocked_authors or []
        
        min_likes = self.filters.get("min_likes", 10)
        max_age_hours = self.filters.get("max_post_age_hours", 72)
        
        for post in posts:
            # Проверка на дублирование
            if self.registry.has_commented(post["id"], self.account.id):
                logger.debug(f"Пост {post['id']} уже комментировался")
                continue
            
            # Проверка количества лайков
            if post["likes"] < min_likes:
                logger.debug(f"Пост {post['id']} имеет слишком мало лайков: {post['likes']}")
                continue
            
            # Проверка возраста поста
            if post["timestamp"]:
                try:
                    from datetime import datetime, timezone
                    post_time = datetime.fromisoformat(post["timestamp"].replace("Z", "+00:00"))
                    age_hours = (datetime.now(timezone.utc) - post_time).total_seconds() / 3600
                    if age_hours > max_age_hours:
                        logger.debug(f"Пост {post['id']} слишком старый: {age_hours:.1f}ч")
                        continue
                except Exception:
                    pass
            
            filtered.append(post)
        
        logger.info(f"После фильтрации осталось {len(filtered)} постов")
        return filtered
    
    async def comment_on_post(
        self,
        post: Dict[str, Any],
        profile_id: Optional[str] = None
    ) -> CommentResult:
        """
        Комментирование поста.
        
        Args:
            post: Данные о посте
            profile_id: ID контентного профиля (опционально)
            
        Returns:
            Результат комментирования
        """
        try:
            post_id = post["id"]
            post_text = post["text"]
            
            logger.info(f"Комментирование поста {post_id}")
            
            # Проверяем, не комментировали ли уже
            if self.registry.has_commented(post_id, self.account.id):
                return CommentResult(
                    success=False,
                    post_id=post_id,
                    comment_text=None,
                    error_message="Пост уже комментировался",
                    commented_at=None
                )
            
            # Определяем профиль для комментария
            if profile_id is None:
                if self._should_use_latam_profile(post_text):
                    profile_id = "latam"
                else:
                    profile_id = self.account.content_profile
            
            profile = self.profile_manager.get_profile(profile_id)
            if not profile:
                return CommentResult(
                    success=False,
                    post_id=post_id,
                    comment_text=None,
                    error_message=f"Профиль {profile_id} не найден",
                    commented_at=None
                )
            
            # Генерация комментария
            if not self.ai_client:
                return CommentResult(
                    success=False,
                    post_id=post_id,
                    comment_text=None,
                    error_message="AI клиент не инициализирован",
                    commented_at=None
                )
            
            target_language = "es/pt" if profile_id == "latam" else None
            result = await self.ai_client.generate_comment(
                profile,
                post_text,
                target_language=target_language
            )
            
            if not result.success:
                return CommentResult(
                    success=False,
                    post_id=post_id,
                    comment_text=None,
                    error_message=f"Ошибка генерации: {result.error}",
                    commented_at=None
                )
            
            comment_text = result.content
            
            # Открываем пост
            self.engine.click_element(post["element"])
            time.sleep(random.uniform(2, 4))
            
            # Имитация чтения
            self.engine.simulate_reading(
                min_time=self.filters.get("min_read_time", 3),
                max_time=self.filters.get("max_read_time", 10)
            )
            
            # Находим поле комментария
            comment_input = self.engine.find_element(
                self.selectors.get("comment_input", "div[contenteditable='true'][role='textbox']"),
                timeout=10
            )
            
            if not comment_input:
                return CommentResult(
                    success=False,
                    post_id=post_id,
                    comment_text=None,
                    error_message="Поле комментария не найдено",
                    commented_at=None
                )
            
            # Вводим комментарий
            self.engine.type_text(comment_input, comment_text, simulate_human=True)
            time.sleep(random.uniform(0.5, 1.5))
            
            # Отправляем
            submit_button = self.engine.find_element(
                self.selectors.get("comment_submit", "button[type='submit']"),
                clickable=True,
                timeout=5
            )
            
            if submit_button:
                self.engine.click_element(submit_button)
                time.sleep(random.uniform(1, 2))
            
            # Регистрируем комментарий
            self.registry.register_comment(
                post_id=post_id,
                account_id=self.account.id,
                profile_id=profile_id,
                comment_text=comment_text,
                post_url=post.get("url")
            )
            
            logger.info(f"Комментарий успешно оставлен на пост {post_id}")
            
            return CommentResult(
                success=True,
                post_id=post_id,
                comment_text=comment_text,
                error_message=None,
                commented_at=datetime.now()
            )
            
        except Exception as e:
            logger.exception(f"Ошибка комментирования поста: {e}")
            return CommentResult(
                success=False,
                post_id=post.get("id"),
                comment_text=None,
                error_message=str(e),
                commented_at=None
            )
    
    async def run_comment_cycle(
        self,
        keywords: List[str],
        max_comments: int = None
    ) -> List[CommentResult]:
        """
        Запуск цикла комментирования.
        
        Args:
            keywords: Список ключевых слов для поиска
            max_comments: Максимальное количество комментариев
            
        Returns:
            Список результатов
        """
        if max_comments is None:
            max_comments = self.filters.get("comments_per_session", 5)
        
        results = []
        
        # Получаем ключевые слова из профиля аккаунта
        if not keywords:
            profile = self.profile_manager.get_profile(self.account.content_profile)
            if profile:
                keywords = profile.keywords
        
        if not keywords:
            logger.warning("Нет ключевых слов для поиска")
            return results
        
        # Ищем посты
        posts = await self.search_posts(keywords, max_posts=max_comments * 3)
        
        # Фильтруем
        filtered_posts = self._filter_posts(posts)
        
        # Комментируем
        for post in filtered_posts[:max_comments]:
            result = await self.comment_on_post(post)
            results.append(result)
            
            # Пауза между комментариями
            delay_min = self.filters.get("delay_between_comments_min", 30)
            delay_max = self.filters.get("delay_between_comments_max", 90)
            delay = random.uniform(delay_min, delay_max)
            logger.info(f"Пауза {delay:.1f} сек перед следующим комментарием")
            time.sleep(delay)
        
        logger.info(f"Цикл комментирования завершен. Оставлено {len([r for r in results if r.success])} комментариев")
        return results
