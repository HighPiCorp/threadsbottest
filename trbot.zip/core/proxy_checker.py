"""
Proxy Checker Module v3.0
Проверка прокси с определением типа и рекомендациями.
"""

import asyncio
import time
from typing import Dict, Optional, List, Any
from dataclasses import dataclass, field
from enum import Enum
from urllib.parse import urlparse

import aiohttp
import aiohttp_socks
from loguru import logger

from .account_manager import ProxyConfig


class ProxyType(Enum):
    """Тип прокси."""
    RESIDENTIAL = "residential"
    MOBILE = "mobile"
    DATACENTER = "datacenter"
    UNKNOWN = "unknown"


@dataclass
class ProxyCheckResult:
    """Результат проверки прокси."""
    success: bool
    external_ip: Optional[str]
    country: Optional[str]
    city: Optional[str]
    timezone: Optional[str]
    isp: Optional[str]
    is_anonymous: bool
    proxy_type: ProxyType
    proxy_type_warning: bool
    speed_ms: int
    error_message: Optional[str] = None
    headers_leaked: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "external_ip": self.external_ip,
            "country": self.country,
            "city": self.city,
            "timezone": self.timezone,
            "isp": self.isp,
            "is_anonymous": self.is_anonymous,
            "proxy_type": self.proxy_type.value,
            "proxy_type_warning": self.proxy_type_warning,
            "speed_ms": self.speed_ms,
            "error_message": self.error_message,
            "headers_leaked": self.headers_leaked,
        }


class ProxyChecker:
    """
    Проверка прокси-серверов.
    
    Features:
    - Проверка TCP соединения
    - Проверка анонимности (утечка заголовков)
    - Определение геолокации
    - Измерение скорости
    - Определение типа прокси
    """

    IP_CHECK_URLS = [
        "https://httpbin.org/ip",
        "https://api.ipify.org?format=json",
        "https://ipinfo.io/json",
    ]

    ANONYMITY_HEADERS = [
        "x-forwarded-for",
        "x-forwarded-host",
        "x-forwarded-proto",
        "x-real-ip",
        "x-client-ip",
        "x-remote-ip",
        "x-remote-addr",
        "x-originating-ip",
        "cf-connecting-ip",
        "true-client-ip",
    ]

    DATACENTER_KEYWORDS = [
        "datacenter", "data center", "hosting", "server", "cloud",
        "aws", "amazon", "google cloud", "azure", "digitalocean",
        "linode", "vultr", "ovh", "hetzner", "contabo"
    ]
    
    MOBILE_KEYWORDS = [
        "mobile", "cellular", "wireless", "3g", "4g", "5g", "lte",
        "mtn", "airtel", "vodafone", "safaricom", "orange"
    ]
    
    RESIDENTIAL_KEYWORDS = [
        "residential", "broadband", "cable", "dsl", "fiber",
        "telecom", "telefonica", "comcast", "verizon", "att"
    ]

    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    def _build_proxy_url(self, proxy: ProxyConfig) -> str:
        if proxy.username and proxy.password:
            return f"{proxy.protocol}://{proxy.username}:{proxy.password}@{proxy.host}:{proxy.port}"
        return f"{proxy.protocol}://{proxy.host}:{proxy.port}"

    def _detect_proxy_type(self, isp: Optional[str], org: Optional[str]) -> ProxyType:
        text = f"{isp or ''} {org or ''}".lower()
        for keyword in self.MOBILE_KEYWORDS:
            if keyword in text:
                return ProxyType.MOBILE
        for keyword in self.DATACENTER_KEYWORDS:
            if keyword in text:
                return ProxyType.DATACENTER
        for keyword in self.RESIDENTIAL_KEYWORDS:
            if keyword in text:
                return ProxyType.RESIDENTIAL
        return ProxyType.UNKNOWN

    async def test_proxy(self, proxy: ProxyConfig) -> ProxyCheckResult:
        start_time = time.time()
        logger.info(f"Проверка прокси: {proxy.host}:{proxy.port}")

        if not proxy.host or not proxy.port:
            logger.error(f"Некорректная конфигурация прокси: host={proxy.host}, port={proxy.port}")
            return ProxyCheckResult(
                success=False,
                external_ip=None,
                country=None,
                city=None,
                timezone=None,
                isp=None,
                is_anonymous=False,
                proxy_type=ProxyType.UNKNOWN,
                proxy_type_warning=True,
                speed_ms=int((time.time() - start_time) * 1000),
                error_message="Отсутствует host или port прокси"
            )

        try:
            proxy_url = self._build_proxy_url(proxy)
            logger.debug(f"URL прокси: {proxy_url}")

            # Тест 1: Внешний IP
            logger.debug("Проверка внешнего IP...")
            ip_result = await self._check_external_ip(proxy_url)
            if not ip_result["success"]:
                logger.error(f"Не удалось получить внешний IP: {ip_result.get('error')}")
                return ProxyCheckResult(
                    success=False,
                    external_ip=None,
                    country=None,
                    city=None,
                    timezone=None,
                    isp=None,
                    is_anonymous=False,
                    proxy_type=ProxyType.UNKNOWN,
                    proxy_type_warning=True,
                    speed_ms=int((time.time() - start_time) * 1000),
                    error_message=ip_result.get("error", "Неизвестная ошибка"),
                )
            external_ip = ip_result["ip"]
            logger.debug(f"Внешний IP: {external_ip}")

            # Тест 2: Анонимность
            logger.debug("Проверка анонимности...")
            anonymity_result = await self._check_anonymity(proxy_url)

            # Тест 3: Геолокация
            logger.debug("Проверка геолокации...")
            geo_result = await self._check_geolocation(external_ip, proxy_url)

            # Тест 4: Тип прокси
            proxy_type = self._detect_proxy_type(geo_result.get("isp"), geo_result.get("org"))
            proxy_type_warning = proxy_type == ProxyType.DATACENTER

            elapsed_ms = int((time.time() - start_time) * 1000)

            logger.info(f"Проверка прокси завершена успешно за {elapsed_ms} мс")
            return ProxyCheckResult(
                success=True,
                external_ip=external_ip,
                country=geo_result.get("country"),
                city=geo_result.get("city"),
                timezone=geo_result.get("timezone"),
                isp=geo_result.get("isp"),
                is_anonymous=anonymity_result["is_anonymous"],
                proxy_type=proxy_type,
                proxy_type_warning=proxy_type_warning,
                speed_ms=elapsed_ms,
                headers_leaked=anonymity_result.get("leaked_headers", []),
            )

        except Exception as e:
            logger.exception(f"Исключение при проверке прокси: {e}")
            return ProxyCheckResult(
                success=False,
                external_ip=None,
                country=None,
                city=None,
                timezone=None,
                isp=None,
                is_anonymous=False,
                proxy_type=ProxyType.UNKNOWN,
                proxy_type_warning=True,
                speed_ms=int((time.time() - start_time) * 1000),
                error_message=str(e),
            )

    async def _check_external_ip(self, proxy_url: str) -> Dict[str, Any]:
        try:
            connector = aiohttp_socks.ProxyConnector.from_url(proxy_url)
            async with aiohttp.ClientSession(connector=connector) as session:
                for url in self.IP_CHECK_URLS:
                    try:
                        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as response:
                            if response.status == 200:
                                data = await response.json()
                                ip = data.get("ip") or data.get("origin")
                                if ip:
                                    return {"success": True, "ip": ip}
                    except Exception as e:
                        logger.debug(f"URL {url} не сработал: {e}")
                        continue
                return {"success": False, "error": "Все URL проверки IP недоступны"}
        except Exception as e:
            logger.error(f"Ошибка подключения через прокси: {e}")
            return {"success": False, "error": str(e)}

    async def _check_anonymity(self, proxy_url: str) -> Dict[str, Any]:
        leaked_headers = []
        try:
            connector = aiohttp_socks.ProxyConnector.from_url(proxy_url)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(
                    "https://httpbin.org/headers",
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        headers = {k.lower(): v for k, v in data.get("headers", {}).items()}
                        for header in self.ANONYMITY_HEADERS:
                            if header in headers:
                                leaked_headers.append(header)
                                logger.warning(f"Прокси утекает заголовок: {header}")
                        is_anonymous = len(leaked_headers) == 0
                        return {"is_anonymous": is_anonymous, "leaked_headers": leaked_headers}
        except Exception as e:
            logger.error(f"Ошибка проверки анонимности: {e}")
            return {"is_anonymous": False, "leaked_headers": [], "error": str(e)}
        return {"is_anonymous": True, "leaked_headers": []}

    async def _check_geolocation(self, ip: str, proxy_url: str) -> Dict[str, Optional[str]]:
        try:
            connector = aiohttp_socks.ProxyConnector.from_url(proxy_url)
            async with aiohttp.ClientSession(connector=connector) as session:
                # ip-api.com
                try:
                    async with session.get(
                        f"http://ip-api.com/json/{ip}?fields=status,message,country,city,timezone,isp,org",
                        timeout=aiohttp.ClientTimeout(total=10)
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            if data.get("status") == "success":
                                return {
                                    "country": data.get("country"),
                                    "city": data.get("city"),
                                    "timezone": data.get("timezone"),
                                    "isp": data.get("isp"),
                                    "org": data.get("org"),
                                }
                except Exception as e:
                    logger.debug(f"ip-api.com не сработал: {e}")

                # ipinfo.io
                try:
                    async with session.get(
                        "https://ipinfo.io/json",
                        timeout=aiohttp.ClientTimeout(total=10)
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            return {
                                "country": data.get("country"),
                                "city": data.get("city"),
                                "timezone": None,
                                "isp": data.get("org"),
                                "org": data.get("org"),
                            }
                except Exception as e:
                    logger.debug(f"ipinfo.io не сработал: {e}")

        except Exception as e:
            logger.error(f"Ошибка проверки геолокации: {e}")

        return {"country": None, "city": None, "timezone": None, "isp": None, "org": None}

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()


_checker: Optional[ProxyChecker] = None

def get_proxy_checker(timeout: int = 30) -> ProxyChecker:
    global _checker
    if _checker is None:
        _checker = ProxyChecker(timeout)
    return _checker