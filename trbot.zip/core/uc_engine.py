"""
UCEngine - движок автоматизации на базе undetected-chromedriver.
Обеспечивает маскировку автоматизации и стабильную работу с Threads.
"""

import os
import json
import time
import random
import logging
import tempfile
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import (
    TimeoutException, NoSuchElementException,
    ElementNotInteractableException, WebDriverException
)

logger = logging.getLogger(__name__)


@dataclass
class BrowserConfig:
    """Конфигурация браузера."""
    headless: bool = False
    window_width: int = 1280
    window_height: int = 720
    proxy: Optional[str] = None
    user_data_dir: Optional[str] = None
    profile_name: Optional[str] = None


class UCEngine:
    """
    Движок автоматизации на базе undetected-chromedriver.
    """
    
    THREADS_URL = "https://www.threads.net"
    
    def __init__(self, config: BrowserConfig):
        self.config = config
        self.driver: Optional[uc.Chrome] = None
        self.wait: Optional[WebDriverWait] = None
        self.selectors: Dict[str, Any] = {}
        self._load_selectors()
        
    def _load_selectors(self):
        """Загрузка селекторов из конфигурационного файла."""
        try:
            selectors_path = Path(__file__).parent.parent / "config" / "selectors.json"
            with open(selectors_path, 'r', encoding='utf-8') as f:
                self.selectors = json.load(f)
            logger.debug("Селекторы загружены успешно")
        except Exception as e:
            logger.error(f"Ошибка загрузки селекторов: {e}")
            self.selectors = {}
    
    def start(self) -> bool:
        """
        Запуск браузера с маскировкой автоматизации.
        
        Returns:
            True если запуск успешен
        """
        try:
            logger.info("Запуск UCEngine...")
            
            options = uc.ChromeOptions()
            
            # Настройки окна
            options.add_argument(f"--window-size={self.config.window_width},{self.config.window_height}")
            
            # Прокси
            if self.config.proxy:
                options.add_argument(f"--proxy-server={self.config.proxy}")
                logger.info(f"Используется прокси: {self.config.proxy}")
            
            # User Data Directory для сохранения сессии
            if self.config.user_data_dir:
                user_data_path = Path(self.config.user_data_dir)
                user_data_path.mkdir(parents=True, exist_ok=True)
                
                if self.config.profile_name:
                    profile_path = user_data_path / self.config.profile_name
                    profile_path.mkdir(parents=True, exist_ok=True)
                    options.add_argument(f"--user-data-dir={profile_path}")
                else:
                    options.add_argument(f"--user-data-dir={user_data_path}")
            
            # Дополнительные настройки для маскировки
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-infobars")
            options.add_argument("--disable-extensions")
            options.add_argument("--disable-gpu")
            
            # Создание драйвера
            self.driver = uc.Chrome(options=options, headless=self.config.headless)
            self.driver.set_page_load_timeout(30)
            
            self.wait = WebDriverWait(self.driver, 10)
            
            # Маскировка webdriver
            self._mask_webdriver()
            
            logger.info("UCEngine запущен успешно")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка запуска UCEngine: {e}")
            return False
    
    def _mask_webdriver(self):
        """Маскировка признаков автоматизации."""
        try:
            self.driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {
                    "source": """
                        Object.defineProperty(navigator, 'webdriver', {
                            get: () => undefined
                        });
                        Object.defineProperty(navigator, 'plugins', {
                            get: () => [1, 2, 3, 4, 5]
                        });
                        window.chrome = { runtime: {} };
                    """
                }
            )
        except Exception as e:
            logger.warning(f"Ошибка маскировки webdriver: {e}")
    
    def stop(self):
        """Остановка браузера."""
        if self.driver:
            try:
                self.driver.quit()
                logger.info("UCEngine остановлен")
            except Exception as e:
                logger.error(f"Ошибка при остановке: {e}")
            finally:
                self.driver = None
                self.wait = None
    
    def navigate_to(self, url: str):
        """Навигация на указанный URL."""
        if not self.driver:
            raise RuntimeError("Браузер не запущен")
        self.driver.get(url)
        logger.debug(f"Навигация на {url}")
    
    def navigate_to_threads(self):
        """Навигация на Threads."""
        self.navigate_to(self.THREADS_URL)
        time.sleep(random.uniform(2, 4))
    
    def find_element(
        self,
        selector: str,
        by: By = By.CSS_SELECTOR,
        timeout: int = 10,
        clickable: bool = False
    ) -> Optional[Any]:
        """
        Поиск элемента с ожиданием.
        
        Args:
            selector: CSS-селектор или XPath
            by: Тип селектора
            timeout: Таймаут ожидания
            clickable: Ожидать кликабельности
            
        Returns:
            Найденный элемент или None
        """
        if not self.driver:
            return None
            
        try:
            wait = WebDriverWait(self.driver, timeout)
            if clickable:
                return wait.until(EC.element_to_be_clickable((by, selector)))
            else:
                return wait.until(EC.presence_of_element_located((by, selector)))
        except TimeoutException:
            return None
    
    def find_elements(
        self,
        selector: str,
        by: By = By.CSS_SELECTOR
    ) -> List[Any]:
        """Поиск всех элементов по селектору."""
        if not self.driver:
            return []
        try:
            return self.driver.find_elements(by, selector)
        except Exception:
            return []
    
    def click_element(self, element, simulate_human: bool = True) -> bool:
        """
        Клик по элементу с имитацией человеческого поведения.
        
        Args:
            element: Элемент для клика
            simulate_human: Имитировать человеческое поведение
            
        Returns:
            True если клик успешен
        """
        try:
            if simulate_human:
                # Плавное перемещение к элементу
                actions = ActionChains(self.driver)
                actions.move_to_element(element)
                actions.pause(random.uniform(0.1, 0.3))
                actions.click()
                actions.perform()
            else:
                element.click()
            return True
        except Exception as e:
            logger.error(f"Ошибка клика: {e}")
            return False
    
    def type_text(
        self,
        element,
        text: str,
        simulate_human: bool = True,
        typo_probability: float = 0.05
    ) -> bool:
        """
        Ввод текста с имитацией человеческого поведения.
        
        Args:
            element: Поле ввода
            text: Текст для ввода
            simulate_human: Имитировать человеческое поведение
            typo_probability: Вероятность опечатки
            
        Returns:
            True если ввод успешен
        """
        try:
            element.clear()
            
            if not simulate_human:
                element.send_keys(text)
                return True
            
            # Имитация человеческого ввода
            for char in text:
                # Случайная задержка между символами
                time.sleep(random.uniform(0.05, 0.2))
                
                # Имитация опечаток
                if random.random() < typo_probability and char.isalpha():
                    # Вводим неправильный символ
                    wrong_char = random.choice('abcdefghijklmnopqrstuvwxyz')
                    element.send_keys(wrong_char)
                    time.sleep(random.uniform(0.1, 0.3))
                    # Удаляем и вводим правильный
                    element.send_keys(Keys.BACKSPACE)
                    time.sleep(random.uniform(0.05, 0.15))
                
                element.send_keys(char)
            
            return True
            
        except Exception as e:
            logger.error(f"Ошибка ввода текста: {e}")
            return False
    
    def simulate_reading(self, min_time: float = 3, max_time: float = 10):
        """Имитация чтения контента."""
        read_time = random.uniform(min_time, max_time)
        logger.debug(f"Имитация чтения: {read_time:.1f} сек")
        
        # Небольшая пауза в начале
        time.sleep(random.uniform(1, 3))
        
        # Плавный скролл
        if self.driver:
            scroll_amount = random.randint(100, 500)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
        
        # Основное время чтения
        time.sleep(read_time)
    
    def scroll_to_element(self, element):
        """Прокрутка к элементу."""
        try:
            self.driver.execute_script(
                "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});",
                element
            )
            time.sleep(random.uniform(0.5, 1.5))
        except Exception as e:
            logger.warning(f"Ошибка прокрутки: {e}")
    
    def get_page_source(self) -> str:
        """Получение HTML-кода страницы."""
        if self.driver:
            return self.driver.page_source
        return ""
    
    def save_screenshot(self, filepath: str) -> bool:
        """Сохранение скриншота."""
        try:
            if self.driver:
                self.driver.save_screenshot(filepath)
                return True
        except Exception as e:
            logger.error(f"Ошибка сохранения скриншота: {e}")
        return False
    
    def execute_script(self, script: str, *args):
        """Выполнение JavaScript."""
        if self.driver:
            return self.driver.execute_script(script, *args)
        return None
    
    def is_logged_in(self) -> bool:
        """Проверка авторизации в Threads."""
        try:
            # Проверяем наличие элемента профиля или кнопки создания поста
            profile_indicator = self.find_element(
                self.selectors.get("navigation", {}).get("profile_tab", ""),
                timeout=5
            )
            return profile_indicator is not None
        except Exception:
            return False
    
    def get_current_url(self) -> str:
        """Получение текущего URL."""
        if self.driver:
            return self.driver.current_url
        return ""
    
    def __enter__(self):
        """Контекстный менеджер - вход."""
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Контекстный менеджер - выход."""
        self.stop()
