"""
Account Manager Module v3.0
Управление аккаунтами с шифрованием и поддержкой контентных профилей.
"""

import json
import os
import base64
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict, field
from datetime import datetime
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from loguru import logger


@dataclass
class ProxyConfig:
    """Конфигурация прокси для аккаунта."""
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    protocol: str = "http"  # http, https, socks4, socks5

    def to_url(self) -> str:
        """Конвертация в URL формат для Chrome."""
        if self.username and self.password:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProxyConfig":
        return cls(**data)


@dataclass
class Account:
    """Данные аккаунта Threads."""
    id: int
    username: str
    password: str
    proxy: Optional[ProxyConfig] = None
    content_profile: str = "primary"  # primary, latam, africa
    user_agent: Optional[str] = None
    timezone: Optional[str] = None
    language: Optional[str] = None
    notes: Optional[str] = None
    is_active: bool = True
    created_at: Optional[str] = None
    last_used: Optional[str] = None
    session_valid: bool = False  # Статус сессии

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        if self.proxy:
            data['proxy'] = self.proxy.to_dict()
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Account":
        if data.get('proxy'):
            data['proxy'] = ProxyConfig.from_dict(data['proxy'])
        # Фильтруем только существующие поля
        valid_fields = cls.__dataclass_fields__.keys()
        filtered_data = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered_data)


class AccountManager:
    """
    Менеджер аккаунтов с Fernet шифрованием.
    
    Features:
    - Безопасное хранение паролей с использованием Fernet
    - Защита мастер-паролем
    - CRUD операции с аккаунтами
    - Управление прокси
    - Привязка контентных профилей
    - Мониторинг статуса сессий
    """

    def __init__(self, config_dir: str = None):
        # Используем Documents/ThreadsBot как основную папку
        if config_dir is None:
            base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
        else:
            base_dir = Path(config_dir)
        
        self.config_dir = base_dir
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # Файлы данных
        self.accounts_file = self.config_dir / "accounts.dat"
        self.salt_file = self.config_dir / ".salt"
        self.cookies_dir = self.config_dir / "cookies"
        self.cookies_dir.mkdir(exist_ok=True)

        self._fernet: Optional[Fernet] = None
        self._accounts: Dict[int, Account] = {}
        
        logger.info(f"AccountManager инициализирован. Директория: {self.config_dir.absolute()}")

    def _generate_salt(self) -> bytes:
        """Генерация или загрузка существующей соли."""
        if self.salt_file.exists():
            return base64.urlsafe_b64decode(self.salt_file.read_bytes())

        salt = os.urandom(16)
        self.salt_file.write_bytes(base64.urlsafe_b64encode(salt))
        # Скрыть файл на Windows
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(self.salt_file), 0x02)
        except Exception:
            pass
        return salt

    def _derive_key(self, master_password: str) -> bytes:
        """Получение ключа шифрования из мастер-пароля."""
        salt = self._generate_salt()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(master_password.encode()))
        return key

    def initialize(self, master_password: str) -> bool:
        """
        Инициализация менеджера аккаунтов с мастер-паролем.

        Args:
            master_password: Мастер-пароль для шифрования

        Returns:
            True если успешно, False если неверный пароль для существующих данных
        """
        try:
            key = self._derive_key(master_password)
            self._fernet = Fernet(key)

            if self.accounts_file.exists():
                return self._load_accounts()

            logger.info("AccountManager инициализирован с новым мастер-паролем")
            return True

        except Exception as e:
            logger.error(f"Ошибка инициализации AccountManager: {e}")
            return False

    def _load_accounts(self) -> bool:
        """Загрузка и расшифровка аккаунтов из файла."""
        try:
            encrypted_data = self.accounts_file.read_bytes()
            decrypted_data = self._fernet.decrypt(encrypted_data)
            accounts_data = json.loads(decrypted_data.decode())

            self._accounts = {
                int(k): Account.from_dict(v)
                for k, v in accounts_data.items()
            }

            logger.info(f"Загружено {len(self._accounts)} аккаунтов")
            return True

        except Exception as e:
            logger.error(f"Ошибка загрузки аккаунтов - неверный пароль или поврежденный файл: {e}")
            return False

    def _save_accounts(self) -> bool:
        """Шифрование и сохранение аккаунтов в файл."""
        try:
            accounts_data = {
                str(k): v.to_dict()
                for k, v in self._accounts.items()
            }
            json_data = json.dumps(accounts_data, indent=2, ensure_ascii=False)
            encrypted_data = self._fernet.encrypt(json_data.encode())

            self.accounts_file.write_bytes(encrypted_data)
            logger.info(f"Сохранено {len(self._accounts)} аккаунтов")
            return True

        except PermissionError as e:
            logger.error(f"Ошибка доступа при сохранении аккаунтов: {e}")
            return False
        except Exception as e:
            logger.error(f"Ошибка сохранения аккаунтов: {e}")
            return False

    def add_account(self, account: Account) -> bool:
        """Добавление нового аккаунта."""
        if not self._fernet:
            logger.error("AccountManager не инициализирован")
            return False

        # Автоматическое назначение ID
        if account.id == 0 or account.id in self._accounts:
            account.id = max(self._accounts.keys(), default=0) + 1

        account.created_at = datetime.now().isoformat()
        self._accounts[account.id] = account
        success = self._save_accounts()

        if success:
            logger.info(f"Добавлен аккаунт {account.id} ({account.username})")

        return success

    def update_account(self, account_id: int, **kwargs) -> bool:
        """Обновление полей аккаунта."""
        if account_id not in self._accounts:
            logger.error(f"Аккаунт {account_id} не найден")
            return False

        account = self._accounts[account_id]

        for key, value in kwargs.items():
            if hasattr(account, key):
                setattr(account, key, value)

        success = self._save_accounts()

        if success:
            logger.info(f"Обновлен аккаунт {account_id}")

        return success

    def delete_account(self, account_id: int) -> bool:
        """Удаление аккаунта."""
        if account_id not in self._accounts:
            logger.error(f"Аккаунт {account_id} не найден")
            return False

        del self._accounts[account_id]
        success = self._save_accounts()

        if success:
            logger.info(f"Удален аккаунт {account_id}")

        return success

    def get_account(self, account_id: int) -> Optional[Account]:
        """Получение аккаунта по ID."""
        return self._accounts.get(account_id)

    def get_all_accounts(self) -> List[Account]:
        """Получение всех аккаунтов."""
        return list(self._accounts.values())

    def get_active_accounts(self) -> List[Account]:
        """Получение только активных аккаунтов."""
        return [a for a in self._accounts.values() if a.is_active]

    def is_initialized(self) -> bool:
        """Проверка инициализации менеджера."""
        return self._fernet is not None

    def has_accounts(self) -> bool:
        """Проверка наличия аккаунтов."""
        return len(self._accounts) > 0

    def change_master_password(self, old_password: str, new_password: str) -> bool:
        """Смена мастер-пароля и перешифровка данных."""
        # Проверка старого пароля
        old_key = self._derive_key(old_password)
        old_fernet = Fernet(old_key)

        try:
            encrypted_data = self.accounts_file.read_bytes()
            old_fernet.decrypt(encrypted_data)
        except Exception:
            logger.error("Неверный старый пароль")
            return False

        # Генерация нового ключа и перешифровка
        new_key = self._derive_key(new_password)
        self._fernet = Fernet(new_key)

        return self._save_accounts()
    
    def update_session_status(self, account_id: int, is_valid: bool) -> bool:
        """
        Обновление статуса сессии аккаунта.
        
        Args:
            account_id: ID аккаунта
            is_valid: Валидна ли сессия
            
        Returns:
            True если обновление успешно
        """
        if account_id not in self._accounts:
            return False
        
        self._accounts[account_id].session_valid = is_valid
        return self._save_accounts()
    
    def save_cookies(self, account_id: int, cookies: List[Dict[str, Any]]) -> bool:
        """Сохранение cookies для аккаунта."""
        try:
            cookies_file = self.cookies_dir / f"account_{account_id}.json"
            with open(cookies_file, 'w', encoding='utf-8') as f:
                json.dump(cookies, f)
            return True
        except Exception as e:
            logger.error(f"Ошибка сохранения cookies: {e}")
            return False
    
    def load_cookies(self, account_id: int) -> List[Dict[str, Any]]:
        """Загрузка cookies для аккаунта."""
        try:
            cookies_file = self.cookies_dir / f"account_{account_id}.json"
            if cookies_file.exists():
                with open(cookies_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Ошибка загрузки cookies: {e}")
        return []
    
    def has_valid_cookies(self, account_id: int) -> bool:
        """Проверка наличия валидных cookies для аккаунта."""
        cookies_file = self.cookies_dir / f"account_{account_id}.json"
        return cookies_file.exists()


# Singleton instance
_account_manager: Optional[AccountManager] = None


def get_account_manager(config_dir: str = None) -> AccountManager:
    """Получение или создание синглтона AccountManager."""
    global _account_manager
    if _account_manager is None:
        _account_manager = AccountManager(config_dir)
    return _account_manager
