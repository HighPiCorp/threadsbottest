"""
Scheduler Module v3.0
Планировщик задач на базе APScheduler.
"""

import asyncio
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json
from pathlib import Path
import os
from loguru import logger

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.events import EVENT_JOB_EXECUTED, EVENT_JOB_ERROR


class TaskType(Enum):
    """Типы запланированных задач."""
    POST = "post"
    COMMENT = "comment"
    PROXY_CHECK = "proxy_check"


@dataclass
class TaskResult:
    """Результат выполнения задачи."""
    task_id: str
    task_type: TaskType
    account_id: int
    success: bool
    message: str
    executed_at: datetime
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ScheduleConfig:
    """Конфигурация расписания."""
    # Расписание постинга
    post_times: List[str] = field(default_factory=lambda: ["10:00", "15:00", "20:00"])
    post_topic: str = ""
    post_enabled: bool = False
    
    # Расписание комментирования
    comment_interval_hours: int = 3
    comment_enabled: bool = False
    
    # Общие настройки
    timezone: str = "UTC"


class BotScheduler:
    """
    Планировщик задач бота на базе APScheduler.
    
    Features:
    - Планирование постинга по времени
    - Планирование комментирования с интервалом
    - Работа в фоновом режиме
    - Graceful shutdown
    """
    
    def __init__(self, config_path: str = None):
        """
        Инициализация планировщика.
        
        Args:
            config_path: Путь к файлу конфигурации расписаний
        """
        if config_path is None:
            base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
            base_dir.mkdir(parents=True, exist_ok=True)
            self.config_path = base_dir / "schedules.json"
        else:
            self.config_path = Path(config_path)
        
        self.scheduler = BackgroundScheduler()
        self._handlers: Dict[TaskType, Callable] = {}
        self._configs: Dict[int, ScheduleConfig] = {}
        self._results: List[TaskResult] = []
        self._is_running = False
        
        # Загрузка конфигураций
        self._load_configs()
        
        # Добавление слушателей событий
        self.scheduler.add_listener(
            self._on_job_executed,
            EVENT_JOB_EXECUTED | EVENT_JOB_ERROR
        )
        
        logger.info("BotScheduler инициализирован")
    
    def _load_configs(self):
        """Загрузка конфигураций расписаний из файла."""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                for account_id_str, config_data in data.items():
                    account_id = int(account_id_str)
                    self._configs[account_id] = ScheduleConfig(**config_data)
                
                logger.info(f"Загружено {len(self._configs)} конфигураций расписаний")
            except Exception as e:
                logger.error(f"Ошибка загрузки конфигураций: {e}")
    
    def _save_configs(self):
        """Сохранение конфигураций расписаний в файл."""
        try:
            data = {}
            for account_id, config in self._configs.items():
                data[str(account_id)] = {
                    "post_times": config.post_times,
                    "post_topic": config.post_topic,
                    "post_enabled": config.post_enabled,
                    "comment_interval_hours": config.comment_interval_hours,
                    "comment_enabled": config.comment_enabled,
                    "timezone": config.timezone,
                }
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.debug("Конфигурации расписаний сохранены")
        except Exception as e:
            logger.error(f"Ошибка сохранения конфигураций: {e}")
    
    def register_handler(self, task_type: TaskType, handler: Callable):
        """
        Регистрация обработчика для типа задачи.
        
        Args:
            task_type: Тип задачи
            handler: Функция-обработчик
        """
        self._handlers[task_type] = handler
        logger.debug(f"Зарегистрирован обработчик для {task_type.value}")
    
    def setup_schedule(self, account_id: int, config: ScheduleConfig):
        """
        Настройка расписания для аккаунта.
        
        Args:
            account_id: ID аккаунта
            config: Конфигурация расписания
        """
        # Удаляем существующие задачи для этого аккаунта
        self._remove_account_jobs(account_id)
        
        # Сохраняем конфигурацию
        self._configs[account_id] = config
        self._save_configs()
        
        # Настройка постинга
        if config.post_enabled and config.post_times:
            for time_str in config.post_times:
                try:
                    hour, minute = map(int, time_str.split(':'))
                    job_id = f"post_{account_id}_{time_str.replace(':', '')}"
                    
                    self.scheduler.add_job(
                        self._execute_task,
                        trigger=CronTrigger(hour=hour, minute=minute, timezone=config.timezone),
                        id=job_id,
                        args=[TaskType.POST, account_id],
                        replace_existing=True,
                        misfire_grace_time=3600
                    )
                    
                    logger.info(f"Запланирован постинг в {time_str} для аккаунта {account_id}")
                except ValueError:
                    logger.error(f"Некорректное время: {time_str}")
        
        # Настройка комментирования
        if config.comment_enabled:
            job_id = f"comment_{account_id}"
            
            self.scheduler.add_job(
                self._execute_task,
                trigger=IntervalTrigger(hours=config.comment_interval_hours),
                id=job_id,
                args=[TaskType.COMMENT, account_id],
                replace_existing=True,
                misfire_grace_time=1800
            )
            
            logger.info(f"Запланировано комментирование каждые {config.comment_interval_hours}ч для аккаунта {account_id}")
    
    def _remove_account_jobs(self, account_id: int):
        """Удаление всех задач для аккаунта."""
        for job in self.scheduler.get_jobs():
            if job.id.startswith(f"post_{account_id}_") or job.id.startswith(f"comment_{account_id}"):
                self.scheduler.remove_job(job.id)
    
    def _execute_task(self, task_type: TaskType, account_id: int):
        """
        Выполнение запланированной задачи.
        
        Args:
            task_type: Тип задачи
            account_id: ID аккаунта
        """
        task_id = f"{task_type.value}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        logger.info(f"Выполнение задачи {task_type.value} для аккаунта {account_id}")
        
        handler = self._handlers.get(task_type)
        if not handler:
            logger.error(f"Нет обработчика для {task_type.value}")
            return
        
        try:
            # Получаем конфигурацию
            config = self._configs.get(account_id, ScheduleConfig())
            
            # Выполняем обработчик
            if asyncio.iscoroutinefunction(handler):
                # Для асинхронных функций создаем новый event loop
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                result = loop.run_until_complete(handler(account_id, config))
                loop.close()
            else:
                result = handler(account_id, config)
            
            task_result = TaskResult(
                task_id=task_id,
                task_type=task_type,
                account_id=account_id,
                success=result.get("success", False),
                message=result.get("message", ""),
                executed_at=datetime.now(),
                details=result.get("details", {})
            )
            
        except Exception as e:
            logger.exception(f"Ошибка выполнения задачи {task_type.value}: {e}")
            task_result = TaskResult(
                task_id=task_id,
                task_type=task_type,
                account_id=account_id,
                success=False,
                message=str(e),
                executed_at=datetime.now()
            )
        
        self._results.append(task_result)
        
        # Храним только последние 100 результатов
        if len(self._results) > 100:
            self._results = self._results[-100:]
    
    def _on_job_executed(self, event):
        """Обработчик событий выполнения задач."""
        if event.exception:
            logger.error(f"Задача {event.job_id} завершилась с ошибкой: {event.exception}")
        else:
            logger.debug(f"Задача {event.job_id} выполнена успешно")
    
    def start(self):
        """Запуск планировщика."""
        if not self._is_running:
            self.scheduler.start()
            self._is_running = True
            logger.info("Планировщик запущен")
    
    def stop(self):
        """Остановка планировщика (graceful shutdown)."""
        if self._is_running:
            self.scheduler.shutdown(wait=True)
            self._is_running = False
            logger.info("Планировщик остановлен")
    
    def pause(self):
        """Пауза планировщика."""
        self.scheduler.pause()
        logger.info("Планировщик на паузе")
    
    def resume(self):
        """Возобновление работы планировщика."""
        self.scheduler.resume()
        logger.info("Планировщик возобновлен")
    
    def get_next_run_times(self, account_id: Optional[int] = None) -> Dict[str, Optional[datetime]]:
        """
        Получение времени следующего запуска задач.
        
        Args:
            account_id: ID аккаунта (опционально)
            
        Returns:
            Словарь {job_id: next_run_time}
        """
        times = {}
        for job in self.scheduler.get_jobs():
            if account_id is None or f"_{account_id}_" in job.id or job.id.endswith(f"_{account_id}"):
                times[job.id] = job.next_run_time
        return times
    
    def get_results(
        self,
        account_id: Optional[int] = None,
        task_type: Optional[TaskType] = None,
        limit: int = 50
    ) -> List[TaskResult]:
        """
        Получение результатов выполнения задач.
        
        Args:
            account_id: Фильтр по аккаунту
            task_type: Фильтр по типу задачи
            limit: Максимальное количество
            
        Returns:
            Список результатов
        """
        results = self._results
        
        if account_id is not None:
            results = [r for r in results if r.account_id == account_id]
        
        if task_type is not None:
            results = [r for r in results if r.task_type == task_type]
        
        return results[-limit:]
    
    def get_config(self, account_id: int) -> Optional[ScheduleConfig]:
        """Получение конфигурации расписания для аккаунта."""
        return self._configs.get(account_id)
    
    def is_running(self) -> bool:
        """Проверка, запущен ли планировщик."""
        return self._is_running


# Singleton instance
_scheduler: Optional[BotScheduler] = None


def get_scheduler(config_path: str = None) -> BotScheduler:
    """
    Получение синглтона BotScheduler.
    
    Args:
        config_path: Путь к файлу конфигурации
        
    Returns:
        Экземпляр BotScheduler
    """
    global _scheduler
    if _scheduler is None:
        _scheduler = BotScheduler(config_path)
    return _scheduler
