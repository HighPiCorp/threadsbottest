"""
OpenRouter API Client для генерации контента v3.0.
Поддерживает актуальные бесплатные модели (март 2026).
"""

import asyncio
import aiohttp
import json
import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from datetime import datetime

from .content_profiles import ContentProfile

logger = logging.getLogger(__name__)


@dataclass
class ModelConfig:
    """Конфигурация AI-модели."""
    name: str
    priority: int
    max_retries: int = 2
    timeout: int = 60


@dataclass
class GenerationResult:
    """Результат генерации контента."""
    success: bool
    content: str
    model_used: str
    error: Optional[str] = None
    tokens_used: Optional[int] = None


# Актуальные бесплатные модели OpenRouter (март 2026)
DEFAULT_MODELS = [
    ModelConfig("nvidia/nemotron-3-super-120b-a12b:free", 1, max_retries=2),
    ModelConfig("google/gemini-2.0-flash-exp:free", 2, max_retries=2),
    ModelConfig("qwen/qwen-72b-chat:free", 3, max_retries=2),
    ModelConfig("microsoft/phi-4:free", 4, max_retries=2),
    ModelConfig("openrouter/auto", 5, max_retries=1),
]


class OpenRouterClient:
    """
    Клиент для работы с OpenRouter API.
    Реализует многоуровневую стратегию fallback.
    """
    
    BASE_URL = "https://openrouter.ai/api/v1"
    
    def __init__(
        self,
        api_key: str,
        models: Optional[List[ModelConfig]] = None,
        temperature: float = 0.7,
        max_tokens: int = 500
    ):
        self.api_key = api_key
        self.models = models or DEFAULT_MODELS.copy()
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Статистика
        self.requests_made = 0
        self.cache_hits = 0
        self.fallbacks_used = 0
        
        logger.info(f"OpenRouterClient инициализирован с {len(self.models)} моделями")
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Получение или создание сессии aiohttp."""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://threadsbot.local",
                    "X-Title": "Threads Automation Bot v3.0"
                },
                timeout=aiohttp.ClientTimeout(total=120)
            )
        return self.session
    
    async def get_available_models(self) -> List[Dict[str, Any]]:
        """
        Динамическое получение списка доступных моделей через API.
        
        Returns:
            Список доступных моделей с метаданными.
        """
        try:
            session = await self._get_session()
            async with session.get(f"{self.BASE_URL}/models") as response:
                if response.status == 200:
                    data = await response.json()
                    models = data.get("data", [])
                    # Фильтруем только бесплатные модели
                    free_models = [m for m in models if ":free" in m.get("id", "")]
                    logger.info(f"Получено {len(free_models)} бесплатных моделей")
                    return free_models
                else:
                    logger.error(f"Ошибка получения моделей: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Исключение при получении моделей: {e}")
            return []
    
    def _sort_models_by_priority(self) -> List[ModelConfig]:
        """Сортировка моделей по приоритету."""
        return sorted(self.models, key=lambda m: m.priority)
    
    async def generate_content(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None
    ) -> GenerationResult:
        """
        Генерация контента с fallback на доступные модели.
        
        Args:
            system_prompt: Системный промпт
            user_prompt: Пользовательский промпт
            temperature: Температура генерации (опционально)
            max_tokens: Максимальное количество токенов (опционально)
            
        Returns:
            Результат генерации
        """
        models_to_try = self._sort_models_by_priority()
        temp = temperature or self.temperature
        tokens = max_tokens or self.max_tokens
        
        for model in models_to_try:
            for attempt in range(model.max_retries):
                try:
                    logger.info(f"Попытка генерации с моделью {model.name} (попытка {attempt + 1})")
                    
                    result = await self._try_generate(
                        model=model.name,
                        system_prompt=system_prompt,
                        user_prompt=user_prompt,
                        temperature=temp,
                        max_tokens=tokens
                    )
                    
                    if result.success:
                        logger.info(f"Успешная генерация с моделью {model.name}")
                        self.requests_made += 1
                        return result
                    
                    if attempt < model.max_retries - 1:
                        await asyncio.sleep(2 ** attempt)
                        
                except Exception as e:
                    logger.error(f"Ошибка генерации с {model.name}: {e}")
                    if attempt < model.max_retries - 1:
                        await asyncio.sleep(2 ** attempt)
            
            # Переключаемся на следующую модель
            self.fallbacks_used += 1
        
        return GenerationResult(
            success=False,
            content="",
            model_used="",
            error="Все модели исчерпаны"
        )
    
    async def _try_generate(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int
    ) -> GenerationResult:
        """Одна попытка генерации."""
        session = await self._get_session()
        
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        try:
            async with session.post(
                f"{self.BASE_URL}/chat/completions",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as response:
                
                if response.status != 200:
                    error_text = await response.text()
                    return GenerationResult(
                        success=False,
                        content="",
                        model_used=model,
                        error=f"HTTP {response.status}: {error_text}"
                    )
                
                data = await response.json()
                
                if "error" in data:
                    return GenerationResult(
                        success=False,
                        content="",
                        model_used=model,
                        error=data["error"].get("message", "Unknown error")
                    )
                
                choices = data.get("choices", [])
                if not choices:
                    return GenerationResult(
                        success=False,
                        content="",
                        model_used=model,
                        error="Нет choices в ответе"
                    )
                
                content = choices[0].get("message", {}).get("content")
                if content is None:
                    return GenerationResult(
                        success=False,
                        content="",
                        model_used=model,
                        error="Модель вернула пустой ответ"
                    )
                
                usage = data.get("usage", {})
                
                return GenerationResult(
                    success=True,
                    content=content.strip(),
                    model_used=model,
                    tokens_used=usage.get("total_tokens")
                )
        except asyncio.TimeoutError:
            return GenerationResult(
                success=False,
                content="",
                model_used=model,
                error="Таймаут запроса"
            )
        except Exception as e:
            return GenerationResult(
                success=False,
                content="",
                model_used=model,
                error=str(e)
            )
    
    async def generate_post(
        self,
        profile: ContentProfile,
        topic: str
    ) -> GenerationResult:
        """
        Генерация поста для указанного профиля.
        
        Args:
            profile: Контентный профиль (объект ContentProfile)
            topic: Тема поста
            
        Returns:
            Результат генерации
        """
        system_prompt = profile.system_prompt
        post_template = profile.post_prompt_template
        user_prompt = post_template.format(topic=topic)
        
        return await self.generate_content(system_prompt, user_prompt)
    
    async def generate_comment(
        self,
        profile: ContentProfile,
        post_content: str,
        target_language: Optional[str] = None
    ) -> GenerationResult:
        """
        Генерация комментария для указанного профиля.
        
        Args:
            profile: Контентный профиль (объект ContentProfile)
            post_content: Содержимое поста
            target_language: Целевой язык (опционально)
            
        Returns:
            Результат генерации
        """
        system_prompt = profile.system_prompt
        comment_template = profile.comment_prompt_template
        user_prompt = comment_template.format(post_content=post_content)
        
        if target_language:
            user_prompt += f"\n\nLanguage: {target_language}"
        
        return await self.generate_content(system_prompt, user_prompt)
    
    async def test_api_key(self) -> Dict[str, Any]:
        """
        Проверка валидности API ключа.
        
        Returns:
            Словарь с результатом проверки
        """
        try:
            session = await self._get_session()
            async with session.get(f"{self.BASE_URL}/auth/key") as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "success": True,
                        "data": data.get("data", {}),
                        "message": "API ключ валиден"
                    }
                elif response.status == 401:
                    return {
                        "success": False,
                        "data": {},
                        "message": "Неверный API ключ"
                    }
                else:
                    return {
                        "success": False,
                        "data": {},
                        "message": f"Неожиданный ответ: {response.status}"
                    }
        except Exception as e:
            logger.error(f"Ошибка проверки API ключа: {e}")
            return {
                "success": False,
                "data": {},
                "message": str(e)
            }
    
    def get_stats(self) -> Dict[str, Any]:
        """Получение статистики использования."""
        return {
            "requests_made": self.requests_made,
            "cache_hits": self.cache_hits,
            "fallbacks_used": self.fallbacks_used,
        }
    
    async def close(self):
        """Закрытие сессии."""
        if self.session and not self.session.closed:
            await self.session.close()
            self.session = None


# Singleton instance
_client_instance: Optional[OpenRouterClient] = None
_client_key: Optional[str] = None


def get_openrouter_client(api_key: Optional[str] = None, **kwargs) -> Optional[OpenRouterClient]:
    """
    Получение или создание синглтона OpenRouterClient.
    
    Args:
        api_key: API ключ OpenRouter (опционально)
        **kwargs: Дополнительные параметры
        
    Returns:
        Экземпляр OpenRouterClient или None
    """
    global _client_instance, _client_key
    
    if api_key is None:
        return _client_instance
    
    # Если ключ изменился или клиент ещё не создан, создаём новый
    if _client_instance is None or _client_key != api_key:
        _client_instance = OpenRouterClient(api_key, **kwargs)
        _client_key = api_key
        logger.info(f"Создан новый OpenRouter клиент с ключом: {api_key[:8]}...")
    
    return _client_instance