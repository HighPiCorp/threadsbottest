"""
Threads Automation Bot v3.0 - Multi-Account Mastery Edition
Точка входа для CLI и GUI режимов.
"""

import argparse
import asyncio
import sys
import os
from pathlib import Path

# Добавляем корень проекта в путь
sys.path.insert(0, str(Path(__file__).parent))

from loguru import logger

# Настройка логирования
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
    level="INFO"
)

# Создаем директорию для логов
logs_dir = Path.home() / "Documents" / "ThreadsBot" / "logs"
logs_dir.mkdir(parents=True, exist_ok=True)

logger.add(
    logs_dir / "bot.log",
    rotation="10 MB",
    retention="7 days",
    level="DEBUG"
)


def setup_environment():
    """Настройка окружения."""
    # Создаем необходимые директории
    base_dir = Path.home() / "Documents" / "ThreadsBot"
    (base_dir / "config").mkdir(parents=True, exist_ok=True)
    (base_dir / "profiles").mkdir(parents=True, exist_ok=True)
    (base_dir / "logs").mkdir(parents=True, exist_ok=True)
    (base_dir / "cookies").mkdir(parents=True, exist_ok=True)


async def test_openrouter(api_key: str):
    """Тестирование подключения к OpenRouter."""
    from core import get_openrouter_client
    
    logger.info("Тестирование подключения к OpenRouter...")
    
    client = get_openrouter_client(api_key)
    result = await client.test_api_key()
    
    if result["success"]:
        logger.info(f"✅ API ключ валиден!")
        logger.info(f"Данные: {result['data']}")
        
        # Получаем список моделей
        models = await client.get_available_models()
        free_models = [m for m in models if ":free" in m.get("id", "")]
        logger.info(f"Доступно бесплатных моделей: {len(free_models)}")
        
        for model in free_models[:5]:
            logger.info(f"  - {model.get('id')}")
    else:
        logger.error(f"❌ Ошибка: {result['message']}")


async def generate_content(api_key: str, topic: str, profile_id: str = "primary"):
    """Генерация контента без публикации."""
    from core import get_openrouter_client, get_profile_manager
    
    logger.info(f"Генерация контента на тему: {topic}")
    
    client = get_openrouter_client(api_key)
    profile_manager = get_profile_manager()
    profile = profile_manager.get_profile(profile_id)
    
    if not profile:
        logger.error(f"Профиль {profile_id} не найден")
        return
    
    result = await client.generate_post(profile, topic)
    
    if result.success:
        logger.info("✅ Контент сгенерирован:")
        logger.info("-" * 40)
        logger.info(result.content)
        logger.info("-" * 40)
        logger.info(f"Модель: {result.model_used}")
    else:
        logger.error(f"❌ Ошибка генерации: {result.error}")


async def list_accounts():
    """Вывод списка аккаунтов."""
    from core import get_account_manager, get_profile_manager
    
    account_manager = get_account_manager()
    profile_manager = get_profile_manager()
    
    accounts = account_manager.get_all_accounts()
    
    if not accounts:
        logger.info("Аккаунты не найдены")
        return
    
    logger.info(f"Найдено {len(accounts)} аккаунтов:")
    logger.info("-" * 80)
    
    for account in accounts:
        profile = profile_manager.get_profile(account.content_profile)
        profile_name = profile.name if profile else account.content_profile
        
        proxy_status = "✅" if account.proxy else "❌"
        session_status = "✅" if account.session_valid else "❌"
        active_status = "✅" if account.is_active else "❌"
        
        logger.info(f"ID: {account.id}")
        logger.info(f"  Имя пользователя: {account.username}")
        logger.info(f"  Профиль: {profile_name}")
        logger.info(f"  Прокси: {proxy_status}")
        logger.info(f"  Сессия: {session_status}")
        logger.info(f"  Активен: {active_status}")
        logger.info("-" * 80)


async def test_proxy(account_id: int):
    """Тестирование прокси для аккаунта."""
    from core import get_account_manager, get_proxy_checker
    
    account_manager = get_account_manager()
    account = account_manager.get_account(account_id)
    
    if not account:
        logger.error(f"Аккаунт {account_id} не найден")
        return
    
    if not account.proxy:
        logger.warning(f"Для аккаунта {account_id} не настроен прокси")
        return
    
    logger.info(f"Проверка прокси для аккаунта {account.username}...")
    
    checker = get_proxy_checker()
    result = await checker.test_proxy(account.proxy)
    
    if result.success:
        logger.info("✅ Прокси работает!")
        logger.info(f"  IP: {result.external_ip}")
        logger.info(f"  Местоположение: {result.city}, {result.country}")
        logger.info(f"  ISP: {result.isp}")
        logger.info(f"  Тип: {result.proxy_type.value}")
        logger.info(f"  Анонимный: {'Да' if result.is_anonymous else 'Нет'}")
        logger.info(f"  Скорость: {result.speed_ms} мс")
        
        if result.proxy_type_warning:
            logger.warning("⚠️ Предупреждение: дата-центровые прокси не рекомендуются для Threads!")
    else:
        logger.error(f"❌ Ошибка: {result.error_message}")


def run_gui():
    """Запуск GUI режима."""
    try:
        from gui.main_window import main as gui_main
        gui_main()
    except ImportError as e:
        logger.error(f"GUI недоступен: {e}")
        logger.info("Установите PyQt6: pip install PyQt6")
        sys.exit(1)


async def main():
    """Главная точка входа."""
    parser = argparse.ArgumentParser(
        description="Threads Automation Bot v3.0 - Multi-Account Mastery Edition",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  %(prog)s --gui                              Запустить GUI режим
  %(prog)s --list-accounts                    Показать список аккаунтов
  %(prog)s --test-proxy 1                     Проверить прокси для аккаунта 1
  %(prog)s --test-openrouter <key>            Проверить API ключ OpenRouter
  %(prog)s --generate "AI Marketing"          Сгенерировать контент
        """
    )
    
    parser.add_argument("--gui", action="store_true", help="Запустить GUI режим")
    parser.add_argument("--list-accounts", action="store_true", help="Показать список аккаунтов")
    parser.add_argument("--test-proxy", type=int, metavar="ID", help="Проверить прокси для аккаунта")
    parser.add_argument("--test-openrouter", type=str, metavar="KEY", help="Проверить API ключ OpenRouter")
    parser.add_argument("--generate", type=str, metavar="TOPIC", help="Сгенерировать контент на тему")
    parser.add_argument("--profile", type=str, default="primary", help="ID профиля контента (primary/latam/africa)")
    parser.add_argument("--openrouter-key", type=str, help="OpenRouter API ключ")
    
    args = parser.parse_args()
    
    # Настройка окружения
    setup_environment()
    
    # GUI режим
    if args.gui:
        run_gui()
        return
    
    # Если нет аргументов - показываем справку
    if len(sys.argv) == 1:
        parser.print_help()
        return
    
    # Список аккаунтов
    if args.list_accounts:
        await list_accounts()
        return
    
    # Тест прокси
    if args.test_proxy:
        await test_proxy(args.test_proxy)
        return
    
    # Тест OpenRouter
    if args.test_openrouter:
        await test_openrouter(args.test_openrouter)
        return
    
    # Генерация контента
    if args.generate:
        api_key = args.openrouter_key or os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            logger.error("Укажите API ключ через --openrouter-key или переменную окружения OPENROUTER_API_KEY")
            sys.exit(1)
        await generate_content(api_key, args.generate, args.profile)
        return


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Прервано пользователем")
        sys.exit(130)
    except Exception as e:
        logger.exception("Критическая ошибка")
        sys.exit(1)
