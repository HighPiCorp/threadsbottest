"""
Threads Automation Bot v2.0
Main entry point for CLI and GUI modes.
"""

import argparse
import asyncio
import sys
import os
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from loguru import logger

from core import (
    get_account_manager,
    get_openrouter_client,
    NodriverEngine,
    BrowserProfile,
    get_ip_monitor,
    get_webrtc_blocker,
    get_fingerprint_factory,
)
from core.behavior import human_delay


# Configure logging
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
    level="INFO"
)
logger.add(
    "logs/bot.log",
    rotation="10 MB",
    retention="7 days",
    level="DEBUG"
)


class ThreadsBot:
    """Main bot controller."""
    
    def __init__(self):
        self.account_manager = get_account_manager()
        self.openrouter = None
        self.engine = None
    
    async def initialize(self, master_password: str, openrouter_key: Optional[str] = None):
        """Initialize bot components."""
        # Initialize account manager
        if not self.account_manager.initialize(master_password):
            logger.error("Failed to initialize account manager")
            return False
        
        # Initialize OpenRouter if key provided
        if openrouter_key:
            self.openrouter = get_openrouter_client(openrouter_key)
        
        return True
    
    async def create_post(
        self,
        account_id: int,
        topic: str,
        tone: str = "casual"
    ) -> bool:
        """
        Create a post on Threads.
        
        Args:
            account_id: Account to use
            topic: Post topic
            tone: Writing tone
        
        Returns:
            True if successful
        """
        try:
            # Get account
            account = self.account_manager.get_account(account_id)
            if not account:
                logger.error(f"Account {account_id} not found")
                return False
            
            logger.info(f"Creating post for account {account.username}")
            
            # Generate content with AI
            if not self.openrouter:
                logger.error("OpenRouter not initialized")
                return False
            
            content = await self.openrouter.generate_post(
                topic=topic,
                tone=tone,
                language="ru"
            )
            
            if not content:
                logger.error("Failed to generate content")
                return False
            
            logger.info(f"Generated content: {content[:100]}...")
            
            # Initialize browser
            profile = BrowserProfile(
                proxy=account.proxy.to_url() if account.proxy else None,
                user_agent=account.user_agent,
                timezone=account.timezone,
                language=account.language or "ru-RU",
            )
            
            self.engine = NodriverEngine(profile)
            
            if not await self.engine.start():
                logger.error("Failed to start browser")
                return False
            
            # Apply anti-detect measures
            fingerprint_factory = get_fingerprint_factory()
            fingerprint = fingerprint_factory.get_for_account(str(account_id))
            
            await self.engine.apply_anti_detect(fingerprint)
            
            # Block WebRTC
            webrtc_blocker = get_webrtc_blocker()
            await webrtc_blocker.apply(self.engine)
            
            # Navigate to Threads
            logger.info("Navigating to Threads...")
            await self.engine.navigate("https://threads.net")
            
            # Wait for page load
            await human_delay(3, 5)
            
            # TODO: Implement actual posting logic
            # This would involve:
            # 1. Check if logged in, login if needed
            # 2. Click create post button
            # 3. Type content
            # 4. Submit post
            
            logger.info("Post creation simulation completed")
            
            # Cleanup
            await self.engine.stop()
            
            return True
            
        except Exception as e:
            logger.error(f"Post creation failed: {e}")
            if self.engine:
                await self.engine.stop()
            return False
    
    async def generate_content_only(
        self,
        topic: str,
        tone: str = "casual"
    ) -> Optional[str]:
        """Generate content without posting (for testing)."""
        if not self.openrouter:
            logger.error("OpenRouter not initialized")
            return None
        
        content = await self.openrouter.generate_post(
            topic=topic,
            tone=tone,
            language="ru"
        )
        
        return content
    
    async def test_browser(self, account_id: int) -> bool:
        """Test browser initialization for account."""
        try:
            account = self.account_manager.get_account(account_id)
            if not account:
                logger.error(f"Account {account_id} not found")
                return False
            
            logger.info(f"Testing browser for account {account.username}")
            
            profile = BrowserProfile(
                proxy=account.proxy.to_url() if account.proxy else None,
                user_agent=account.user_agent,
                timezone=account.timezone,
                language=account.language or "ru-RU",
            )
            
            self.engine = NodriverEngine(profile)
            
            if not await self.engine.start():
                logger.error("Failed to start browser")
                return False
            
            # Apply anti-detect
            fingerprint_factory = get_fingerprint_factory()
            fingerprint = fingerprint_factory.get_for_account(str(account_id))
            await self.engine.apply_anti_detect(fingerprint)
            
            # Block WebRTC
            webrtc_blocker = get_webrtc_blocker()
            await webrtc_blocker.apply(self.engine)
            
            # Navigate to test page
            logger.info("Navigating to test page...")
            await self.engine.navigate("https://pixelscan.net/")
            
            logger.info("Browser test running - check the opened browser window")
            logger.info("Press Ctrl+C to stop...")
            
            # Keep browser open
            while True:
                await asyncio.sleep(1)
                
        except KeyboardInterrupt:
            logger.info("Test stopped by user")
        except Exception as e:
            logger.error(f"Browser test failed: {e}")
        finally:
            if self.engine:
                await self.engine.stop()
        
        return True


async def interactive_setup():
    """Interactive setup wizard for first run."""
    print("\n" + "="*60)
    print("  Threads Automation Bot v2.0 - Setup Wizard")
    print("="*60 + "\n")
    
    # Master password
    print("Step 1: Create master password")
    print("This password will encrypt all your account data.")
    print("IMPORTANT: If you forget this password, your data cannot be recovered!\n")
    
    while True:
        password = input("Enter master password: ")
        confirm = input("Confirm master password: ")
        
        if password == confirm and len(password) >= 8:
            break
        
        print("Passwords don't match or too short (min 8 chars). Try again.\n")
    
    # Initialize account manager
    account_manager = get_account_manager()
    if not account_manager.initialize(password):
        print("Failed to initialize account manager!")
        return False
    
    print("\n✓ Account manager initialized\n")
    
    # OpenRouter API key
    print("Step 2: OpenRouter API Key")
    print("Get your free API key at: https://openrouter.ai/keys")
    print("Free models available: meta-llama/llama-4-maverick:free\n")
    
    api_key = input("Enter OpenRouter API key (or press Enter to skip): ").strip()
    
    if api_key:
        # Test the key
        client = get_openrouter_client(api_key)
        print("\n✓ OpenRouter client configured\n")
    else:
        print("\n⚠ OpenRouter not configured (you can add it later)\n")
    
    # Add first account
    print("Step 3: Add your first Threads account")
    print("You can add more accounts later through the GUI or CLI.\n")
    
    add_account = input("Add an account now? (y/n): ").lower() == 'y'
    
    if add_account:
        from core.account_manager import Account, ProxyConfig
        
        username = input("Threads username: ").strip()
        password = input("Threads password: ").strip()
        
        use_proxy = input("Use proxy? (y/n): ").lower() == 'y'
        proxy = None
        
        if use_proxy:
            print("\nProxy format: protocol://host:port or protocol://user:pass@host:port")
            proxy_url = input("Proxy URL: ").strip()
            
            # Parse proxy URL
            try:
                from urllib.parse import urlparse
                parsed = urlparse(proxy_url)
                proxy = ProxyConfig(
                    host=parsed.hostname,
                    port=parsed.port,
                    username=parsed.username,
                    password=parsed.password,
                    protocol=parsed.scheme or "http"
                )
                print("\n✓ Proxy configured\n")
            except Exception as e:
                print(f"\n⚠ Failed to parse proxy: {e}\n")
        
        account = Account(
            id=0,  # Auto-assigned
            username=username,
            password=password,
            proxy=proxy,
            is_active=True
        )
        
        if account_manager.add_account(account):
            print(f"\n✓ Account '{username}' added successfully!\n")
        else:
            print("\n✗ Failed to add account\n")
    
    print("="*60)
    print("  Setup completed!")
    print("="*60)
    print("\nNext steps:")
    print("  - Run 'python main.py --gui' to start the GUI")
    print("  - Run 'python main.py --help' for CLI options")
    print("  - Read README.md for detailed instructions\n")
    
    return True


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Threads Automation Bot v2.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --setup                    Run setup wizard
  %(prog)s --gui                      Start GUI mode
  %(prog)s --account 1 --post "AI"    Create post about AI using account 1
  %(prog)s --account 1 --test         Test browser for account 1
  %(prog)s --generate "Technology"    Generate content without posting
        """
    )
    
    parser.add_argument("--setup", action="store_true", help="Run setup wizard")
    parser.add_argument("--gui", action="store_true", help="Start GUI mode")
    parser.add_argument("--account", type=int, help="Account ID to use")
    parser.add_argument("--post", type=str, help="Create post with topic")
    parser.add_argument("--tone", type=str, default="casual", help="Post tone (casual/professional/funny)")
    parser.add_argument("--generate", type=str, help="Generate content only (no posting)")
    parser.add_argument("--test", action="store_true", help="Test browser initialization")
    parser.add_argument("--master-password", type=str, help="Master password (or set THREADS_MASTER_PASSWORD env var)")
    parser.add_argument("--openrouter-key", type=str, help="OpenRouter API key (or set OPENROUTER_API_KEY env var)")
    
    args = parser.parse_args()
    
    # Setup wizard
    if args.setup:
        return await interactive_setup()
    
    # GUI mode
    if args.gui:
        try:
            from gui.main_window import main as gui_main
            return gui_main()
        except ImportError:
            logger.error("GUI not available. Install PyQt6: pip install PyQt6")
            return 1
    
    # Get credentials
    master_password = args.master_password or os.getenv("THREADS_MASTER_PASSWORD")
    openrouter_key = args.openrouter_key or os.getenv("OPENROUTER_API_KEY")
    
    if not master_password:
        print("Error: Master password required")
        print("Use --master-password or set THREADS_MASTER_PASSWORD environment variable")
        return 1
    
    # Initialize bot
    bot = ThreadsBot()
    if not await bot.initialize(master_password, openrouter_key):
        print("Error: Failed to initialize bot")
        return 1
    
    # Generate content only
    if args.generate:
        if not openrouter_key:
            print("Error: OpenRouter API key required for content generation")
            return 1
        
        content = await bot.generate_content_only(args.generate, args.tone)
        if content:
            print("\nGenerated content:")
            print("-" * 40)
            print(content)
            print("-" * 40)
            return 0
        else:
            print("Error: Failed to generate content")
            return 1
    
    # Test browser
    if args.test:
        if not args.account:
            print("Error: --account required for testing")
            return 1
        
        await bot.test_browser(args.account)
        return 0
    
    # Create post
    if args.post:
        if not args.account:
            print("Error: --account required for posting")
            return 1
        
        if not openrouter_key:
            print("Error: OpenRouter API key required for posting")
            return 1
        
        success = await bot.create_post(args.account, args.post, args.tone)
        return 0 if success else 1
    
    # No action specified
    parser.print_help()
    return 0


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code or 0)
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.exception("Fatal error")
        sys.exit(1)
