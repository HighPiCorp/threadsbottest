"""
Scheduler Module
Manages scheduled tasks for posting and commenting.
"""

import asyncio
import random
import os
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import json
from pathlib import Path

from loguru import logger

try:
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    AP_SCHEDULER_AVAILABLE = True
except ImportError:
    AP_SCHEDULER_AVAILABLE = False
    logger.warning("APScheduler not installed, using fallback scheduler")


class TaskType(Enum):
    """Types of scheduled tasks."""
    POST = "post"
    COMMENT = "comment"
    PROXY_CHECK = "proxy_check"
    SESSION_REFRESH = "session_refresh"


class TaskStatus(Enum):
    """Status of a task."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PAUSED = "paused"


@dataclass
class ScheduleConfig:
    """Configuration for scheduling."""
    # Posting schedule
    post_times: List[str] = field(default_factory=lambda: ["10:00", "15:00", "20:00"])
    post_topics: List[str] = field(default_factory=list)
    post_topic_weights: List[float] = field(default_factory=list)
    post_tone: str = "casual"
    max_daily_posts: int = 3
    
    # Commenting schedule
    comment_interval_hours: int = 2
    comment_sources: Dict[str, List[str]] = field(default_factory=dict)
    comment_max_per_cycle: int = 5
    comment_style: str = "engaging"
    max_daily_comments: int = 20
    
    # Other
    proxy_check_interval_hours: int = 1
    session_refresh_interval_hours: int = 6
    timezone: str = "UTC"


@dataclass
class TaskResult:
    """Result of a task execution."""
    task_id: str
    success: bool
    message: str
    executed_at: datetime
    details: Dict[str, Any] = field(default_factory=dict)


class AccountScheduler:
    """
    Scheduler for a single account's tasks.
    
    Manages:
    - Scheduled posting
    - Scheduled commenting
    - Proxy checks
    - Session refresh
    """
    
    def __init__(
        self,
        account_id: int,
        config: Optional[ScheduleConfig] = None
    ):
        self.account_id = account_id
        self.config = config or ScheduleConfig()
        
        self.scheduler = None
        if AP_SCHEDULER_AVAILABLE:
            self.scheduler = AsyncIOScheduler(timezone=self.config.timezone)
        
        self._tasks: Dict[str, Any] = {}
        self._task_handlers: Dict[TaskType, Callable] = {}
        self._results: List[TaskResult] = []
        self._is_running = False
    
    def register_handler(self, task_type: TaskType, handler: Callable):
        """Register a handler for a task type."""
        self._task_handlers[task_type] = handler
        logger.debug(f"Registered handler for {task_type.value}")
    
    def setup_schedule(self):
        """Set up scheduled tasks based on configuration."""
        if not self.scheduler:
            logger.warning("APScheduler not available, using manual scheduling")
            return
        
        # Clear existing jobs
        self.scheduler.remove_all_jobs()
        
        # Setup posting schedule
        for time_str in self.config.post_times:
            hour, minute = map(int, time_str.split(':'))
            job_id = f"post_{self.account_id}_{time_str.replace(':', '')}"
            
            self.scheduler.add_job(
                self._execute_task,
                trigger=CronTrigger(hour=hour, minute=minute),
                id=job_id,
                args=[TaskType.POST],
                replace_existing=True,
                misfire_grace_time=3600  # 1 hour grace period
            )
            
            logger.info(f"Scheduled post job at {time_str} for account {self.account_id}")
        
        # Setup commenting schedule
        comment_job_id = f"comment_{self.account_id}"
        self.scheduler.add_job(
            self._execute_task,
            trigger=IntervalTrigger(hours=self.config.comment_interval_hours),
            id=comment_job_id,
            args=[TaskType.COMMENT],
            replace_existing=True,
            misfire_grace_time=1800
        )
        
        logger.info(f"Scheduled comment job every {self.config.comment_interval_hours}h for account {self.account_id}")
        
        # Setup proxy check
        proxy_job_id = f"proxy_check_{self.account_id}"
        self.scheduler.add_job(
            self._execute_task,
            trigger=IntervalTrigger(hours=self.config.proxy_check_interval_hours),
            id=proxy_job_id,
            args=[TaskType.PROXY_CHECK],
            replace_existing=True
        )
        
        # Setup session refresh
        session_job_id = f"session_refresh_{self.account_id}"
        self.scheduler.add_job(
            self._execute_task,
            trigger=IntervalTrigger(hours=self.config.session_refresh_interval_hours),
            id=session_job_id,
            args=[TaskType.SESSION_REFRESH],
            replace_existing=True
        )
    
    async def _execute_task(self, task_type: TaskType):
        """Execute a scheduled task."""
        task_id = f"{task_type.value}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        logger.info(f"Executing {task_type.value} task for account {self.account_id}")
        
        handler = self._task_handlers.get(task_type)
        if not handler:
            logger.error(f"No handler registered for {task_type.value}")
            return
        
        try:
            # Execute handler
            result = await handler(self.account_id, self.config)
            
            task_result = TaskResult(
                task_id=task_id,
                success=result.get("success", False),
                message=result.get("message", ""),
                executed_at=datetime.now(),
                details=result.get("details", {})
            )
            
        except Exception as e:
            logger.exception(f"Task {task_type.value} failed: {e}")
            task_result = TaskResult(
                task_id=task_id,
                success=False,
                message=str(e),
                executed_at=datetime.now()
            )
        
        self._results.append(task_result)
        
        # Keep only last 100 results
        if len(self._results) > 100:
            self._results = self._results[-100:]
    
    def start(self):
        """Start the scheduler."""
        if self.scheduler and not self._is_running:
            self.scheduler.start()
            self._is_running = True
            logger.info(f"Scheduler started for account {self.account_id}")
    
    def pause(self):
        """Pause the scheduler."""
        if self.scheduler:
            self.scheduler.pause()
            logger.info(f"Scheduler paused for account {self.account_id}")
    
    def resume(self):
        """Resume the scheduler."""
        if self.scheduler:
            self.scheduler.resume()
            logger.info(f"Scheduler resumed for account {self.account_id}")
    
    def stop(self):
        """Stop the scheduler."""
        if self.scheduler:
            self.scheduler.shutdown(wait=False)
            self._is_running = False
            logger.info(f"Scheduler stopped for account {self.account_id}")
    
    def get_next_run_times(self) -> Dict[str, Optional[datetime]]:
        """Get next scheduled run times for all tasks."""
        if not self.scheduler:
            return {}
        
        times = {}
        for job in self.scheduler.get_jobs():
            times[job.id] = job.next_run_time
        return times
    
    def get_results(
        self,
        task_type: Optional[TaskType] = None,
        since: Optional[datetime] = None
    ) -> List[TaskResult]:
        """Get task results with optional filtering."""
        results = self._results
        
        if task_type:
            results = [r for r in results if r.task_id.startswith(task_type.value)]
        
        if since:
            results = [r for r in results if r.executed_at >= since]
        
        return results
    
    def get_stats(self) -> Dict[str, Any]:
        """Get scheduler statistics."""
        total_tasks = len(self._results)
        successful_tasks = sum(1 for r in self._results if r.success)
        
        return {
            "account_id": self.account_id,
            "is_running": self._is_running,
            "total_tasks": total_tasks,
            "successful_tasks": successful_tasks,
            "failed_tasks": total_tasks - successful_tasks,
            "next_runs": self.get_next_run_times(),
        }


class GlobalScheduler:
    """
    Global scheduler managing all accounts.
    
    Features:
    - Per-account schedulers
    - Configuration persistence
    - Statistics aggregation
    """
    
    def __init__(self, config_dir: str = "config"):
        # Use Documents/ThreadsBot
        base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
        self.config_dir = base_dir
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self._schedulers: Dict[int, AccountScheduler] = {}
        self._configs: Dict[int, ScheduleConfig] = {}
        
        self._config_file = self.config_dir / "schedules.json"
        self._load_configs()
    
    def _load_configs(self):
        """Load schedule configurations from file."""
        if self._config_file.exists():
            try:
                with open(self._config_file, 'r') as f:
                    data = json.load(f)
                
                for account_id_str, config_data in data.items():
                    account_id = int(account_id_str)
                    self._configs[account_id] = ScheduleConfig(**config_data)
                
                logger.info(f"Loaded {len(self._configs)} schedule configs")
            except Exception as e:
                logger.error(f"Failed to load schedule configs: {e}")
    
    def _save_configs(self):
        """Save schedule configurations to file."""
        try:
            data = {}
            for account_id, config in self._configs.items():
                data[str(account_id)] = {
                    "post_times": config.post_times,
                    "post_topics": config.post_topics,
                    "post_topic_weights": config.post_topic_weights,
                    "post_tone": config.post_tone,
                    "max_daily_posts": config.max_daily_posts,
                    "comment_interval_hours": config.comment_interval_hours,
                    "comment_sources": config.comment_sources,
                    "comment_max_per_cycle": config.comment_max_per_cycle,
                    "comment_style": config.comment_style,
                    "max_daily_comments": config.max_daily_comments,
                    "proxy_check_interval_hours": config.proxy_check_interval_hours,
                    "session_refresh_interval_hours": config.session_refresh_interval_hours,
                    "timezone": config.timezone,
                }
            
            with open(self._config_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Schedule configs saved")
        except Exception as e:
            logger.error(f"Failed to save schedule configs: {e}")
    
    def create_scheduler(
        self,
        account_id: int,
        config: Optional[ScheduleConfig] = None
    ) -> AccountScheduler:
        """Create a scheduler for an account."""
        if config:
            self._configs[account_id] = config
            self._save_configs()
        elif account_id not in self._configs:
            self._configs[account_id] = ScheduleConfig()
        
        scheduler = AccountScheduler(
            account_id=account_id,
            config=self._configs[account_id]
        )
        
        self._schedulers[account_id] = scheduler
        return scheduler
    
    def get_scheduler(self, account_id: int) -> Optional[AccountScheduler]:
        """Get scheduler for an account."""
        return self._schedulers.get(account_id)
    
    def remove_scheduler(self, account_id: int):
        """Remove a scheduler."""
        if account_id in self._schedulers:
            self._schedulers[account_id].stop()
            del self._schedulers[account_id]
    
    def update_config(
        self,
        account_id: int,
        config: ScheduleConfig
    ):
        """Update schedule configuration for an account."""
        self._configs[account_id] = config
        self._save_configs()
        
        # Update existing scheduler
        if account_id in self._schedulers:
            self._schedulers[account_id].config = config
            self._schedulers[account_id].setup_schedule()
    
    def get_config(self, account_id: int) -> Optional[ScheduleConfig]:
        """Get schedule configuration for an account."""
        return self._configs.get(account_id)
    
    def start_all(self):
        """Start all schedulers."""
        for account_id, scheduler in self._schedulers.items():
            scheduler.setup_schedule()
            scheduler.start()
            logger.info(f"Started scheduler for account {account_id}")
    
    def stop_all(self):
        """Stop all schedulers."""
        for scheduler in self._schedulers.values():
            scheduler.stop()
        logger.info("All schedulers stopped")
    
    def get_all_stats(self) -> Dict[int, Dict[str, Any]]:
        """Get statistics for all schedulers."""
        return {
            account_id: scheduler.get_stats()
            for account_id, scheduler in self._schedulers.items()
        }


# Singleton
_global_scheduler: Optional[GlobalScheduler] = None


def get_global_scheduler(config_dir: str = "config") -> GlobalScheduler:
    """Get global scheduler singleton."""
    global _global_scheduler
    if _global_scheduler is None:
        _global_scheduler = GlobalScheduler(config_dir)
    return _global_scheduler


# Manual fallback scheduler for when APScheduler is not available
class ManualScheduler:
    """Simple manual scheduler as fallback."""
    
    def __init__(self):
        self._tasks: List[Dict] = []
        self._running = False
    
    def add_task(
        self,
        task_type: TaskType,
        handler: Callable,
        interval_seconds: int,
        account_id: int
    ):
        """Add a recurring task."""
        self._tasks.append({
            "type": task_type,
            "handler": handler,
            "interval": interval_seconds,
            "account_id": account_id,
            "last_run": None,
        })
    
    async def run(self):
        """Run the scheduler loop."""
        self._running = True
        
        while self._running:
            now = datetime.now()
            
            for task in self._tasks:
                if task["last_run"] is None or \
                   (now - task["last_run"]).total_seconds() >= task["interval"]:
                    
                    try:
                        await task["handler"](task["account_id"])
                    except Exception as e:
                        logger.error(f"Manual task error: {e}")
                    
                    task["last_run"] = now
            
            await asyncio.sleep(60)  # Check every minute
    
    def stop(self):
        """Stop the scheduler."""
        self._running = False