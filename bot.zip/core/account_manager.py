"""
Account Manager Module
Handles secure storage and retrieval of account credentials using Fernet encryption.
"""

import json
import os
import base64
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from loguru import logger


@dataclass
class ProxyConfig:
    """Proxy configuration for an account."""
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    protocol: str = "http"  # http, https, socks4, socks5

    def to_url(self) -> str:
        """Convert proxy config to URL format for Chrome."""
        if self.username and self.password:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProxyConfig":
        return cls(**data)


@dataclass
class Account:
    """Threads account data."""
    id: int
    username: str
    password: str
    proxy: Optional[ProxyConfig] = None
    user_agent: Optional[str] = None
    timezone: Optional[str] = None
    language: Optional[str] = None
    notes: Optional[str] = None
    is_active: bool = True
    created_at: Optional[str] = None
    last_used: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        if self.proxy:
            data['proxy'] = self.proxy.to_dict()
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Account":
        if data.get('proxy'):
            data['proxy'] = ProxyConfig.from_dict(data['proxy'])
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


class AccountManager:
    """
    Manages account storage with Fernet encryption.

    Features:
    - Secure password storage using Fernet encryption
    - Master password protection
    - Account CRUD operations
    - Proxy configuration management
    """

    def __init__(self, config_dir: str = "config"):
        # Используем Documents/ThreadsBot как основную папку (уже настроено)
        base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
        self.config_dir = base_dir
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # ИЗМЕНЕНО: accounts.enc -> accounts.dat (чтобы избежать блокировки антивирусом)
        self.accounts_file = self.config_dir / "accounts.dat"
        self.salt_file = self.config_dir / ".salt"

        self._fernet: Optional[Fernet] = None
        self._accounts: Dict[int, Account] = {}
        self._master_password_hash: Optional[str] = None

        logger.info(f"AccountManager initialized. Config dir: {self.config_dir.absolute()}")

    def _generate_salt(self) -> bytes:
        """Generate or load existing salt."""
        if self.salt_file.exists():
            return base64.urlsafe_b64decode(self.salt_file.read_bytes())

        salt = os.urandom(16)
        self.salt_file.write_bytes(base64.urlsafe_b64encode(salt))
        # Hide salt file on Windows
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(self.salt_file), 0x02)
        except Exception:
            pass
        return salt

    def _derive_key(self, master_password: str) -> bytes:
        """Derive encryption key from master password."""
        salt = self._generate_salt()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(master_password.encode()))
        return key

    def initialize(self, master_password: str) -> bool:
        """
        Initialize the account manager with master password.

        Args:
            master_password: Master password for encryption

        Returns:
            True if successful, False if wrong password for existing data
        """
        try:
            key = self._derive_key(master_password)
            self._fernet = Fernet(key)

            if self.accounts_file.exists():
                return self._load_accounts()

            logger.info("AccountManager initialized with new master password")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize AccountManager: {e}")
            return False

    def _load_accounts(self) -> bool:
        """Load and decrypt accounts from file."""
        try:
            encrypted_data = self.accounts_file.read_bytes()
            decrypted_data = self._fernet.decrypt(encrypted_data)
            accounts_data = json.loads(decrypted_data.decode())

            self._accounts = {
                int(k): Account.from_dict(v)
                for k, v in accounts_data.items()
            }

            logger.info(f"Loaded {len(self._accounts)} accounts")
            return True

        except Exception as e:
            logger.error(f"Failed to load accounts - wrong password or corrupted file: {e}")
            return False

    def _save_accounts(self) -> bool:
        """Encrypt and save accounts to file."""
        try:
            accounts_data = {
                str(k): v.to_dict()
                for k, v in self._accounts.items()
            }
            json_data = json.dumps(accounts_data, indent=2, ensure_ascii=False)
            encrypted_data = self._fernet.encrypt(json_data.encode())

            # Запись с дополнительной проверкой прав
            self.accounts_file.write_bytes(encrypted_data)
            logger.info(f"Saved {len(self._accounts)} accounts to {self.accounts_file}")
            return True

        except PermissionError as e:
            logger.error(f"Permission denied while saving accounts: {e}. "
                         f"Check if file is read-only or blocked by antivirus.")
            return False
        except Exception as e:
            logger.error(f"Failed to save accounts: {e}")
            return False

    def add_account(self, account: Account) -> bool:
        """Add a new account."""
        if not self._fernet:
            logger.error("AccountManager not initialized")
            return False

        # Auto-assign ID if not set
        if account.id == 0 or account.id in self._accounts:
            account.id = max(self._accounts.keys(), default=0) + 1

        self._accounts[account.id] = account
        success = self._save_accounts()

        if success:
            logger.info(f"Added account {account.id} ({account.username})")

        return success

    def update_account(self, account_id: int, **kwargs) -> bool:
        """Update account fields."""
        if account_id not in self._accounts:
            logger.error(f"Account {account_id} not found")
            return False

        account = self._accounts[account_id]

        for key, value in kwargs.items():
            if hasattr(account, key):
                setattr(account, key, value)

        success = self._save_accounts()

        if success:
            logger.info(f"Updated account {account_id}")

        return success

    def delete_account(self, account_id: int) -> bool:
        """Delete an account."""
        if account_id not in self._accounts:
            logger.error(f"Account {account_id} not found")
            return False

        del self._accounts[account_id]
        success = self._save_accounts()

        if success:
            logger.info(f"Deleted account {account_id}")

        return success

    def get_account(self, account_id: int) -> Optional[Account]:
        """Get account by ID."""
        return self._accounts.get(account_id)

    def get_all_accounts(self) -> List[Account]:
        """Get all accounts."""
        return list(self._accounts.values())

    def get_active_accounts(self) -> List[Account]:
        """Get only active accounts."""
        return [a for a in self._accounts.values() if a.is_active]

    def is_initialized(self) -> bool:
        """Check if manager is initialized."""
        return self._fernet is not None

    def has_accounts(self) -> bool:
        """Check if any accounts exist."""
        return len(self._accounts) > 0

    def change_master_password(self, old_password: str, new_password: str) -> bool:
        """Change master password and re-encrypt data."""
        # Verify old password
        old_key = self._derive_key(old_password)
        old_fernet = Fernet(old_key)

        try:
            encrypted_data = self.accounts_file.read_bytes()
            old_fernet.decrypt(encrypted_data)
        except Exception:
            logger.error("Old password is incorrect")
            return False

        # Generate new key and re-encrypt
        new_key = self._derive_key(new_password)
        self._fernet = Fernet(new_key)

        return self._save_accounts()


# Singleton instance
_account_manager: Optional[AccountManager] = None


def get_account_manager(config_dir: str = "config") -> AccountManager:
    """Get or create AccountManager singleton."""
    global _account_manager
    if _account_manager is None:
        _account_manager = AccountManager(config_dir)
    return _account_manager