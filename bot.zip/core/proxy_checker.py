"""
Proxy Checker Module
Validates proxy servers for connectivity, anonymity, and geolocation.
"""

import asyncio
import time
from typing import Dict, Optional, List, Any
from dataclasses import dataclass
from urllib.parse import urlparse

import aiohttp
import aiohttp_socks
from loguru import logger

from .account_manager import ProxyConfig


@dataclass
class ProxyCheckResult:
    """Result of proxy check."""
    success: bool
    external_ip: Optional[str]
    country: Optional[str]
    city: Optional[str]
    timezone: Optional[str]
    isp: Optional[str]
    is_anonymous: bool
    speed_ms: int
    error_message: Optional[str] = None
    headers_leaked: List[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "external_ip": self.external_ip,
            "country": self.country,
            "city": self.city,
            "timezone": self.timezone,
            "isp": self.isp,
            "is_anonymous": self.is_anonymous,
            "speed_ms": self.speed_ms,
            "error_message": self.error_message,
            "headers_leaked": self.headers_leaked or [],
        }


class ProxyChecker:
    """
    Checks proxy servers for various properties.

    Features:
    - TCP connectivity check
    - Anonymity verification (header leak detection)
    - Geolocation detection
    - Speed measurement
    """

    # Test URLs
    IP_CHECK_URLS = [
        "https://httpbin.org/ip",
        "https://api.ipify.org?format=json",
        "https://ipinfo.io/json",
    ]

    # Headers that should NOT be present for anonymity
    ANONYMITY_HEADERS = [
        "x-forwarded-for",
        "x-forwarded-host",
        "x-forwarded-proto",
        "x-real-ip",
        "x-client-ip",
        "x-remote-ip",
        "x-remote-addr",
        "x-originating-ip",
        "cf-connecting-ip",
        "true-client-ip",
    ]

    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    def _build_proxy_url(self, proxy: ProxyConfig) -> str:
        """Build proxy URL from config."""
        if proxy.username and proxy.password:
            return f"{proxy.protocol}://{proxy.username}:{proxy.password}@{proxy.host}:{proxy.port}"
        return f"{proxy.protocol}://{proxy.host}:{proxy.port}"

    async def test_proxy(self, proxy: ProxyConfig) -> ProxyCheckResult:
        """
        Test a proxy server comprehensively.

        Args:
            proxy: Proxy configuration to test

        Returns:
            ProxyCheckResult with all check results
        """
        start_time = time.time()

        # Проверка на корректность прокси (host и port не должны быть None)
        if not proxy.host or not proxy.port:
            logger.error(f"Invalid proxy config: host={proxy.host}, port={proxy.port}")
            return ProxyCheckResult(
                success=False,
                external_ip=None,
                country=None,
                city=None,
                timezone=None,
                isp=None,
                is_anonymous=False,
                speed_ms=int((time.time() - start_time) * 1000),
                error_message="Proxy host or port is missing"
            )

        try:
            proxy_url = self._build_proxy_url(proxy)
            logger.info(f"Testing proxy: {proxy.host}:{proxy.port}")

            # Test 1: Basic connectivity and IP detection
            ip_result = await self._check_external_ip(proxy_url)

            if not ip_result["success"]:
                return ProxyCheckResult(
                    success=False,
                    external_ip=None,
                    country=None,
                    city=None,
                    timezone=None,
                    isp=None,
                    is_anonymous=False,
                    speed_ms=int((time.time() - start_time) * 1000),
                    error_message=ip_result.get("error", "Unknown error"),
                )

            # Test 2: Anonymity check
            anonymity_result = await self._check_anonymity(proxy_url)

            # Test 3: Geolocation
            geo_result = await self._check_geolocation(ip_result.get("ip"), proxy_url)

            elapsed_ms = int((time.time() - start_time) * 1000)

            return ProxyCheckResult(
                success=True,
                external_ip=ip_result.get("ip"),
                country=geo_result.get("country"),
                city=geo_result.get("city"),
                timezone=geo_result.get("timezone"),
                isp=geo_result.get("isp"),
                is_anonymous=anonymity_result["is_anonymous"],
                speed_ms=elapsed_ms,
                headers_leaked=anonymity_result.get("leaked_headers", []),
            )

        except Exception as e:
            logger.error(f"Proxy test failed: {e}")
            return ProxyCheckResult(
                success=False,
                external_ip=None,
                country=None,
                city=None,
                timezone=None,
                isp=None,
                is_anonymous=False,
                speed_ms=int((time.time() - start_time) * 1000),
                error_message=str(e),
            )

    async def _check_external_ip(self, proxy_url: str) -> Dict[str, Any]:
        """Check external IP through proxy."""
        try:
            connector = aiohttp_socks.ProxyConnector.from_url(proxy_url)

            async with aiohttp.ClientSession(connector=connector) as session:
                for url in self.IP_CHECK_URLS:
                    try:
                        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as response:
                            if response.status == 200:
                                data = await response.json()

                                # Extract IP from different response formats
                                ip = data.get("ip") or data.get("origin")

                                if ip:
                                    logger.debug(f"External IP detected: {ip}")
                                    return {"success": True, "ip": ip}

                    except Exception as e:
                        logger.debug(f"IP check URL {url} failed: {e}")
                        continue

                return {"success": False, "error": "All IP check URLs failed"}

        except Exception as e:
            logger.error(f"External IP check failed: {e}")
            return {"success": False, "error": str(e)}

    async def _check_anonymity(self, proxy_url: str) -> Dict[str, Any]:
        """Check if proxy leaks identifying headers."""
        leaked_headers = []

        try:
            connector = aiohttp_socks.ProxyConnector.from_url(proxy_url)

            async with aiohttp.ClientSession(connector=connector) as session:
                # Use httpbin to see what headers are sent
                async with session.get(
                    "https://httpbin.org/headers",
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        headers = {k.lower(): v for k, v in data.get("headers", {}).items()}

                        for header in self.ANONYMITY_HEADERS:
                            if header in headers:
                                leaked_headers.append(header)
                                logger.warning(f"Proxy leaks header: {header}")

                        is_anonymous = len(leaked_headers) == 0

                        return {
                            "is_anonymous": is_anonymous,
                            "leaked_headers": leaked_headers,
                        }

        except Exception as e:
            logger.error(f"Anonymity check failed: {e}")
            return {"is_anonymous": False, "leaked_headers": [], "error": str(e)}

        return {"is_anonymous": True, "leaked_headers": []}

    async def _check_geolocation(
        self,
        ip: Optional[str],
        proxy_url: str
    ) -> Dict[str, Optional[str]]:
        """Get geolocation for IP."""
        if not ip:
            return {"country": None, "city": None, "timezone": None, "isp": None}

        try:
            connector = aiohttp_socks.ProxyConnector.from_url(proxy_url)

            async with aiohttp.ClientSession(connector=connector) as session:
                # Try ip-api.com
                try:
                    async with session.get(
                        f"http://ip-api.com/json/{ip}?fields=status,message,country,city,timezone,isp",
                        timeout=aiohttp.ClientTimeout(total=10)
                    ) as response:
                        if response.status == 200:
                            data = await response.json()

                            if data.get("status") == "success":
                                return {
                                    "country": data.get("country"),
                                    "city": data.get("city"),
                                    "timezone": data.get("timezone"),
                                    "isp": data.get("isp"),
                                }
                except Exception as e:
                    logger.debug(f"ip-api.com failed: {e}")

                # Fallback to ipinfo.io
                try:
                    async with session.get(
                        "https://ipinfo.io/json",
                        timeout=aiohttp.ClientTimeout(total=10)
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            return {
                                "country": data.get("country"),
                                "city": data.get("city"),
                                "timezone": None,  # ipinfo doesn't provide timezone
                                "isp": data.get("org"),
                            }
                except Exception as e:
                    logger.debug(f"ipinfo.io failed: {e}")

        except Exception as e:
            logger.error(f"Geolocation check failed: {e}")

        return {"country": None, "city": None, "timezone": None, "isp": None}

    async def check_all_proxies(
        self,
        accounts: List[Any],
        callback: Optional[callable] = None
    ) -> Dict[int, ProxyCheckResult]:
        """
        Check all proxies from accounts.

        Args:
            accounts: List of accounts with proxies
            callback: Optional callback for progress updates

        Returns:
            Dict mapping account_id to check result
        """
        results = {}

        for account in accounts:
            if not account.proxy:
                continue

            result = await self.test_proxy(account.proxy)
            results[account.id] = result

            if callback:
                callback(account.id, result)

            # Small delay between checks
            await asyncio.sleep(0.5)

        return results

    async def close(self):
        """Close HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()


# Singleton instance
_checker: Optional[ProxyChecker] = None


def get_proxy_checker(timeout: int = 30) -> ProxyChecker:
    """Get proxy checker singleton."""
    global _checker
    if _checker is None:
        _checker = ProxyChecker(timeout)
    return _checker