"""
Post Fetcher Module
Searches and retrieves posts from Threads for commenting.
"""

import asyncio
import re
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime, timedelta
from urllib.parse import quote

from loguru import logger

from .engines.base_engine import BaseBrowserEngine
from .behavior import human_delay, simulate_page_scan


@dataclass
class Post:
    """Represents a Threads post."""
    url: str
    text: str
    author: str
    author_username: str
    likes: int
    replies: int
    posted_at: Optional[datetime]
    post_id: Optional[str] = None
    hashtags: List[str] = None
    
    def __post_init__(self):
        if self.hashtags is None:
            self.hashtags = []
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "text": self.text[:200] + "..." if len(self.text) > 200 else self.text,
            "author": self.author,
            "author_username": self.author_username,
            "likes": self.likes,
            "replies": self.replies,
            "posted_at": self.posted_at.isoformat() if self.posted_at else None,
            "post_id": self.post_id,
            "hashtags": self.hashtags,
        }


class PostSearcher:
    """
    Searches for posts on Threads.
    
    Supports:
    - Keyword search
    - Hashtag search
    - Account feed search
    - Trending posts
    """
    
    BASE_URL = "https://www.threads.net"
    
    # Selectors
    SELECTORS = {
        "search_input": 'input[placeholder*="Search"]',
        "search_result": 'article',
        "post_text": '[data-testid="post-text"]',
        "post_author": 'a[href^="/@"]',
        "like_count": '[data-testid="like-count"]',
        "reply_count": '[data-testid="reply-count"]',
        "post_link": 'a[href*="/post/"]',
    }
    
    def __init__(self, engine: BaseBrowserEngine):
        self.engine = engine
    
    async def search(
        self,
        keywords: Optional[List[str]] = None,
        hashtags: Optional[List[str]] = None,
        accounts: Optional[List[str]] = None,
        max_results: int = 20
    ) -> List[Post]:
        """
        Search for posts by various criteria.
        
        Args:
            keywords: Keywords to search for
            hashtags: Hashtags to search for
            accounts: Accounts to fetch posts from
            max_results: Maximum posts to return
            
        Returns:
            List of Post objects
        """
        all_posts = []
        
        # Search by keywords
        if keywords:
            for keyword in keywords:
                posts = await self._search_by_keyword(keyword, max_results // len(keywords))
                all_posts.extend(posts)
                await human_delay(2, 4)
        
        # Search by hashtags
        if hashtags:
            for hashtag in hashtags:
                posts = await self._search_by_hashtag(hashtag, max_results // len(hashtags))
                all_posts.extend(posts)
                await human_delay(2, 4)
        
        # Get posts from accounts
        if accounts:
            for account in accounts:
                posts = await self._get_account_posts(account, max_results // len(accounts))
                all_posts.extend(posts)
                await human_delay(2, 4)
        
        # Remove duplicates
        seen_urls = set()
        unique_posts = []
        for post in all_posts:
            if post.url not in seen_urls:
                seen_urls.add(post.url)
                unique_posts.append(post)
        
        return unique_posts[:max_results]
    
    async def _search_by_keyword(self, keyword: str, max_results: int) -> List[Post]:
        """Search posts by keyword."""
        try:
            logger.info(f"Searching for keyword: {keyword}")
            
            # Navigate to search
            search_url = f"{self.BASE_URL}/search?q={quote(keyword)}"
            await self.engine.navigate(search_url)
            await human_delay(3, 5)
            
            # Simulate reading/scrolling
            await simulate_page_scan(self.engine, scan_duration=(3, 6))
            
            # Extract posts
            posts = await self._extract_posts_from_page(max_results)
            
            logger.info(f"Found {len(posts)} posts for keyword '{keyword}'")
            return posts
            
        except Exception as e:
            logger.error(f"Keyword search failed: {e}")
            return []
    
    async def _search_by_hashtag(self, hashtag: str, max_results: int) -> List[Post]:
        """Search posts by hashtag."""
        try:
            logger.info(f"Searching for hashtag: #{hashtag}")
            
            # Clean hashtag
            hashtag = hashtag.lstrip('#')
            
            # Navigate to hashtag page
            hashtag_url = f"{self.BASE_URL}/tags/{quote(hashtag)}"
            await self.engine.navigate(hashtag_url)
            await human_delay(3, 5)
            
            # Extract posts
            posts = await self._extract_posts_from_page(max_results)
            
            # Add hashtag to each post
            for post in posts:
                if hashtag not in post.hashtags:
                    post.hashtags.append(hashtag)
            
            logger.info(f"Found {len(posts)} posts for hashtag #{hashtag}")
            return posts
            
        except Exception as e:
            logger.error(f"Hashtag search failed: {e}")
            return []
    
    async def _get_account_posts(self, username: str, max_results: int) -> List[Post]:
        """Get posts from a specific account."""
        try:
            logger.info(f"Fetching posts from account: @{username}")
            
            # Clean username
            username = username.lstrip('@')
            
            # Navigate to profile
            profile_url = f"{self.BASE_URL}/@{username}"
            await self.engine.navigate(profile_url)
            await human_delay(3, 5)
            
            # Extract posts
            posts = await self._extract_posts_from_page(max_results)
            
            logger.info(f"Found {len(posts)} posts from @{username}")
            return posts
            
        except Exception as e:
            logger.error(f"Account posts fetch failed: {e}")
            return []
    
    async def _extract_posts_from_page(self, max_results: int) -> List[Post]:
        """Extract post data from current page."""
        posts = []
        
        try:
            # Find all post elements
            post_elements = await self.engine.find_elements(
                self.SELECTORS["search_result"]
            )
            
            for element in post_elements[:max_results]:
                try:
                    post = await self._parse_post_element(element)
                    if post:
                        posts.append(post)
                except Exception as e:
                    logger.debug(f"Failed to parse post element: {e}")
                    continue
            
        except Exception as e:
            logger.error(f"Post extraction failed: {e}")
        
        return posts
    
    async def _parse_post_element(self, element) -> Optional[Post]:
        """Parse a single post element."""
        try:
            # Get post URL
            link_elem = await element.find_element(
                self.engine.driver,  # This might need adjustment based on engine
                self.SELECTORS["post_link"]
            ) if hasattr(element, 'find_element') else None
            
            if not link_elem:
                return None
            
            url = await self.engine.execute_script(
                "return arguments[0].getAttribute('href')",
                link_elem
            )
            
            if not url:
                return None
            
            # Make absolute URL
            if url.startswith('/'):
                url = f"{self.BASE_URL}{url}"
            
            # Extract post ID from URL
            post_id = self._extract_post_id(url)
            
            # Get post text
            text = ""
            text_elem = await element.find_element(
                self.engine.driver,
                self.SELECTORS["post_text"]
            ) if hasattr(element, 'find_element') else None
            
            if text_elem:
                text = await self.engine.get_text(text_elem)
            
            # Get author
            author = ""
            author_username = ""
            author_elem = await element.find_element(
                self.engine.driver,
                self.SELECTORS["post_author"]
            ) if hasattr(element, 'find_element') else None
            
            if author_elem:
                author_username = await self.engine.execute_script(
                    "return arguments[0].getAttribute('href')",
                    author_elem
                )
                if author_username:
                    author_username = author_username.lstrip('/@')
            
            # Get engagement metrics
            likes = 0
            likes_elem = await element.find_element(
                self.engine.driver,
                self.SELECTORS["like_count"]
            ) if hasattr(element, 'find_element') else None
            
            if likes_elem:
                likes_text = await self.engine.get_text(likes_elem)
                likes = self._parse_number(likes_text)
            
            replies = 0
            replies_elem = await element.find_element(
                self.engine.driver,
                self.SELECTORS["reply_count"]
            ) if hasattr(element, 'find_element') else None
            
            if replies_elem:
                replies_text = await self.engine.get_text(replies_elem)
                replies = self._parse_number(replies_text)
            
            # Extract hashtags
            hashtags = re.findall(r'#\w+', text)
            
            return Post(
                url=url,
                text=text,
                author=author,
                author_username=author_username,
                likes=likes,
                replies=replies,
                posted_at=None,  # Would need to parse from page
                post_id=post_id,
                hashtags=hashtags,
            )
            
        except Exception as e:
            logger.debug(f"Post parsing error: {e}")
            return None
    
    def _extract_post_id(self, url: str) -> Optional[str]:
        """Extract post ID from URL."""
        patterns = [
            r'/post/([^/?]+)',
            r'/t/([^/?]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        return None
    
    def _parse_number(self, text: str) -> int:
        """Parse number from text (handles K, M suffixes)."""
        text = text.lower().replace(',', '').strip()
        
        multipliers = {
            'k': 1000,
            'm': 1000000,
        }
        
        for suffix, multiplier in multipliers.items():
            if suffix in text:
                try:
                    number = float(text.replace(suffix, ''))
                    return int(number * multiplier)
                except ValueError:
                    return 0
        
        try:
            return int(text)
        except ValueError:
            return 0
    
    async def get_trending_posts(self, max_results: int = 10) -> List[Post]:
        """Get trending posts from explore page."""
        try:
            logger.info("Fetching trending posts")
            
            await self.engine.navigate(f"{self.BASE_URL}/explore")
            await human_delay(3, 5)
            
            posts = await self._extract_posts_from_page(max_results)
            
            logger.info(f"Found {len(posts)} trending posts")
            return posts
            
        except Exception as e:
            logger.error(f"Trending posts fetch failed: {e}")
            return []
