"""
Commenter Module
Handles searching, filtering, and commenting on posts.
"""

import asyncio
import random
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime

from loguru import logger

from .account_manager import Account
from .engines.base_engine import BaseBrowserEngine
from .openrouter_client import OpenRouterClient
from .threads_auth import ThreadsSession
from .post_fetcher import PostSearcher, Post
from .post_filter import PostFilter, FilterConfig, get_global_registry
from .behavior import human_delay, think_delay, simulate_reading, type_text_human_like


@dataclass
class CommentResult:
    """Result of a comment operation."""
    success: bool
    post_url: str
    comment_text: str
    error_message: Optional[str] = None
    commented_at: Optional[datetime] = None


class CommentGenerator:
    """Generates comments using AI."""
    
    def __init__(self, ai_client: OpenRouterClient):
        self.ai_client = ai_client
    
    async def generate(
        self,
        post: Post,
        style: str = "engaging",
        context: Optional[str] = None
    ) -> Optional[str]:
        """
        Generate a comment for a post.
        
        Args:
            post: Post to comment on
            style: Comment style (engaging, supportive, questioning, etc.)
            context: Optional context about the account/persona
            
        Returns:
            Generated comment text or None
        """
        try:
            comment = await self.ai_client.generate_comment(
                post_text=post.text,
                context=context,
                tone=style,
                language="ru"  # Can be made configurable
            )
            
            return comment
            
        except Exception as e:
            logger.error(f"Comment generation failed: {e}")
            return None


class Commenter:
    """
    Main commenting controller.
    
    Orchestrates:
    - Post searching
    - Post filtering
    - Comment generation
    - Comment submission
    - Rate limiting
    """
    
    # Selectors for comment UI
    SELECTORS = {
        "comment_button": 'button[aria-label*="Reply"]',
        "comment_input": '[contenteditable="true"]',
        "submit_button": 'button:has-text("Post")',
        "comment_text": '[data-testid="comment-text"]',
    }
    
    def __init__(
        self,
        account: Account,
        engine: BaseBrowserEngine,
        ai_client: OpenRouterClient,
        auth_session: ThreadsSession,
        filter_config: Optional[FilterConfig] = None
    ):
        self.account = account
        self.engine = engine
        self.ai_client = ai_client
        self.auth_session = auth_session
        
        self.searcher = PostSearcher(engine)
        self.filter = PostFilter(filter_config or FilterConfig())
        self.generator = CommentGenerator(ai_client)
        self.registry = get_global_registry()
        
        self._comments_today = 0
        self._last_comment_time: Optional[datetime] = None
    
    async def run_cycle(
        self,
        keywords: Optional[List[str]] = None,
        hashtags: Optional[List[str]] = None,
        accounts: Optional[List[str]] = None,
        max_comments: int = 5,
        comment_style: str = "engaging",
        min_delay_seconds: int = 60,
    ) -> List[CommentResult]:
        """
        Run one commenting cycle.
        
        Args:
            keywords: Keywords to search for
            hashtags: Hashtags to search for
            accounts: Accounts to fetch posts from
            max_comments: Maximum comments to post in this cycle
            comment_style: Style of comments to generate
            min_delay_seconds: Minimum delay between comments
            
        Returns:
            List of comment results
        """
        results = []
        
        try:
            logger.info(f"Starting comment cycle for {self.account.username}")
            
            # Ensure logged in
            auth_result = await self.auth_session.ensure_logged_in()
            if not auth_result.success:
                logger.error(f"Auth failed: {auth_result.error_message}")
                return results
            
            # Search for posts
            posts = await self.searcher.search(
                keywords=keywords,
                hashtags=hashtags,
                accounts=accounts,
                max_results=30
            )
            
            if not posts:
                logger.info("No posts found to comment on")
                return results
            
            # Get already commented URLs
            commented_urls = self.registry.get_all_commented_urls()
            
            # Filter posts
            filtered_posts = self.filter.filter_posts(posts, commented_urls)
            
            if not filtered_posts:
                logger.info("No posts passed filters")
                return results
            
            # Comment on posts
            for post in filtered_posts[:max_comments]:
                # Check rate limits
                if not self._can_comment(min_delay_seconds):
                    logger.warning("Rate limit reached, stopping cycle")
                    break
                
                # Check daily limit
                if self._comments_today >= 30:  # Configurable
                    logger.warning("Daily comment limit reached")
                    break
                
                # Check if already commented by this account
                if self.registry.is_commented(post.url, self.account.id):
                    logger.debug(f"Already commented on {post.url}")
                    continue
                
                # Generate and post comment
                result = await self._comment_on_post(post, comment_style)
                results.append(result)
                
                if result.success:
                    self._comments_today += 1
                    self._last_comment_time = datetime.now()
                    
                    # Register in global registry
                    self.registry.register_comment(
                        post_url=post.url,
                        account_id=self.account.id,
                        post_id=post.post_id,
                        comment_text=result.comment_text
                    )
                    
                    # Delay before next comment
                    if len(results) < max_comments:
                        delay = random.randint(min_delay_seconds, min_delay_seconds + 60)
                        logger.info(f"Waiting {delay}s before next comment...")
                        await asyncio.sleep(delay)
                
        except Exception as e:
            logger.exception(f"Comment cycle error: {e}")
        
        logger.info(f"Comment cycle completed: {sum(1 for r in results if r.success)}/{len(results)} successful")
        return results
    
    async def _comment_on_post(
        self,
        post: Post,
        style: str
    ) -> CommentResult:
        """Comment on a single post."""
        try:
            logger.info(f"Commenting on post by @{post.author_username}: {post.text[:50]}...")
            
            # Navigate to post
            await self.engine.navigate(post.url)
            await human_delay(2, 4)
            
            # Simulate reading
            await simulate_reading(self.engine)
            
            # Generate comment
            comment_text = await self.generator.generate(
                post=post,
                style=style,
                context=self.account.notes  # Use account notes as context
            )
            
            if not comment_text:
                return CommentResult(
                    success=False,
                    post_url=post.url,
                    comment_text="",
                    error_message="Failed to generate comment"
                )
            
            logger.info(f"Generated comment: {comment_text[:50]}...")
            
            # Open comment dialog
            comment_btn = await self.engine.find_element(
                self.SELECTORS["comment_button"]
            )
            
            if not comment_btn:
                # Try alternative
                comment_btn = await self.engine.find_element('button:has-text("Reply")')
            
            if not comment_btn:
                return CommentResult(
                    success=False,
                    post_url=post.url,
                    comment_text=comment_text,
                    error_message="Comment button not found"
                )
            
            await comment_btn.click()
            await human_delay(1, 2)
            
            # Find comment input
            comment_input = await self.engine.find_element(
                self.SELECTORS["comment_input"]
            )
            
            if not comment_input:
                return CommentResult(
                    success=False,
                    post_url=post.url,
                    comment_text=comment_text,
                    error_message="Comment input not found"
                )
            
            # Type comment
            await comment_input.click()
            await human_delay(0.3, 0.7)
            await self.engine.type_text(comment_input, comment_text, human_like=True)
            await human_delay(0.5, 1)
            
            # Submit comment
            submit_btn = await self.engine.find_element(
                self.SELECTORS["submit_button"]
            )
            
            if not submit_btn:
                submit_btn = await self.engine.find_element('button[type="submit"]')
            
            if submit_btn:
                await submit_btn.click()
                await human_delay(2, 4)
                
                # Verify comment was posted
                # This could check for the comment appearing on the page
                
                logger.info(f"Comment posted successfully on {post.url}")
                
                return CommentResult(
                    success=True,
                    post_url=post.url,
                    comment_text=comment_text,
                    commented_at=datetime.now()
                )
            else:
                return CommentResult(
                    success=False,
                    post_url=post.url,
                    comment_text=comment_text,
                    error_message="Submit button not found"
                )
                
        except Exception as e:
            logger.exception(f"Comment error on {post.url}: {e}")
            return CommentResult(
                success=False,
                post_url=post.url,
                comment_text="",
                error_message=str(e)
            )
    
    def _can_comment(self, min_delay_seconds: int) -> bool:
        """Check if commenting is allowed based on rate limits."""
        if self._last_comment_time:
            seconds_since_last = (datetime.now() - self._last_comment_time).total_seconds()
            if seconds_since_last < min_delay_seconds:
                logger.warning(f"Rate limit: {seconds_since_last:.0f}s since last comment")
                return False
        return True
    
    def can_comment(
        self,
        max_daily: int = 30,
        min_interval_minutes: int = 5
    ) -> bool:
        """
        Check if commenting is allowed based on limits.
        
        Args:
            max_daily: Maximum comments per day
            min_interval_minutes: Minimum minutes between comments
            
        Returns:
            True if commenting is allowed
        """
        if self._comments_today >= max_daily:
            logger.warning(f"Daily comment limit reached for {self.account.username}")
            return False
        
        if self._last_comment_time:
            minutes_since_last = (datetime.now() - self._last_comment_time).total_seconds() / 60
            if minutes_since_last < min_interval_minutes:
                logger.warning(f"Comment interval too short for {self.account.username}")
                return False
        
        return True
    
    def get_stats(self) -> Dict[str, Any]:
        """Get commenting statistics."""
        registry_stats = self.registry.get_account_stats(self.account.id)
        
        return {
            "comments_today": self._comments_today,
            "last_comment_time": self._last_comment_time.isoformat() if self._last_comment_time else None,
            "registry_stats": registry_stats,
        }
    
    def reset_daily_stats(self):
        """Reset daily comment counter."""
        self._comments_today = 0
