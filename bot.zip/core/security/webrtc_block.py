"""
WebRTC Blocking Module
Prevents IP leaks through WebRTC.
"""

from typing import Dict, Any
from loguru import logger


# JavaScript to inject for WebRTC blocking
WEBRTC_BLOCK_SCRIPT = """
(() => {
    'use strict';
    
    // Store original RTCPeerConnection
    const OriginalRTCPeerConnection = window.RTCPeerConnection || window.webkitRTCPeerConnection || window.mozRTCPeerConnection;
    
    if (!OriginalRTCPeerConnection) {
        return;
    }
    
    // Create mock RTCPeerConnection
    function MockRTCPeerConnection(config) {
        // Call original constructor but intercept methods
        const pc = new OriginalRTCPeerConnection(config);
        
        // Override createOffer to filter candidates
        const originalCreateOffer = pc.createOffer.bind(pc);
        pc.createOffer = function(options) {
            return originalCreateOffer(options).then(offer => {
                if (offer && offer.sdp) {
                    // Remove all ICE candidates
                    offer.sdp = offer.sdp.replace(/a=candidate:[^\\r\\n]*\\r\\n/g, '');
                }
                return offer;
            });
        };
        
        // Override setLocalDescription to filter candidates
        const originalSetLocalDescription = pc.setLocalDescription.bind(pc);
        pc.setLocalDescription = function(description) {
            if (description && description.sdp) {
                description.sdp = description.sdp.replace(/a=candidate:[^\\r\\n]*\\r\\n/g, '');
            }
            return originalSetLocalDescription(description);
        };
        
        // Override addIceCandidate to block all candidates
        pc.addIceCandidate = function(candidate) {
            // Silently reject all ICE candidates
            return Promise.resolve();
        };
        
        // Override onicecandidate handler
        Object.defineProperty(pc, 'onicecandidate', {
            set: function(handler) {
                // Never call the handler with real candidates
            },
            get: function() {
                return null;
            }
        });
        
        return pc;
    }
    
    // Replace global RTCPeerConnection
    window.RTCPeerConnection = MockRTCPeerConnection;
    window.webkitRTCPeerConnection = MockRTCPeerConnection;
    if (window.mozRTCPeerConnection) {
        window.mozRTCPeerConnection = MockRTCPeerConnection;
    }
    
    // Also block getUserMedia if it exists
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
        navigator.mediaDevices.getUserMedia = function(constraints) {
            // Return rejected promise to block camera/microphone access
            return Promise.reject(new DOMException('Permission denied', 'NotAllowedError'));
        };
    }
    
    // Block enumerateDevices
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        navigator.mediaDevices.enumerateDevices = function() {
            return Promise.resolve([]);
        };
    }
    
    // Set WebRTC handling policy via Chrome API if available
    if (typeof chrome !== 'undefined' && chrome.privacy && chrome.privacy.network) {
        try {
            chrome.privacy.network.webRTCIPHandlingPolicy.set({
                value: 'disable_non_proxied_udp'
            });
        } catch (e) {
            // Ignore errors
        }
    }
    
    console.log('[AntiDetect] WebRTC blocking active');
})();
"""


class WebRTCBlocker:
    """
    Blocks WebRTC to prevent IP address leaks.
    
    Uses both CDP commands and JavaScript injection for maximum protection.
    """
    
    def __init__(self):
        self.is_active = False
    
    async def apply(self, engine) -> bool:
        """
        Apply WebRTC blocking to browser engine.
        
        Args:
            engine: Browser engine instance
        
        Returns:
            True if successful
        """
        try:
            success = True
            
            # Method 1: CDP command to set WebRTC policy
            try:
                await engine.cdp_execute(
                    "Network.setWebRTCIPHandlingPolicy",
                    {"policy": "disable_non_proxied_udp"}
                )
                logger.debug("WebRTC policy set via CDP")
            except Exception as e:
                logger.debug(f"CDP WebRTC policy failed: {e}")
                success = False
            
            # Method 2: Inject blocking script
            try:
                await engine.cdp_execute(
                    "Page.addScriptToEvaluateOnNewDocument",
                    {"source": WEBRTC_BLOCK_SCRIPT}
                )
                logger.debug("WebRTC blocking script injected")
            except Exception as e:
                logger.debug(f"Script injection failed: {e}")
                success = False
            
            self.is_active = success
            
            if success:
                logger.info("WebRTC blocking activated")
            
            return success
            
        except Exception as e:
            logger.error(f"WebRTC blocking failed: {e}")
            return False
    
    async def verify(self, engine) -> Dict[str, Any]:
        """
        Verify WebRTC is blocked.
        
        Args:
            engine: Browser engine
        
        Returns:
            Verification results
        """
        try:
            result = await engine.execute_script("""
                (() => {
                    const results = {
                        rtcPeerConnectionAvailable: typeof RTCPeerConnection !== 'undefined',
                        rtcPeerConnectionIsMock: false,
                        webkitRtcAvailable: typeof webkitRTCPeerConnection !== 'undefined',
                        mozRtcAvailable: typeof mozRTCPeerConnection !== 'undefined',
                        mediaDevicesAvailable: !!(navigator.mediaDevices),
                        getUserMediaAvailable: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
                        enumerateDevicesAvailable: !!(navigator.mediaDevices && navigator.mediaDevices.enumerateDevices)
                    };
                    
                    // Check if RTCPeerConnection is our mock
                    if (results.rtcPeerConnectionAvailable) {
                        const pc = new RTCPeerConnection();
                        results.rtcPeerConnectionIsMock = typeof pc.addIceCandidate === 'function';
                    }
                    
                    return results;
                })();
            """)
            
            return {
                "blocked": result.get('rtcPeerConnectionIsMock', False),
                "details": result
            }
            
        except Exception as e:
            logger.error(f"WebRTC verification failed: {e}")
            return {"blocked": False, "error": str(e)}


# Singleton instance
_blocker: WebRTCBlocker = None


def get_webrtc_blocker() -> WebRTCBlocker:
    """Get WebRTC blocker singleton."""
    global _blocker
    if _blocker is None:
        _blocker = WebRTCBlocker()
    return _blocker
