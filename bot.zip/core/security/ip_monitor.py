"""
IP Monitor Module
Monitors and prevents IP leaks, manages geolocation.
"""

import asyncio
import aiohttp
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass
from loguru import logger


@dataclass
class GeoLocation:
    """Geolocation data."""
    country: str
    country_code: str
    region: str
    city: str
    latitude: float
    longitude: float
    timezone: str
    isp: str
    ip: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "country": self.country,
            "country_code": self.country_code,
            "region": self.region,
            "city": self.city,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "timezone": self.timezone,
            "isp": self.isp,
            "ip": self.ip,
        }


class IPMonitor:
    """
    Monitors IP addresses and geolocation.
    
    Features:
    - Detect proxy IP and geolocation
    - Verify no real IP leaks
    - Synchronize browser timezone with proxy location
    """
    
    # Free geolocation APIs
    GEOLOCATION_APIS = [
        "http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,lat,lon,timezone,isp,query",
        "https://ipapi.co/{ip}/json/",
    ]
    
    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._cached_geo: Dict[str, GeoLocation] = {}
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=10)
            )
        return self._session
    
    async def get_ip_geolocation(
        self,
        ip: Optional[str] = None,
        proxy: Optional[str] = None
    ) -> Optional[GeoLocation]:
        """
        Get geolocation for IP address.
        
        Args:
            ip: IP to lookup (None for current IP via proxy)
            proxy: Proxy to use for request
        
        Returns:
            GeoLocation data or None
        """
        # Check cache
        cache_key = f"{ip or 'current'}_{proxy or 'direct'}"
        if cache_key in self._cached_geo:
            return self._cached_geo[cache_key]
        
        try:
            session = await self._get_session()
            
            # Use first API (ip-api.com)
            url = self.GEOLOCATION_APIS[0].format(ip=ip or "")
            
            proxy_url = None
            if proxy:
                proxy_url = proxy if proxy.startswith('http') else f"http://{proxy}"
            
            async with session.get(url, proxy=proxy_url) as response:
                if response.status != 200:
                    logger.warning(f"Geolocation API returned {response.status}")
                    return None
                
                data = await response.json()
                
                if data.get('status') != 'success':
                    logger.warning(f"Geolocation API error: {data.get('message')}")
                    return None
                
                geo = GeoLocation(
                    country=data.get('country', 'Unknown'),
                    country_code=data.get('countryCode', 'US'),
                    region=data.get('regionName', 'Unknown'),
                    city=data.get('city', 'Unknown'),
                    latitude=data.get('lat', 0.0),
                    longitude=data.get('lon', 0.0),
                    timezone=data.get('timezone', 'UTC'),
                    isp=data.get('isp', 'Unknown'),
                    ip=data.get('query', 'Unknown'),
                )
                
                # Cache result
                self._cached_geo[cache_key] = geo
                
                logger.info(f"Geolocation: {geo.city}, {geo.country} ({geo.ip})")
                
                return geo
                
        except Exception as e:
            logger.error(f"Failed to get geolocation: {e}")
            return None
    
    async def detect_ip_leak(
        self,
        engine,
        expected_proxy: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Detect if real IP is leaking through browser.
        
        Args:
            engine: Browser engine
            expected_proxy: Expected proxy IP
        
        Returns:
            Leak detection results
        """
        try:
            # Navigate to IP check page
            await engine.navigate("https://ipleak.net/")
            
            # Wait for page to load
            await asyncio.sleep(3)
            
            # Get detected IPs from page
            detected_ips = await engine.execute_script("""
                (() => {
                    const ips = [];
                    // Look for IP addresses in page content
                    const elements = document.querySelectorAll('*');
                    const ipRegex = /\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b/g;
                    
                    elements.forEach(el => {
                        if (el.textContent) {
                            const matches = el.textContent.match(ipRegex);
                            if (matches) {
                                ips.push(...matches);
                            }
                        }
                    });
                    
                    return [...new Set(ips)];
                })();
            """)
            
            # Also check via WebRTC
            webrtc_ips = await engine.execute_script("""
                (async () => {
                    const ips = [];
                    try {
                        const pc = new RTCPeerConnection({iceServers: []});
                        pc.createDataChannel('');
                        const offer = await pc.createOffer();
                        const sdp = offer.sdp;
                        
                        // Extract IP from SDP
                        const ipRegex = /c=IN IP4 ([0-9.]+)/;
                        const match = sdp.match(ipRegex);
                        if (match) {
                            ips.push(match[1]);
                        }
                    } catch (e) {}
                    return ips;
                })();
            """)
            
            # Analyze results
            all_detected_ips = set(detected_ips or [])
            if webrtc_ips:
                all_detected_ips.update(webrtc_ips)
            
            # Check for potential leaks
            leaks = []
            
            if expected_proxy:
                # Check if expected proxy IP is detected
                proxy_ip = expected_proxy.split(':')[0] if ':' in expected_proxy else expected_proxy
                proxy_detected = any(proxy_ip in ip for ip in all_detected_ips)
                
                if not proxy_detected:
                    leaks.append({
                        "type": "proxy_not_detected",
                        "message": "Expected proxy IP not detected",
                        "expected": expected_proxy,
                        "found": list(all_detected_ips)
                    })
            
            # Check for WebRTC leaks
            if webrtc_ips:
                for ip in webrtc_ips:
                    # Check if it's a private/local IP
                    if ip.startswith(('192.168.', '10.', '172.16.', '127.')):
                        leaks.append({
                            "type": "webrtc_local_ip_leak",
                            "message": "WebRTC is leaking local IP address",
                            "ip": ip
                        })
            
            return {
                "leak_detected": len(leaks) > 0,
                "leaks": leaks,
                "detected_ips": list(all_detected_ips),
                "webrtc_ips": webrtc_ips or [],
            }
            
        except Exception as e:
            logger.error(f"IP leak detection failed: {e}")
            return {
                "leak_detected": True,
                "error": str(e),
                "leaks": [{"type": "detection_error", "message": str(e)}]
            }
    
    async def apply_geolocation_to_browser(
        self,
        engine,
        geo: GeoLocation
    ) -> bool:
        """
        Apply geolocation settings to browser.
        
        Args:
            engine: Browser engine
            geo: Geolocation data
        
        Returns:
            True if successful
        """
        try:
            success = True
            
            # Set timezone
            try:
                await engine.cdp_execute(
                    "Emulation.setTimezoneOverride",
                    {"timezoneId": geo.timezone}
                )
                logger.debug(f"Timezone set to {geo.timezone}")
            except Exception as e:
                logger.warning(f"Failed to set timezone: {e}")
                success = False
            
            # Set geolocation
            try:
                await engine.cdp_execute(
                    "Emulation.setGeolocationOverride",
                    {
                        "latitude": geo.latitude,
                        "longitude": geo.longitude,
                        "accuracy": 100
                    }
                )
                logger.debug(f"Geolocation set to ({geo.latitude}, {geo.longitude})")
            except Exception as e:
                logger.warning(f"Failed to set geolocation: {e}")
                success = False
            
            # Inject navigator.geolocation override
            script = f"""
            (() => {{
                const mockPosition = {{
                    coords: {{
                        latitude: {geo.latitude},
                        longitude: {geo.longitude},
                        accuracy: 100,
                        altitude: null,
                        altitudeAccuracy: null,
                        heading: null,
                        speed: null
                    }},
                    timestamp: Date.now()
                }};
                
                navigator.geolocation.getCurrentPosition = function(success, error, options) {{
                    setTimeout(() => success(mockPosition), 100);
                }};
                
                navigator.geolocation.watchPosition = function(success, error, options) {{
                    setTimeout(() => success(mockPosition), 100);
                    return 1;
                }};
            }})();
            """
            
            try:
                await engine.cdp_execute(
                    "Page.addScriptToEvaluateOnNewDocument",
                    {"source": script}
                )
                logger.debug("Geolocation override script injected")
            except Exception as e:
                logger.warning(f"Failed to inject geolocation script: {e}")
                success = False
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to apply geolocation: {e}")
            return False
    
    async def close(self):
        """Close HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()


# Singleton instance
_monitor: Optional[IPMonitor] = None


def get_ip_monitor() -> IPMonitor:
    """Get IP monitor singleton."""
    global _monitor
    if _monitor is None:
        _monitor = IPMonitor()
    return _monitor
