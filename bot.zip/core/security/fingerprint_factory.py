"""
Fingerprint Factory Module
Dynamic browser fingerprint generation and rotation.
"""

import random
import hashlib
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime

from loguru import logger


# Common Chrome versions for rotation
CHROME_VERSIONS = [
    "120.0.6099.130", "120.0.6099.109", "120.0.6099.71",
    "121.0.6167.140", "121.0.6167.86", "121.0.6167.85",
    "122.0.6261.95", "122.0.6261.69", "122.0.6261.58",
    "123.0.6312.86", "123.0.6312.59", "123.0.6312.46",
]

# Common WebGL vendors/renderers for rotation
WEBGL_VENDORS = [
    "Google Inc. (NVIDIA)",
    "Google Inc. (AMD)",
    "Google Inc. (Intel)",
    "Google Inc.",
]

WEBGL_RENDERERS = [
    "ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (AMD, AMD Radeon RX 6800 XT Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (Intel, Intel(R) UHD Graphics 770 Direct3D11 vs_5_0 ps_5_0, D3D11)",
    "ANGLE (Intel, Intel(R) Iris(TM) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)",
]

# Font lists for rotation
COMMON_FONTS = [
    "Arial", "Arial Black", "Arial Narrow", "Calibri", "Cambria",
    "Comic Sans MS", "Courier New", "Georgia", "Impact", "Lucida Console",
    "Lucida Sans Unicode", "Microsoft Sans Serif", "Palatino Linotype",
    "Segoe UI", "Tahoma", "Times New Roman", "Trebuchet MS", "Verdana",
]

EXTRA_FONTS = [
    "Consolas", "Constantia", "Corbel", "Franklin Gothic Medium",
    "Gabriola", "Gill Sans MT", "Leelawadee", "Malgun Gothic",
    "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue",
    "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft YaHei",
    "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text",
]

# Screen resolutions for viewport rotation
SCREEN_RESOLUTIONS = [
    {"width": 1920, "height": 1080},
    {"width": 1920, "height": 1200},
    {"width": 2560, "height": 1440},
    {"width": 2560, "height": 1600},
    {"width": 3840, "height": 2160},
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1536, "height": 864},
    {"width": 1680, "height": 1050},
]

# Color depths
COLOR_DEPTHS = [24, 32]

# Pixel ratios
PIXEL_RATIOS = [1, 1.25, 1.5, 2]


@dataclass
class BrowserFingerprint:
    """Complete browser fingerprint configuration."""
    
    # Browser info
    chrome_version: str
    user_agent: str
    platform: str
    
    # Screen info
    screen_resolution: Dict[str, int]
    color_depth: int
    pixel_ratio: float
    
    # WebGL info
    webgl_vendor: str
    webgl_renderer: str
    
    # Font info
    fonts: List[str]
    
    # Navigator info
    language: str
    languages: List[str]
    
    # Hardware info
    hardware_concurrency: int
    device_memory: int
    
    # Generated timestamp
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "chrome_version": self.chrome_version,
            "user_agent": self.user_agent,
            "platform": self.platform,
            "screen_resolution": self.screen_resolution,
            "color_depth": self.color_depth,
            "pixel_ratio": self.pixel_ratio,
            "webgl_vendor": self.webgl_vendor,
            "webgl_renderer": self.webgl_renderer,
            "fonts": self.fonts,
            "language": self.language,
            "languages": self.languages,
            "hardware_concurrency": self.hardware_concurrency,
            "device_memory": self.device_memory,
            "created_at": self.created_at.isoformat(),
        }
    
    def get_hash(self) -> str:
        """Get unique hash of fingerprint."""
        data = f"{self.chrome_version}:{self.user_agent}:{self.webgl_renderer}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]


class FingerprintFactory:
    """
    Factory for generating and rotating browser fingerprints.
    
    Features:
    - Random fingerprint generation
    - Consistent fingerprints per account
    - Periodic rotation
    - Fingerprint diversity tracking
    """
    
    def __init__(self):
        self._fingerprints: Dict[str, BrowserFingerprint] = {}
        self._rotation_counter: Dict[str, int] = {}
        self._used_hashes: set = set()
    
    def generate(
        self,
        account_id: Optional[str] = None,
        seed: Optional[str] = None,
        locale: str = "en-US"
    ) -> BrowserFingerprint:
        """
        Generate a new browser fingerprint.
        
        Args:
            account_id: Optional account ID for consistent fingerprints
            seed: Optional seed for reproducible generation
            locale: Browser locale
        
        Returns:
            BrowserFingerprint instance
        """
        # Use seed for reproducibility
        if seed:
            random.seed(seed)
        elif account_id:
            random.seed(account_id)
        else:
            random.seed()
        
        # Select components
        chrome_version = random.choice(CHROME_VERSIONS)
        screen_res = random.choice(SCREEN_RESOLUTIONS)
        webgl_vendor = random.choice(WEBGL_VENDORS)
        webgl_renderer = random.choice(WEBGL_RENDERERS)
        
        # Generate font list (base + random extras)
        num_extra_fonts = random.randint(2, 5)
        fonts = COMMON_FONTS.copy()
        fonts.extend(random.sample(EXTRA_FONTS, num_extra_fonts))
        
        # Build user agent
        platform = "Win32"
        user_agent = (
            f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) "
            f"Chrome/{chrome_version.split('.')[0]}.0.0.0 Safari/537.36"
        )
        
        # Hardware specs
        hardware_concurrency = random.choice([4, 6, 8, 12, 16])
        device_memory = random.choice([4, 8, 16, 32])
        
        fingerprint = BrowserFingerprint(
            chrome_version=chrome_version,
            user_agent=user_agent,
            platform=platform,
            screen_resolution=screen_res,
            color_depth=random.choice(COLOR_DEPTHS),
            pixel_ratio=random.choice(PIXEL_RATIOS),
            webgl_vendor=webgl_vendor,
            webgl_renderer=webgl_renderer,
            fonts=fonts,
            language=locale,
            languages=[locale, locale.split('-')[0]],
            hardware_concurrency=hardware_concurrency,
            device_memory=device_memory,
        )
        
        # Store if account_id provided
        if account_id:
            self._fingerprints[account_id] = fingerprint
        
        # Track hash
        self._used_hashes.add(fingerprint.get_hash())
        
        logger.debug(f"Generated fingerprint: {fingerprint.get_hash()}")
        
        return fingerprint
    
    def get_for_account(self, account_id: str) -> BrowserFingerprint:
        """
        Get or create fingerprint for account.
        
        Args:
            account_id: Account identifier
        
        Returns:
            BrowserFingerprint for account
        """
        if account_id not in self._fingerprints:
            self._fingerprints[account_id] = self.generate(
                account_id=account_id,
                seed=account_id
            )
        
        return self._fingerprints[account_id]
    
    def should_rotate(self, account_id: str, action_threshold: int = 100) -> bool:
        """
        Check if fingerprint should be rotated.
        
        Args:
            account_id: Account identifier
            action_threshold: Number of actions before rotation
        
        Returns:
            True if rotation needed
        """
        count = self._rotation_counter.get(account_id, 0)
        return count >= action_threshold
    
    def increment_counter(self, account_id: str) -> None:
        """Increment action counter for account."""
        self._rotation_counter[account_id] = self._rotation_counter.get(account_id, 0) + 1
    
    def rotate(self, account_id: str) -> BrowserFingerprint:
        """
        Rotate fingerprint for account.
        
        Args:
            account_id: Account identifier
        
        Returns:
            New BrowserFingerprint
        """
        # Generate new fingerprint with different seed
        seed = f"{account_id}_{datetime.now().timestamp()}"
        fingerprint = self.generate(account_id=account_id, seed=seed)
        
        # Reset counter
        self._rotation_counter[account_id] = 0
        
        logger.info(f"Rotated fingerprint for account {account_id}: {fingerprint.get_hash()}")
        
        return fingerprint
    
    def get_injection_script(self, fingerprint: BrowserFingerprint) -> str:
        """
        Generate JavaScript to inject fingerprint into page.
        
        Args:
            fingerprint: Fingerprint to inject
        
        Returns:
            JavaScript code
        """
        fonts_json = str(fingerprint.fonts).replace("'", '"')
        languages_json = str(fingerprint.languages).replace("'", '"')
        
        script = f"""
        (() => {{
            'use strict';
            
            const fingerprint = {{
                userAgent: '{fingerprint.user_agent}',
                platform: '{fingerprint.platform}',
                language: '{fingerprint.language}',
                languages: {languages_json},
                hardwareConcurrency: {fingerprint.hardware_concurrency},
                deviceMemory: {fingerprint.device_memory},
                screen: {{
                    width: {fingerprint.screen_resolution['width']},
                    height: {fingerprint.screen_resolution['height']},
                    colorDepth: {fingerprint.color_depth},
                    pixelDepth: {fingerprint.color_depth}
                }},
                devicePixelRatio: {fingerprint.pixel_ratio}
            }};
            
            // Override navigator properties
            Object.defineProperty(navigator, 'userAgent', {{
                get: () => fingerprint.userAgent
            }});
            
            Object.defineProperty(navigator, 'platform', {{
                get: () => fingerprint.platform
            }});
            
            Object.defineProperty(navigator, 'language', {{
                get: () => fingerprint.language
            }});
            
            Object.defineProperty(navigator, 'languages', {{
                get: () => fingerprint.languages
            }});
            
            Object.defineProperty(navigator, 'hardwareConcurrency', {{
                get: () => fingerprint.hardwareConcurrency
            }});
            
            if ('deviceMemory' in navigator) {{
                Object.defineProperty(navigator, 'deviceMemory', {{
                    get: () => fingerprint.deviceMemory
                }});
            }}
            
            // Override screen properties
            Object.defineProperty(screen, 'width', {{
                get: () => fingerprint.screen.width
            }});
            
            Object.defineProperty(screen, 'height', {{
                get: () => fingerprint.screen.height
            }});
            
            Object.defineProperty(screen, 'colorDepth', {{
                get: () => fingerprint.screen.colorDepth
            }});
            
            Object.defineProperty(screen, 'pixelDepth', {{
                get: () => fingerprint.screen.pixelDepth
            }});
            
            // Override devicePixelRatio
            Object.defineProperty(window, 'devicePixelRatio', {{
                get: () => fingerprint.devicePixelRatio
            }});
            
            // Override WebGL
            const getParameter = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {{
                if (parameter === 37445) {{  // UNMASKED_VENDOR_WEBGL
                    return '{fingerprint.webgl_vendor}';
                }}
                if (parameter === 37446) {{  // UNMASKED_RENDERER_WEBGL
                    return '{fingerprint.webgl_renderer}';
                }}
                return getParameter(parameter);
            }};
            
            // Override fonts (if queryable)
            if (document.fonts && document.fonts.check) {{
                const originalCheck = document.fonts.check.bind(document.fonts);
                document.fonts.check = function(font, text) {{
                    const fontName = font.match(/^[\"']?([^\"']+)[\"']?/);
                    if (fontName && fingerprint.fonts.includes(fontName[1])) {{
                        return true;
                    }}
                    return originalCheck(font, text);
                }};
            }}
            
            console.log('[AntiDetect] Fingerprint injected');
        }})();
        """
        
        return script
    
    def get_diversity_stats(self) -> Dict[str, Any]:
        """Get statistics about fingerprint diversity."""
        return {
            "total_generated": len(self._used_hashes),
            "active_accounts": len(self._fingerprints),
            "unique_hashes": len(self._used_hashes),
        }


# Singleton instance
_factory: Optional[FingerprintFactory] = None


def get_fingerprint_factory() -> FingerprintFactory:
    """Get fingerprint factory singleton."""
    global _factory
    if _factory is None:
        _factory = FingerprintFactory()
    return _factory
