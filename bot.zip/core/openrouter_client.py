"""
OpenRouter AI Client Module
Handles AI content generation with multi-level fallback strategy.
"""

import hashlib
import json
import asyncio
import sqlite3
import os
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass
from pathlib import Path

import aiohttp
from loguru import logger


@dataclass
class ModelConfig:
    """AI Model configuration."""
    name: str
    priority: int
    max_retries: int = 3
    timeout: int = 60


# Актуальные бесплатные модели OpenRouter (на март 2026)
# Чтобы получить свежий список, используйте метод get_available_models()
DEFAULT_MODELS = [
    ModelConfig("google/gemini-2.0-flash-exp:free", 1, max_retries=2),
    ModelConfig("mistralai/mistral-7b-instruct:free", 2, max_retries=2),
    ModelConfig("meta-llama/llama-3.2-3b-instruct:free", 3, max_retries=2),
    ModelConfig("openrouter/auto", 4, max_retries=1),
]


class AICache:
    """SQLite-based cache for AI responses."""
    
    def __init__(self, db_path: str = "config/task_queue.db"):
        # Use Documents/ThreadsBot
        base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
        self.db_path = base_dir / "task_queue.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
    
    def _init_db(self):
        """Initialize cache table."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS ai_cache (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    prompt_hash TEXT UNIQUE NOT NULL,
                    prompt TEXT NOT NULL,
                    response TEXT NOT NULL,
                    model TEXT NOT NULL,
                    cache_type TEXT NOT NULL,  -- 'post' or 'comment'
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_cache_hash ON ai_cache(prompt_hash)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_cache_expires ON ai_cache(expires_at)
            """)
            conn.commit()
    
    def _hash_prompt(self, prompt: str) -> str:
        """Create hash of prompt for lookup."""
        return hashlib.sha256(prompt.encode()).hexdigest()[:32]
    
    def get(self, prompt: str, cache_type: str = "post") -> Optional[str]:
        """Get cached response if not expired."""
        prompt_hash = self._hash_prompt(prompt)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """SELECT response FROM ai_cache 
                   WHERE prompt_hash = ? AND cache_type = ? AND expires_at > datetime('now')""",
                (prompt_hash, cache_type)
            )
            result = cursor.fetchone()
            
            if result:
                logger.debug(f"Cache hit for {cache_type} prompt")
                return result[0]
            
            return None
    
    def set(self, prompt: str, response: str, model: str, cache_type: str = "post"):
        """Cache a response with TTL."""
        prompt_hash = self._hash_prompt(prompt)
        
        # TTL: 1 hour for comments, 24 hours for posts
        ttl_hours = 1 if cache_type == "comment" else 24
        expires_at = datetime.now() + timedelta(hours=ttl_hours)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO ai_cache 
                   (prompt_hash, prompt, response, model, cache_type, expires_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (prompt_hash, prompt, response, model, cache_type, expires_at)
            )
            conn.commit()
            logger.debug(f"Cached {cache_type} response (expires: {expires_at})")
    
    def clear_expired(self):
        """Remove expired cache entries."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM ai_cache WHERE expires_at < datetime('now')")
            conn.commit()


class OpenRouterClient:
    """
    OpenRouter AI client with fallback strategy and caching.
    
    Features:
    - Multi-level model fallback
    - Response caching with TTL
    - Rate limit handling
    - Retry logic with exponential backoff
    """
    
    BASE_URL = "https://openrouter.ai/api/v1"
    
    def __init__(
        self,
        api_key: str,
        models: Optional[List[ModelConfig]] = None,
        cache_db_path: str = "config/task_queue.db"
    ):
        self.api_key = api_key
        self.models = models or DEFAULT_MODELS.copy()
        self.cache = AICache(cache_db_path)
        
        self._session: Optional[aiohttp.ClientSession] = None
        self._current_model_index = 0
        self._rate_limited_until: Optional[datetime] = None
        
        # Stats
        self.requests_made = 0
        self.cache_hits = 0
        self.fallbacks_used = 0
        
        logger.info(f"OpenRouterClient initialized with {len(self.models)} models")
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "HTTP-Referer": "https://threads-automator.local",
                    "X-Title": "Threads Automation Bot",
                },
                timeout=aiohttp.ClientTimeout(total=120)
            )
        return self._session
    
    def _get_current_model(self) -> ModelConfig:
        """Get currently selected model."""
        return self.models[self._current_model_index]
    
    def _switch_to_next_model(self):
        """Switch to next model in fallback chain."""
        self._current_model_index = (self._current_model_index + 1) % len(self.models)
        self.fallbacks_used += 1
        logger.warning(f"Switched to fallback model: {self._get_current_model().name}")
    
    async def _make_request(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 500
    ) -> Optional[str]:
        """Make single API request to current model."""
        
        # Check rate limiting
        if self._rate_limited_until and datetime.now() < self._rate_limited_until:
            wait_seconds = (self._rate_limited_until - datetime.now()).total_seconds()
            logger.warning(f"Rate limited, waiting {wait_seconds:.0f}s")
            await asyncio.sleep(wait_seconds)
        
        model = self._get_current_model()
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model.name,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        
        session = await self._get_session()
        
        try:
            async with session.post(
                f"{self.BASE_URL}/chat/completions",
                json=payload
            ) as response:
                
                self.requests_made += 1
                
                if response.status == 429:
                    # Rate limited - switch model
                    logger.warning(f"Rate limit hit for {model.name}")
                    self._rate_limited_until = datetime.now() + timedelta(minutes=1)
                    return None
                
                if response.status == 401:
                    logger.error("Invalid API key")
                    raise ValueError("Invalid OpenRouter API key")
                
                response.raise_for_status()
                
                data = await response.json()
                
                if "choices" in data and len(data["choices"]) > 0:
                    content = data["choices"][0]["message"].get("content")
                    if content is not None:
                        logger.info(f"Successfully generated content with {model.name}")
                        return content.strip()
                    else:
                        logger.error(f"Model {model.name} returned empty content")
                        return None
                
                logger.error(f"Unexpected response format: {data}")
                return None
                
        except asyncio.TimeoutError:
            logger.warning(f"Timeout for {model.name}")
            return None
        except aiohttp.ClientError as e:
            logger.error(f"Request failed for {model.name}: {e}")
            return None
    
    async def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        cache_type: str = "post",
        temperature: float = 0.7,
        max_tokens: int = 500,
        use_cache: bool = True
    ) -> Optional[str]:
        """
        Generate content with automatic fallback.
        
        Args:
            prompt: User prompt
            system_prompt: Optional system instructions
            cache_type: 'post' or 'comment' (affects TTL)
            temperature: Creativity (0.0 - 1.0)
            max_tokens: Maximum response length
            use_cache: Whether to use caching
            
        Returns:
            Generated text or None if all models failed
        """
        # Check cache first
        if use_cache:
            cached = self.cache.get(prompt, cache_type)
            if cached:
                self.cache_hits += 1
                return cached
        
        # Try each model in fallback chain
        initial_model_index = self._current_model_index
        attempts = 0
        max_attempts = sum(m.max_retries for m in self.models)
        
        while attempts < max_attempts:
            model = self._get_current_model()
            
            result = await self._make_request(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            if result:
                # Cache successful response
                if use_cache:
                    self.cache.set(prompt, result, model.name, cache_type)
                return result
            
            # Failed - try next model
            self._switch_to_next_model()
            attempts += 1
            
            # Small delay between retries
            await asyncio.sleep(0.5)
        
        # All models failed
        logger.error("All AI models failed to generate content")
        return None
    
    async def generate_post(
        self,
        topic: str,
        tone: str = "casual",
        max_length: int = 280,
        language: str = "ru"
    ) -> Optional[str]:
        """
        Generate a Threads post.
        
        Args:
            topic: Post topic/subject
            tone: Writing tone (casual, professional, funny, etc.)
            max_length: Maximum character count
            language: Output language
            
        Returns:
            Generated post text
        """
        system_prompt = f"""You are a social media content creator writing for Threads.
Write engaging, authentic posts that sound human and natural.
Rules:
- Maximum {max_length} characters
- Use appropriate hashtags (2-4 max)
- Avoid robotic or overly promotional language
- Match the requested tone
- Write in {language} language"""
        
        prompt = f"Write a {tone} Threads post about: {topic}"
        
        return await self.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            cache_type="post",
            temperature=0.8,
            max_tokens=300
        )
    
    async def generate_comment(
        self,
        post_text: str,
        context: Optional[str] = None,
        tone: str = "engaging",
        language: str = "ru"
    ) -> Optional[str]:
        """
        Generate a comment on a post.
        
        Args:
            post_text: The post being commented on
            context: Optional context about the account/persona
            tone: Comment tone (engaging, supportive, questioning, etc.)
            language: Output language
            
        Returns:
            Generated comment text
        """
        system_prompt = f"""You are writing a comment on a social media post.
Rules:
- Be authentic and human-sounding
- Keep it concise (under 100 characters ideally, max 200)
- React naturally to the post content
- Don't be overly promotional
- Write in {language} language"""
        
        if context:
            system_prompt += f"\nContext about you: {context}"
        
        prompt = f"""Post: "{post_text[:500]}"

Write a {tone} comment on this post:"""
        
        return await self.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            cache_type="comment",
            temperature=0.7,
            max_tokens=150
        )
    
    async def close(self):
        """Close HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def test_api_key(self) -> Dict[str, Any]:
        """
        Test if API key is valid.
        
        Returns:
            Dict with success status and account info
        """
        try:
            # Используем временную сессию без глобального таймаута, чтобы избежать проблем с asyncio.timeout
            async with aiohttp.ClientSession() as session:
                # Ограничиваем время выполнения через asyncio.timeout (доступен с Python 3.11)
                try:
                    async with asyncio.timeout(10):
                        async with session.get(f"{self.BASE_URL}/auth/key") as response:
                            if response.status == 200:
                                data = await response.json()
                                return {
                                    "success": True,
                                    "data": data.get("data", {}),
                                    "message": "API key is valid"
                                }
                            elif response.status == 401:
                                return {
                                    "success": False,
                                    "data": {},
                                    "message": "Invalid API key"
                                }
                            else:
                                return {
                                    "success": False,
                                    "data": {},
                                    "message": f"Unexpected response: {response.status}"
                                }
                except asyncio.TimeoutError:
                    logger.error("API key test timed out")
                    return {"success": False, "data": {}, "message": "Request timed out"}
                    
        except Exception as e:
            logger.error(f"API key test failed: {e}")
            return {
                "success": False,
                "data": {},
                "message": str(e)
            }
    
    async def get_available_models(self) -> List[Dict[str, Any]]:
        """
        Get list of available models from OpenRouter.
        
        Returns:
            List of model information
        """
        try:
            session = await self._get_session()
            
            async with session.get(
                f"{self.BASE_URL}/models",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("data", [])
                else:
                    logger.error(f"Failed to get models: {response.status}")
                    return []
                    
        except Exception as e:
            logger.error(f"Get models failed: {e}")
            return []
    
    def get_stats(self) -> Dict[str, Any]:
        """Get usage statistics."""
        return {
            "requests_made": self.requests_made,
            "cache_hits": self.cache_hits,
            "fallbacks_used": self.fallbacks_used,
            "current_model": self._get_current_model().name,
            "cache_size": self._get_cache_size(),
        }
    
    def _get_cache_size(self) -> int:
        """Get number of cached entries."""
        try:
            with sqlite3.connect(self.cache.db_path) as conn:
                cursor = conn.execute(
                    "SELECT COUNT(*) FROM ai_cache WHERE expires_at > datetime('now')"
                )
                return cursor.fetchone()[0]
        except Exception:
            return 0
    
    def get_detailed_stats(self) -> Dict[str, Any]:
        """Get detailed usage statistics including cache breakdown."""
        try:
            with sqlite3.connect(self.cache.db_path) as conn:
                # Cache by type
                cursor = conn.execute(
                    """SELECT cache_type, COUNT(*) 
                       FROM ai_cache 
                       WHERE expires_at > datetime('now')
                       GROUP BY cache_type"""
                )
                cache_by_type = {row[0]: row[1] for row in cursor.fetchall()}
                
                # Recent usage (last 24 hours)
                cursor = conn.execute(
                    """SELECT COUNT(*) FROM ai_cache 
                       WHERE created_at > datetime('now', '-1 day')"""
                )
                recent_caches = cursor.fetchone()[0]
                
                return {
                    "requests_made": self.requests_made,
                    "cache_hits": self.cache_hits,
                    "fallbacks_used": self.fallbacks_used,
                    "current_model": self._get_current_model().name,
                    "cache_total": self._get_cache_size(),
                    "cache_by_type": cache_by_type,
                    "recent_caches_24h": recent_caches,
                    "cache_hit_rate": self.cache_hits / max(self.requests_made, 1),
                }
        except Exception as e:
            logger.error(f"Failed to get detailed stats: {e}")
            return self.get_stats()


# Singleton instance с поддержкой смены ключа
_client_instance: Optional[OpenRouterClient] = None
_client_key: Optional[str] = None


def get_openrouter_client(
    api_key: Optional[str] = None,
    **kwargs
) -> Optional[OpenRouterClient]:
    """
    Get or create OpenRouterClient singleton.
    If api_key is provided and different from the stored key, a new client is created.
    """
    global _client_instance, _client_key

    if api_key is None:
        return _client_instance

    # Если ключ изменился или клиент ещё не создан, создаём новый
    if _client_instance is None or _client_key != api_key:
        _client_instance = OpenRouterClient(api_key, **kwargs)
        _client_key = api_key
        logger.info(f"Created new OpenRouter client with key: {api_key[:8]}...")
    else:
        logger.debug("Reusing existing OpenRouter client")

    return _client_instance