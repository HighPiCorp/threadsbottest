"""
Poster Module
Handles creation and publishing of posts on Threads.
"""

import asyncio
from typing import Optional, List, Dict, Any, Union
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from loguru import logger

from .account_manager import Account
from .engines.base_engine import BaseBrowserEngine
from .openrouter_client import OpenRouterClient
from .threads_auth import ThreadsSession
from .behavior import human_delay, think_delay, type_text_human_like, simulate_reading


@dataclass
class PostResult:
    """Result of post creation."""
    success: bool
    post_url: Optional[str]
    content: str
    error_message: Optional[str] = None
    posted_at: Optional[datetime] = None


class Poster:
    """
    Creates and publishes posts on Threads.

    Features:
    - AI-generated content (optional, can accept pre-generated text)
    - Image upload support
    - Human-like typing
    - Error handling and retries
    - Session management via ThreadsSession
    """

    # Selectors for Threads UI (may need updates as Threads changes)
    SELECTORS = {
        # Create post button (usually on home page)
        "create_post_button": 'a[href="/"]',  # Sometimes the logo is a link to home, but we need the actual create button
        # More reliable: find the "What's on your mind?" input or the + button
        "create_post_button_alt": '[aria-label="Create thread"]',
        "create_post_button_text": 'div:has-text("What\'s on your mind?")',
        
        # Text input area (contenteditable div)
        "text_input": '[contenteditable="true"]',
        
        # Submit button (usually "Post" or similar)
        "post_button": 'button:has-text("Post")',
        "post_button_disabled": 'button:has-text("Post"):disabled',
        
        # Image upload
        "add_image_button": '[aria-label="Add image"]',
        "file_input": 'input[type="file"]',
        
        # Success indicators
        "success_indicator": '[role="alert"]:has-text("posted")',
        "post_link": 'a[href*="/post/"]',
        
        # Character count (optional, for validation)
        "character_count": '[data-testid="character-count"]',
    }

    def __init__(
        self,
        account: Account,
        engine: BaseBrowserEngine,
        ai_client: Optional[OpenRouterClient] = None,
        auth_session: Optional[ThreadsSession] = None
    ):
        """
        Initialize Poster.

        Args:
            account: Account to post from
            engine: Browser engine instance (already started or will be started)
            ai_client: Optional OpenRouter client for content generation
            auth_session: Optional ThreadsSession for authentication (if None, will be created)
        """
        self.account = account
        self.engine = engine
        self.ai_client = ai_client
        self.auth_session = auth_session or ThreadsSession(account, engine)

        self._posts_today = 0
        self._last_post_time: Optional[datetime] = None

    async def ensure_authenticated(self) -> bool:
        """Ensure account is logged in."""
        auth_result = await self.auth_session.ensure_logged_in()
        if not auth_result.success:
            logger.error(f"Authentication failed for {self.account.username}: {auth_result.error_message}")
            return False
        return True

    async def create_post(
        self,
        topic: Optional[str] = None,
        content: Optional[str] = None,
        tone: str = "casual",
        image_path: Optional[Union[str, Path]] = None,
        preview_only: bool = False
    ) -> PostResult:
        """
        Create and publish a post.

        Either `topic` or `content` must be provided.
        If `topic` is given, content is generated via AI.
        If `content` is given, it's used directly.

        Args:
            topic: Post topic/subject (for AI generation)
            content: Pre-generated post text (if provided, AI generation is skipped)
            tone: Writing tone (used if generating)
            image_path: Optional image to attach
            preview_only: If True, only generate/prepare content but don't publish

        Returns:
            PostResult with status
        """
        if not topic and not content:
            return PostResult(
                success=False,
                post_url=None,
                content="",
                error_message="Either topic or content must be provided"
            )

        # 1. Determine final content
        final_content = content
        if not final_content and topic and self.ai_client:
            logger.info(f"Generating content for topic: {topic} with tone: {tone}")
            final_content = await self.ai_client.generate_post(topic=topic, tone=tone)
            if not final_content:
                return PostResult(
                    success=False,
                    post_url=None,
                    content="",
                    error_message="Failed to generate content"
                )
        elif not final_content:
            return PostResult(
                success=False,
                post_url=None,
                content="",
                error_message="No content provided and no AI client available"
            )

        logger.info(f"Post content: {final_content[:100]}...")
        if preview_only:
            return PostResult(
                success=True,
                post_url=None,
                content=final_content,
                posted_at=None
            )

        # 2. Ensure authenticated
        if not await self.ensure_authenticated():
            return PostResult(
                success=False,
                post_url=None,
                content=final_content,
                error_message="Authentication failed"
            )

        # 3. Open create post dialog
        if not await self._open_create_post_dialog():
            return PostResult(
                success=False,
                post_url=None,
                content=final_content,
                error_message="Failed to open post creation dialog"
            )

        # 4. Type content
        if not await self._type_post_content(final_content):
            return PostResult(
                success=False,
                post_url=None,
                content=final_content,
                error_message="Failed to type post content"
            )

        # 5. Attach image if provided
        if image_path:
            success = await self._attach_image(image_path)
            if not success:
                logger.warning("Failed to attach image, continuing without it")

        # 6. Submit post
        post_url = await self._submit_post()
        if post_url:
            self._posts_today += 1
            self._last_post_time = datetime.now()
            logger.info(f"Post published successfully: {post_url}")
            return PostResult(
                success=True,
                post_url=post_url,
                content=final_content,
                posted_at=datetime.now()
            )
        else:
            return PostResult(
                success=False,
                post_url=None,
                content=final_content,
                error_message="Failed to submit post"
            )

    async def _open_create_post_dialog(self) -> bool:
        """Navigate to home and click the create post button."""
        try:
            # Navigate to threads.net (home)
            await self.engine.navigate("https://www.threads.net")
            await human_delay(2, 4)

            # Try multiple selectors for the create post button
            create_btn = None
            for selector in [
                self.SELECTORS["create_post_button_alt"],
                self.SELECTORS["create_post_button_text"],
                'button:has-text("What")',
                'div[role="button"]:has-text("What")',
            ]:
                if selector:
                    create_btn = await self.engine.find_element(selector)
                    if create_btn:
                        logger.debug(f"Found create button with selector: {selector}")
                        break

            if not create_btn:
                # Fallback: try to find the main input directly
                logger.warning("Create button not found, trying to find text input directly")
                # Sometimes the input is already visible on home
                text_input = await self.engine.find_element(self.SELECTORS["text_input"])
                if text_input:
                    # We're already in the compose view
                    return True
                else:
                    logger.error("Could not find create post button or text input")
                    return False

            # Click the button with human-like behavior
            from .behavior.mouse import click_element_human_like
            await click_element_human_like(self.engine, create_btn)
            await human_delay(1, 3)

            # Verify that text input appeared
            text_input = await self.engine.wait_for_element(
                self.SELECTORS["text_input"], timeout=10
            )
            if not text_input:
                logger.error("Text input did not appear after clicking create")
                return False

            return True

        except Exception as e:
            logger.error(f"Failed to open create post dialog: {e}")
            return False

    async def _type_post_content(self, content: str) -> bool:
        """Type post content into the text field."""
        try:
            text_input = await self.engine.find_element(self.SELECTORS["text_input"])
            if not text_input:
                logger.error("Text input not found")
                return False

            # Focus and type
            await text_input.click()
            await human_delay(0.3, 0.7)

            # Use human-like typing
            await type_text_human_like(self.engine, text_input, content)

            # Optional: small pause after typing
            await human_delay(0.5, 1.5)

            return True

        except Exception as e:
            logger.error(f"Failed to type content: {e}")
            return False

    async def _attach_image(self, image_path: Union[str, Path]) -> bool:
        """Attach an image to the post."""
        try:
            image_path = Path(image_path)
            if not image_path.exists():
                logger.error(f"Image file not found: {image_path}")
                return False

            # Click add image button
            add_image_btn = await self.engine.find_element(self.SELECTORS["add_image_button"])
            if add_image_btn:
                await add_image_btn.click()
                await human_delay(0.5, 1.5)

            # Find file input
            file_input = await self.engine.find_element(self.SELECTORS["file_input"])
            if not file_input:
                logger.warning("File input not found, cannot upload image")
                return False

            # Send file path
            await file_input.send_keys(str(image_path.absolute()))
            await human_delay(2, 4)  # Wait for upload
            logger.info("Image attached successfully")
            return True

        except Exception as e:
            logger.error(f"Failed to attach image: {e}")
            return False

    async def _submit_post(self) -> Optional[str]:
        """Click the post button and return the post URL if successful."""
        try:
            # Find post button
            post_btn = await self.engine.find_element(self.SELECTORS["post_button"])
            if not post_btn:
                # Try alternative with text
                post_btn = await self.engine.find_element('button:has-text("Post")')
                if not post_btn:
                    logger.error("Post button not found")
                    return None

            # Check if disabled (e.g., no content)
            is_disabled = await self.engine.execute_script(
                "return arguments[0].disabled === true", post_btn
            )
            if is_disabled:
                logger.error("Post button is disabled")
                return None

            # Click with human-like delay
            await post_btn.click()
            await human_delay(3, 6)  # Wait for post to be published

            # Look for success indicators
            success = await self.engine.find_element(self.SELECTORS["success_indicator"])
            if not success:
                # Sometimes there's no alert, check if we are redirected to the post
                current_url = await self.engine.execute_script("return window.location.href")
                if "/post/" in current_url or "/t/" in current_url:
                    return current_url

                # Try to find a link to the post
                post_link = await self.engine.find_element(self.SELECTORS["post_link"])
                if post_link:
                    href = await post_link.get_attribute("href")
                    if href:
                        return href if href.startswith("http") else f"https://www.threads.net{href}"

                # Last resort: assume success and return home URL
                logger.warning("No explicit success indicator, assuming post succeeded")
                return "https://www.threads.net"
            else:
                # Success indicator found, try to get post URL
                post_link = await self.engine.find_element(self.SELECTORS["post_link"])
                if post_link:
                    href = await post_link.get_attribute("href")
                    return href if href.startswith("http") else f"https://www.threads.net{href}"
                return "https://www.threads.net"

        except Exception as e:
            logger.error(f"Failed to submit post: {e}")
            return None

    def can_post(self, max_daily: int = 10, min_interval_minutes: int = 30) -> bool:
        """Check if posting is allowed based on limits."""
        if self._posts_today >= max_daily:
            logger.warning(f"Daily post limit reached for {self.account.username}")
            return False
        if self._last_post_time:
            minutes_since_last = (datetime.now() - self._last_post_time).total_seconds() / 60
            if minutes_since_last < min_interval_minutes:
                logger.warning(f"Post interval too short for {self.account.username}")
                return False
        return True

    def get_stats(self) -> Dict[str, Any]:
        """Get posting statistics."""
        return {
            "posts_today": self._posts_today,
            "last_post_time": self._last_post_time.isoformat() if self._last_post_time else None,
        }

    def reset_daily_stats(self):
        """Reset daily post counter."""
        self._posts_today = 0