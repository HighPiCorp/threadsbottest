"""
Threads Authentication Module
Handles login and session management for Threads accounts.
"""

import asyncio
import json
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

from loguru import logger

from .account_manager import Account
from .engines.base_engine import BaseBrowserEngine
from .behavior import human_delay, think_delay


@dataclass
class AuthResult:
    """Result of authentication attempt."""
    success: bool
    is_logged_in: bool
    error_type: Optional[str] = None  # 'invalid_credentials', 'captcha', 'blocked', 'timeout', 'unknown'
    error_message: Optional[str] = None
    cookies: List[Dict[str, Any]] = None


class ThreadsSession:
    """
    Manages authentication and session for a Threads account.
    
    Features:
    - Login with username/password
    - Session persistence via cookies
    - Login state detection
    - Error handling for various auth scenarios
    """
    
    # Threads URLs
    BASE_URL = "https://www.threads.net"
    LOGIN_URL = "https://www.threads.net/login"
    
    # Selectors (will be loaded from config)
    SELECTORS = {
        "username_input": 'input[name="username"]',
        "password_input": 'input[name="password"]',
        "login_button": 'button[type="submit"]',
        "user_avatar": 'img[alt*="profile"]',
        "create_post_button": '[aria-label="Create thread"]',
        "error_message": '[role="alert"]',
        "captcha_frame": 'iframe[src*="captcha"]',
    }
    
    def __init__(
        self,
        account: Account,
        engine: BaseBrowserEngine,
        cookies_dir: str = "config/cookies"
    ):
        self.account = account
        self.engine = engine
        self.cookies_dir = Path(cookies_dir)
        self.cookies_dir.mkdir(parents=True, exist_ok=True)
        
        self._is_logged_in: Optional[bool] = None
        self._last_auth_time: Optional[datetime] = None
        self._cookies_file = self.cookies_dir / f"account_{account.id}_cookies.json"
    
    async def ensure_logged_in(self, max_attempts: int = 2) -> AuthResult:
        """
        Ensure account is logged in, attempting login if necessary.
        
        Args:
            max_attempts: Maximum login attempts
            
        Returns:
            AuthResult with status
        """
        # Check if already logged in
        if await self.is_logged_in():
            logger.info(f"Account {self.account.username} is already logged in")
            return AuthResult(success=True, is_logged_in=True)
        
        # Try to load saved cookies
        if await self._load_cookies():
            if await self.is_logged_in():
                logger.info(f"Session restored from cookies for {self.account.username}")
                return AuthResult(success=True, is_logged_in=True)
        
        # Perform login
        for attempt in range(max_attempts):
            logger.info(f"Login attempt {attempt + 1}/{max_attempts} for {self.account.username}")
            
            result = await self.login()
            
            if result.success:
                return result
            
            if result.error_type in ['invalid_credentials', 'blocked']:
                # Don't retry on these errors
                return result
            
            await human_delay(3, 5)
        
        return result
    
    async def login(self) -> AuthResult:
        """
        Perform login with username and password.
        
        Returns:
            AuthResult with login status
        """
        try:
            logger.info(f"Starting login for {self.account.username}")
            
            # Navigate to login page
            await self.engine.navigate(self.LOGIN_URL)
            await human_delay(2, 4)
            
            # Check for CAPTCHA
            if await self._detect_captcha():
                logger.warning("CAPTCHA detected during login")
                return AuthResult(
                    success=False,
                    is_logged_in=False,
                    error_type='captcha',
                    error_message='CAPTCHA challenge detected. Manual intervention required.'
                )
            
            # Find and fill username field
            username_field = await self.engine.find_element(
                self.SELECTORS["username_input"]
            )
            
            if not username_field:
                # Try alternative selectors
                username_field = await self.engine.find_element('input[placeholder*="username" i]')
            
            if not username_field:
                logger.error("Username field not found")
                return AuthResult(
                    success=False,
                    is_logged_in=False,
                    error_type='unknown',
                    error_message='Login form not found - page structure may have changed'
                )
            
            # Clear and type username
            await username_field.click()
            await human_delay(0.2, 0.5)
            await self.engine.type_text(username_field, self.account.username)
            await human_delay(0.5, 1)
            
            # Find and fill password field
            password_field = await self.engine.find_element(
                self.SELECTORS["password_input"]
            )
            
            if not password_field:
                password_field = await self.engine.find_element('input[type="password"]')
            
            if not password_field:
                logger.error("Password field not found")
                return AuthResult(
                    success=False,
                    is_logged_in=False,
                    error_type='unknown',
                    error_message='Password field not found'
                )
            
            await password_field.click()
            await human_delay(0.2, 0.5)
            await self.engine.type_text(password_field, self.account.password)
            await human_delay(0.5, 1)
            
            # Click login button
            login_button = await self.engine.find_element(
                self.SELECTORS["login_button"]
            )
            
            if not login_button:
                # Try alternative
                login_button = await self.engine.find_element('button:has-text("Log in")')
            
            if login_button:
                await login_button.click()
            else:
                # Try pressing Enter on password field
                await password_field.send_keys('\r')
            
            # Wait for login to complete
            await human_delay(3, 5)
            
            # Check for errors
            error_result = await self._check_login_errors()
            if error_result:
                return error_result
            
            # Check if logged in
            if await self.is_logged_in():
                logger.info(f"Login successful for {self.account.username}")
                
                # Save cookies
                await self._save_cookies()
                
                self._last_auth_time = datetime.now()
                
                return AuthResult(
                    success=True,
                    is_logged_in=True,
                    cookies=await self.engine.get_cookies()
                )
            else:
                logger.error("Login failed - unable to verify logged in state")
                return AuthResult(
                    success=False,
                    is_logged_in=False,
                    error_type='unknown',
                    error_message='Unable to verify login success'
                )
                
        except Exception as e:
            logger.exception(f"Login error for {self.account.username}: {e}")
            return AuthResult(
                success=False,
                is_logged_in=False,
                error_type='unknown',
                error_message=str(e)
            )
    
    async def is_logged_in(self) -> bool:
        """
        Check if currently logged in.
        
        Returns:
            True if logged in
        """
        try:
            # Navigate to base URL
            await self.engine.navigate(self.BASE_URL)
            await human_delay(2, 3)
            
            # Check for logged-in indicators
            indicators = [
                self.SELECTORS["user_avatar"],
                self.SELECTORS["create_post_button"],
                'a[href*="/logout"]',
                '[aria-label*="profile"]',
            ]
            
            for selector in indicators:
                element = await self.engine.find_element(selector)
                if element:
                    logger.debug(f"Logged in indicator found: {selector}")
                    self._is_logged_in = True
                    return True
            
            # Check for login button (indicates logged out)
            login_button = await self.engine.find_element('a[href="/login"]')
            if login_button:
                logger.debug("Login button found - not logged in")
                self._is_logged_in = False
                return False
            
            # Ambiguous state
            logger.debug("Login state ambiguous")
            return False
            
        except Exception as e:
            logger.error(f"Error checking login state: {e}")
            return False
    
    async def logout(self) -> bool:
        """
        Perform logout.
        
        Returns:
            True if successful
        """
        try:
            # Navigate to logout URL or click logout button
            # Threads logout is typically via settings menu
            await self.engine.navigate(f"{self.BASE_URL}/logout")
            await human_delay(2, 3)
            
            # Clear cookies
            await self.engine.clear_cookies()
            
            # Delete saved cookies file
            if self._cookies_file.exists():
                self._cookies_file.unlink()
            
            self._is_logged_in = False
            logger.info(f"Logged out account {self.account.username}")
            
            return True
            
        except Exception as e:
            logger.error(f"Logout error: {e}")
            return False
    
    async def _detect_captcha(self) -> bool:
        """Detect if CAPTCHA is present."""
        try:
            captcha = await self.engine.find_element(self.SELECTORS["captcha_frame"])
            if captcha:
                return True
            
            # Check for common CAPTCHA indicators
            page_source = await self.engine.get_page_source()
            captcha_indicators = [
                'captcha',
                'recaptcha',
                'hcaptcha',
                'security check',
            ]
            
            page_lower = page_source.lower()
            for indicator in captcha_indicators:
                if indicator in page_lower:
                    logger.warning(f"Possible CAPTCHA detected: {indicator}")
                    return True
            
            return False
            
        except Exception:
            return False
    
    async def _check_login_errors(self) -> Optional[AuthResult]:
        """Check for login error messages."""
        try:
            # Check for error alert
            error_element = await self.engine.find_element(self.SELECTORS["error_message"])
            if error_element:
                error_text = await self.engine.get_text(error_element)
                error_lower = error_text.lower()
                
                logger.warning(f"Login error message: {error_text}")
                
                if any(word in error_lower for word in ['password', 'username', 'incorrect', 'invalid']):
                    return AuthResult(
                        success=False,
                        is_logged_in=False,
                        error_type='invalid_credentials',
                        error_message=error_text
                    )
                
                if any(word in error_lower for word in ['blocked', 'suspended', 'disabled']):
                    return AuthResult(
                        success=False,
                        is_logged_in=False,
                        error_type='blocked',
                        error_message=error_text
                    )
                
                return AuthResult(
                    success=False,
                    is_logged_in=False,
                    error_type='unknown',
                    error_message=error_text
                )
            
            return None
            
        except Exception:
            return None
    
    async def _save_cookies(self) -> bool:
        """Save cookies to file."""
        try:
            cookies = await self.engine.get_cookies()
            
            cookie_data = {
                "account_id": self.account.id,
                "username": self.account.username,
                "saved_at": datetime.now().isoformat(),
                "cookies": cookies,
            }
            
            with open(self._cookies_file, 'w') as f:
                json.dump(cookie_data, f, indent=2)
            
            logger.debug(f"Cookies saved for account {self.account.id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save cookies: {e}")
            return False
    
    async def _load_cookies(self) -> bool:
        """Load cookies from file."""
        try:
            if not self._cookies_file.exists():
                return False
            
            with open(self._cookies_file, 'r') as f:
                cookie_data = json.load(f)
            
            # Check if cookies are not too old (7 days)
            saved_at = datetime.fromisoformat(cookie_data.get("saved_at", "2000-01-01"))
            if datetime.now() - saved_at > timedelta(days=7):
                logger.info("Cookies too old, will re-authenticate")
                return False
            
            cookies = cookie_data.get("cookies", [])
            
            if cookies:
                await self.engine.set_cookies(cookies)
                logger.debug(f"Cookies loaded for account {self.account.id}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to load cookies: {e}")
            return False
    
    def get_session_age(self) -> Optional[timedelta]:
        """Get age of current session."""
        if self._last_auth_time:
            return datetime.now() - self._last_auth_time
        return None
    
    def should_refresh_session(self, max_age_hours: int = 24) -> bool:
        """Check if session should be refreshed."""
        age = self.get_session_age()
        if age:
            return age > timedelta(hours=max_age_hours)
        return True
