"""
Nodriver Browser Engine
Primary browser automation engine using nodriver library.
"""

import asyncio
import random
import shutil
import tempfile
from typing import Optional, Dict, Any, List
from pathlib import Path

import nodriver as uc
from loguru import logger

from .base_engine import BaseBrowserEngine, BrowserProfile, FingerprintConfig


class NodriverEngine(BaseBrowserEngine):
    """
    Browser automation using nodriver (pure Python Chrome automation).
    
    Features:
    - No WebDriver needed
    - Native CDP support
    - Better stealth than Selenium
    - Proxy support via Chrome args
    """
    
    def __init__(self, profile: BrowserProfile):
        super().__init__(profile)
        self.browser: Optional[uc.Browser] = None
        self.tab: Optional[uc.Tab] = None
        self._cdp_session = None
        self._temp_profile_dir: Optional[str] = None
    
    def _find_chrome_path(self) -> Optional[str]:
        """Find Chrome executable path."""
        # Common paths on Windows
        paths = [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            shutil.which("chrome"),
            shutil.which("google-chrome"),
            shutil.which("google-chrome-stable"),
        ]
        for path in paths:
            if path and Path(path).exists():
                logger.debug(f"Found Chrome at: {path}")
                return str(path)
        logger.warning("Chrome executable not found in standard locations")
        return None
    
    def _build_chrome_args(self) -> List[str]:
        """Build Chrome command-line arguments."""
        args = []
        
        # Explicitly set Chrome path if found (helps avoid confusion with running instances)
        chrome_path = self._find_chrome_path()
        if chrome_path:
            args.append(f"--chrome-path={chrome_path}")
        
        # User data directory (ensure isolation)
        if self.profile.user_data_dir:
            args.append(f"--user-data-dir={self.profile.user_data_dir}")
        else:
            # Use a temporary directory for each launch
            self._temp_profile_dir = tempfile.mkdtemp(prefix="threads_bot_profile_")
            args.append(f"--user-data-dir={self._temp_profile_dir}")
            logger.debug(f"Using temporary profile: {self._temp_profile_dir}")
        
        # Proxy configuration
        if self.profile.proxy:
            args.append(f"--proxy-server={self.profile.proxy}")
            args.append("--proxy-bypass-list=\"")  # Force all traffic through proxy
        
        # User agent
        if self.profile.user_agent:
            args.append(f"--user-agent={self.profile.user_agent}")
        
        # Viewport
        if self.profile.viewport:
            width = self.profile.viewport.get("width", 1920)
            height = self.profile.viewport.get("height", 1080)
            args.append(f"--window-size={width},{height}")
        
        # Language
        if self.profile.language:
            args.append(f"--lang={self.profile.language}")
        
        # Remote debugging port (let nodriver choose a free port)
        args.append("--remote-debugging-port=0")
        
        # Additional anti-detect and isolation args
        args.extend([
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-blink-features=AutomationControlled",
            "--disable-web-security",
            "--disable-features=IsolateOrigins,site-per-process",
            "--disable-site-isolation-trials",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--disable-sync",  # Disable Chrome sync
            "--disable-gpu",
            "--disable-software-rasterizer",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            "--disable-breakpad",
            "--disable-component-update",
            "--disable-default-apps",
            "--disable-domain-reliability",
            "--disable-features=Translate,BackForwardCache,OptimizationHints,MediaRouter,CalculateNativeWinOcclusion",
            "--disable-hang-monitor",
            "--disable-ipc-flooding-protection",
            "--disable-prompt-on-repost",
            "--disable-speech-api",
            "--disk-cache-dir=null",
            "--enable-features=NetworkService,NetworkServiceInProcess",
            "--force-color-profile=srgb",
            "--metrics-recording-only",
            "--mute-audio",
            "--no-pings",
            "--no-zygote",
            "--use-gl=angle",
            "--use-angle=default",
        ])
        
        return args
    
    async def start(self) -> bool:
        """Start browser with nodriver."""
        try:
            logger.info("Starting nodriver browser...")
            
            # Build Chrome arguments
            chrome_args = self._build_chrome_args()
            logger.debug(f"Chrome args: {chrome_args}")
            
            # Start browser
            self.browser = await uc.start(
                headless=False,  # Never use headless
                browser_args=chrome_args
            )
            
            # Check that browser actually started
            if self.browser is None:
                logger.error("uc.start() returned None - browser failed to start")
                return False
            
            # Give it a moment to initialize
            await asyncio.sleep(1.5)
            
            # Get main tab
            try:
                self.tab = self.browser.main_tab
            except Exception as e:
                logger.error(f"Failed to get main tab: {e}")
                return False
            
            if self.tab is None:
                logger.error("main_tab is None - browser might not be fully initialized")
                return False
            
            # Apply anti-detect measures
            fingerprint = FingerprintConfig()
            await self.apply_anti_detect(fingerprint)
            
            self.is_running = True
            logger.info("Browser started successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start browser: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    async def stop(self) -> bool:
        """Stop browser and clean up temporary profile."""
        try:
            if self.browser:
                self.browser.stop()
                self.browser = None
                self.tab = None
            
            # Clean up temporary profile directory
            if self._temp_profile_dir and Path(self._temp_profile_dir).exists():
                import shutil
                try:
                    shutil.rmtree(self._temp_profile_dir, ignore_errors=True)
                    logger.debug(f"Removed temporary profile: {self._temp_profile_dir}")
                except Exception as e:
                    logger.warning(f"Failed to remove temp profile: {e}")
            
            self.is_running = False
            logger.info("Browser stopped")
            return True
            
        except Exception as e:
            logger.error(f"Error stopping browser: {e}")
            return False
    
    # ---------- Остальные методы без изменений ----------
    async def navigate(self, url: str) -> bool:
        """Navigate to URL."""
        try:
            if not self.tab:
                logger.error("Browser not started")
                return False
            
            await self.tab.get(url)
            logger.debug(f"Navigated to {url}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to navigate to {url}: {e}")
            return False
    
    async def find_element(self, selector: str, by: str = "css") -> Optional[uc.Element]:
        try:
            if not self.tab:
                return None
            if by == "css":
                return await self.tab.select(selector)
            elif by == "xpath":
                elements = await self.tab.find_elements_by_xpath(selector)
                return elements[0] if elements else None
            elif by == "id":
                return await self.tab.select(f"#{selector}")
            return None
        except Exception:
            return None
    
    async def find_elements(self, selector: str, by: str = "css") -> List[uc.Element]:
        try:
            if not self.tab:
                return []
            if by == "css":
                return await self.tab.find_elements_by_css(selector)
            elif by == "xpath":
                return await self.tab.find_elements_by_xpath(selector)
            return []
        except Exception:
            return []
    
    async def click(self, element: uc.Element) -> bool:
        try:
            await element.click()
            return True
        except Exception as e:
            logger.error(f"Failed to click element: {e}")
            return False
    
    async def type_text(self, element: uc.Element, text: str, human_like: bool = True) -> bool:
        try:
            if human_like:
                from ..behavior.keyboard import type_text_human_like
                await type_text_human_like(self, element, text)
            else:
                await element.send_keys(text)
            return True
        except Exception as e:
            logger.error(f"Failed to type text: {e}")
            return False
    
    async def get_text(self, element: uc.Element) -> str:
        try:
            return element.text or ""
        except Exception:
            return ""
    
    async def scroll_to(self, element: uc.Element) -> bool:
        try:
            await element.scroll_into_view()
            return True
        except Exception:
            return False
    
    async def scroll_by(self, x: int, y: int) -> bool:
        try:
            await self.tab.evaluate(f"window.scrollBy({x}, {y})")
            return True
        except Exception:
            return False
    
    async def execute_script(self, script: str, *args) -> Any:
        try:
            args_str = ", ".join(str(arg) for arg in args)
            full_script = f"({script})({args_str})"
            return await self.tab.evaluate(full_script)
        except Exception as e:
            logger.error(f"Script execution failed: {e}")
            return None
    
    async def take_screenshot(self, path: str) -> bool:
        try:
            await self.tab.save_screenshot(path)
            return True
        except Exception:
            return False
    
    async def get_cookies(self) -> List[Dict[str, Any]]:
        try:
            cookies = await self.tab.evaluate("document.cookie")
            result = []
            if cookies:
                for cookie in cookies.split("; "):
                    if "=" in cookie:
                        name, value = cookie.split("=", 1)
                        result.append({"name": name, "value": value})
            return result
        except Exception:
            return []
    
    async def set_cookies(self, cookies: List[Dict[str, Any]]) -> bool:
        try:
            for cookie in cookies:
                name = cookie.get("name", "")
                value = cookie.get("value", "")
                domain = cookie.get("domain", "")
                path = cookie.get("path", "/")
                cookie_str = f"{name}={value}; domain={domain}; path={path}"
                await self.tab.evaluate(f'document.cookie = "{cookie_str}"')
            return True
        except Exception:
            return False
    
    async def clear_cookies(self) -> bool:
        try:
            await self.tab.evaluate("""
                document.cookie.split(";").forEach(function(c) {
                    document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
                });
            """)
            return True
        except Exception:
            return False
    
    async def get_page_source(self) -> str:
        try:
            return await self.tab.evaluate("document.documentElement.outerHTML")
        except Exception:
            return ""
    
    async def wait_for_element(self, selector: str, by: str = "css", timeout: int = 10) -> Optional[uc.Element]:
        try:
            start_time = asyncio.get_event_loop().time()
            while asyncio.get_event_loop().time() - start_time < timeout:
                element = await self.find_element(selector, by)
                if element:
                    return element
                await asyncio.sleep(0.5)
            return None
        except Exception:
            return None
    
    async def minimize_window(self) -> bool:
        try:
            await self.cdp_execute("Browser.setWindowBounds", {
                "windowId": 1,
                "bounds": {"windowState": "minimized"}
            })
            return True
        except Exception:
            return False
    
    async def maximize_window(self) -> bool:
        try:
            await self.cdp_execute("Browser.setWindowBounds", {
                "windowId": 1,
                "bounds": {"windowState": "maximized"}
            })
            return True
        except Exception:
            return False
    
    async def set_window_position(self, x: int, y: int) -> bool:
        try:
            await self.cdp_execute("Browser.setWindowBounds", {
                "windowId": 1,
                "bounds": {"left": x, "top": y}
            })
            return True
        except Exception:
            return False
    
    async def set_window_size(self, width: int, height: int) -> bool:
        try:
            await self.cdp_execute("Browser.setWindowBounds", {
                "windowId": 1,
                "bounds": {"width": width, "height": height}
            })
            return True
        except Exception:
            return False
    
    async def cdp_execute(self, command: str, params: Dict[str, Any] = None) -> Any:
        try:
            if not self.tab:
                return None
            result = await self.tab.send(command, params or {})
            return result
        except Exception as e:
            logger.debug(f"CDP command failed: {command} - {e}")
            return None
    
    async def get_mouse_position(self) -> tuple:
        try:
            pos = await self.tab.evaluate("""
                (() => {
                    return {x: window.mouseX || 0, y: window.mouseY || 0};
                })()
            """)
            return (pos.get("x", 0), pos.get("y", 0))
        except Exception:
            return (0, 0)
    
    async def move_mouse_to(self, x: int, y: int, duration: float = 0.5) -> bool:
        try:
            from ..behavior.mouse import move_mouse_human_like
            await move_mouse_human_like(self, x, y, duration)
            return True
        except Exception as e:
            logger.error(f"Failed to move mouse: {e}")
            return False