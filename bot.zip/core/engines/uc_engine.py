"""
Undetected ChromeDriver Engine
Fallback browser automation using undetected-chromedriver.
"""

import random
from typing import Optional, Dict, Any, List
from pathlib import Path

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from loguru import logger

from .base_engine import BaseBrowserEngine, BrowserProfile, FingerprintConfig


class UCEngine(BaseBrowserEngine):
    """
    Browser automation using undetected-chromedriver.
    
    Used as fallback when nodriver has issues.
    """
    
    def __init__(self, profile: BrowserProfile):
        super().__init__(profile)
        self.driver: Optional[uc.Chrome] = None
        self._action_chains: Optional[ActionChains] = None
    
    def _build_options(self) -> uc.ChromeOptions:
        """Build Chrome options."""
        options = uc.ChromeOptions()
        
        # User data directory
        if self.profile.user_data_dir:
            options.add_argument(f"--user-data-dir={self.profile.user_data_dir}")
        
        # Proxy configuration
        if self.profile.proxy:
            options.add_argument(f"--proxy-server={self.profile.proxy}")
            options.add_argument('--proxy-bypass-list=""')
        
        # User agent
        if self.profile.user_agent:
            options.add_argument(f"--user-agent={self.profile.user_agent}")
        
        # Viewport
        if self.profile.viewport:
            width = self.profile.viewport.get("width", 1920)
            height = self.profile.viewport.get("height", 1080)
            options.add_argument(f"--window-size={width},{height}")
        
        # Language
        if self.profile.language:
            options.add_argument(f"--lang={self.profile.language}")
        
        # Anti-detect options
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-web-security")
        options.add_argument("--disable-features=IsolateOrigins,site-per-process")
        options.add_argument("--disable-site-isolation-trials")
        
        return options
    
    async def start(self) -> bool:
        """Start browser with undetected-chromedriver."""
        try:
            logger.info("Starting undetected-chromedriver...")
            
            options = self._build_options()
            
            # Create driver
            self.driver = uc.Chrome(
                options=options,
                headless=False,  # Never use headless
                use_subprocess=True,  # Required for Windows
            )
            
            self._action_chains = ActionChains(self.driver)
            
            # Apply anti-detect measures
            fingerprint = FingerprintConfig()
            await self.apply_anti_detect(fingerprint)
            
            self.is_running = True
            logger.info("Browser started successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start browser: {e}")
            return False
    
    async def stop(self) -> bool:
        """Stop browser."""
        try:
            if self.driver:
                self.driver.quit()
                self.driver = None
                self._action_chains = None
            
            self.is_running = False
            logger.info("Browser stopped")
            return True
            
        except Exception as e:
            logger.error(f"Error stopping browser: {e}")
            return False
    
    def _get_by_strategy(self, by: str) -> By:
        """Convert string to By strategy."""
        strategies = {
            "css": By.CSS_SELECTOR,
            "xpath": By.XPATH,
            "id": By.ID,
            "name": By.NAME,
            "class": By.CLASS_NAME,
            "tag": By.TAG_NAME,
        }
        return strategies.get(by, By.CSS_SELECTOR)
    
    async def navigate(self, url: str) -> bool:
        """Navigate to URL."""
        try:
            if not self.driver:
                logger.error("Browser not started")
                return False
            
            self.driver.get(url)
            logger.debug(f"Navigated to {url}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to navigate to {url}: {e}")
            return False
    
    async def find_element(self, selector: str, by: str = "css") -> Optional[WebElement]:
        """Find element by selector."""
        try:
            if not self.driver:
                return None
            
            by_strategy = self._get_by_strategy(by)
            return self.driver.find_element(by_strategy, selector)
            
        except Exception:
            return None
    
    async def find_elements(self, selector: str, by: str = "css") -> List[WebElement]:
        """Find all elements matching selector."""
        try:
            if not self.driver:
                return []
            
            by_strategy = self._get_by_strategy(by)
            return self.driver.find_elements(by_strategy, selector)
            
        except Exception:
            return []
    
    async def click(self, element: WebElement) -> bool:
        """Click on element."""
        try:
            element.click()
            return True
        except Exception as e:
            logger.error(f"Failed to click element: {e}")
            return False
    
    async def type_text(
        self,
        element: WebElement,
        text: str,
        human_like: bool = True
    ) -> bool:
        """Type text into element."""
        try:
            if human_like:
                # Use behavior module for human-like typing
                from ..behavior.keyboard import type_text_human_like_uc
                await type_text_human_like_uc(self, element, text)
            else:
                element.send_keys(text)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to type text: {e}")
            return False
    
    async def get_text(self, element: WebElement) -> str:
        """Get element text content."""
        try:
            return element.text or ""
        except Exception:
            return ""
    
    async def scroll_to(self, element: WebElement) -> bool:
        """Scroll element into view."""
        try:
            self.driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element)
            return True
        except Exception:
            return False
    
    async def scroll_by(self, x: int, y: int) -> bool:
        """Scroll by offset."""
        try:
            self.driver.execute_script(f"window.scrollBy({x}, {y})")
            return True
        except Exception:
            return False
    
    async def execute_script(self, script: str, *args) -> Any:
        """Execute JavaScript."""
        try:
            return self.driver.execute_script(script, *args)
        except Exception as e:
            logger.error(f"Script execution failed: {e}")
            return None
    
    async def take_screenshot(self, path: str) -> bool:
        """Take screenshot."""
        try:
            self.driver.save_screenshot(path)
            return True
        except Exception:
            return False
    
    async def get_cookies(self) -> List[Dict[str, Any]]:
        """Get all cookies."""
        try:
            return self.driver.get_cookies()
        except Exception:
            return []
    
    async def set_cookies(self, cookies: List[Dict[str, Any]]) -> bool:
        """Set cookies."""
        try:
            for cookie in cookies:
                self.driver.add_cookie(cookie)
            return True
        except Exception:
            return False
    
    async def clear_cookies(self) -> bool:
        """Clear all cookies."""
        try:
            self.driver.delete_all_cookies()
            return True
        except Exception:
            return False
    
    async def get_page_source(self) -> str:
        """Get current page HTML."""
        try:
            return self.driver.page_source
        except Exception:
            return ""
    
    async def wait_for_element(
        self,
        selector: str,
        by: str = "css",
        timeout: int = 10
    ) -> Optional[WebElement]:
        """Wait for element to appear."""
        try:
            by_strategy = self._get_by_strategy(by)
            wait = WebDriverWait(self.driver, timeout)
            return wait.until(EC.presence_of_element_located((by_strategy, selector)))
        except Exception:
            return None
    
    async def minimize_window(self) -> bool:
        """Minimize browser window."""
        try:
            self.driver.minimize_window()
            return True
        except Exception:
            return False
    
    async def maximize_window(self) -> bool:
        """Maximize browser window."""
        try:
            self.driver.maximize_window()
            return True
        except Exception:
            return False
    
    async def set_window_position(self, x: int, y: int) -> bool:
        """Set window position."""
        try:
            self.driver.set_window_position(x, y)
            return True
        except Exception:
            return False
    
    async def set_window_size(self, width: int, height: int) -> bool:
        """Set window size."""
        try:
            self.driver.set_window_size(width, height)
            return True
        except Exception:
            return False
    
    async def cdp_execute(self, command: str, params: Dict[str, Any] = None) -> Any:
        """Execute Chrome DevTools Protocol command."""
        try:
            if not self.driver:
                return None
            
            # undetected-chromedriver supports CDP via execute_cdp_cmd
            return self.driver.execute_cdp_cmd(command, params or {})
            
        except Exception as e:
            logger.debug(f"CDP command failed: {command} - {e}")
            return None
    
    async def get_mouse_position(self) -> tuple:
        """Get current mouse position."""
        try:
            pos = self.driver.execute_script("""
                return {x: window.mouseX || 0, y: window.mouseY || 0};
            """)
            return (pos.get("x", 0), pos.get("y", 0))
        except Exception:
            return (0, 0)
    
    async def move_mouse_to(self, x: int, y: int, duration: float = 0.5) -> bool:
        """Move mouse to coordinates using ActionChains."""
        try:
            if self._action_chains:
                self._action_chains.move_by_offset(x, y).perform()
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to move mouse: {e}")
            return False
