"""
Base Browser Engine
Abstract base class for browser automation engines.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Dict, Any, List
from pathlib import Path


@dataclass
class BrowserProfile:
    """Browser profile configuration."""
    user_data_dir: Optional[str] = None
    proxy: Optional[str] = None
    user_agent: Optional[str] = None
    viewport: Optional[Dict[str, int]] = None  # {"width": 1920, "height": 1080}
    timezone: Optional[str] = None
    language: Optional[str] = None
    geolocation: Optional[Dict[str, float]] = None  # {"latitude": 51.5, "longitude": -0.12}
    
    # Anti-detect settings
    webrtc_policy: str = "disable_non_proxied_udp"
    canvas_noise: bool = True
    webgl_noise: bool = True


@dataclass
class FingerprintConfig:
    """Browser fingerprint configuration for rotation."""
    chrome_version: str = "120.0.0.0"
    platform: str = "Win32"
    vendor: str = "Google Inc."
    renderer: str = "ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)"
    fonts: List[str] = None
    
    def __post_init__(self):
        if self.fonts is None:
            self.fonts = [
                "Arial", "Courier New", "Georgia", "Times New Roman",
                "Verdana", "Helvetica", "Tahoma", "Trebuchet MS"
            ]


class BaseBrowserEngine(ABC):
    """
    Abstract base class for browser automation engines.
    
    All browser engines must implement these methods for consistent behavior.
    """
    
    def __init__(self, profile: BrowserProfile):
        self.profile = profile
        self.driver: Any = None
        self.is_running = False
    
    @abstractmethod
    async def start(self) -> bool:
        """Start the browser instance."""
        pass
    
    @abstractmethod
    async def stop(self) -> bool:
        """Stop the browser instance."""
        pass
    
    @abstractmethod
    async def navigate(self, url: str) -> bool:
        """Navigate to URL."""
        pass
    
    @abstractmethod
    async def find_element(self, selector: str, by: str = "css") -> Optional[Any]:
        """Find element by selector."""
        pass
    
    @abstractmethod
    async def find_elements(self, selector: str, by: str = "css") -> List[Any]:
        """Find all elements matching selector."""
        pass
    
    @abstractmethod
    async def click(self, element: Any) -> bool:
        """Click on element."""
        pass
    
    @abstractmethod
    async def type_text(self, element: Any, text: str, human_like: bool = True) -> bool:
        """Type text into element."""
        pass
    
    @abstractmethod
    async def get_text(self, element: Any) -> str:
        """Get element text content."""
        pass
    
    @abstractmethod
    async def scroll_to(self, element: Any) -> bool:
        """Scroll element into view."""
        pass
    
    @abstractmethod
    async def scroll_by(self, x: int, y: int) -> bool:
        """Scroll by offset."""
        pass
    
    @abstractmethod
    async def execute_script(self, script: str, *args) -> Any:
        """Execute JavaScript."""
        pass
    
    @abstractmethod
    async def take_screenshot(self, path: str) -> bool:
        """Take screenshot."""
        pass
    
    @abstractmethod
    async def get_cookies(self) -> List[Dict[str, Any]]:
        """Get all cookies."""
        pass
    
    @abstractmethod
    async def set_cookies(self, cookies: List[Dict[str, Any]]) -> bool:
        """Set cookies."""
        pass
    
    @abstractmethod
    async def clear_cookies(self) -> bool:
        """Clear all cookies."""
        pass
    
    @abstractmethod
    async def get_page_source(self) -> str:
        """Get current page HTML."""
        pass
    
    @abstractmethod
    async def wait_for_element(
        self,
        selector: str,
        by: str = "css",
        timeout: int = 10
    ) -> Optional[Any]:
        """Wait for element to appear."""
        pass
    
    @abstractmethod
    async def minimize_window(self) -> bool:
        """Minimize browser window."""
        pass
    
    @abstractmethod
    async def maximize_window(self) -> bool:
        """Maximize browser window."""
        pass
    
    @abstractmethod
    async def set_window_position(self, x: int, y: int) -> bool:
        """Set window position."""
        pass
    
    @abstractmethod
    async def set_window_size(self, width: int, height: int) -> bool:
        """Set window size."""
        pass
    
    # CDP Methods for anti-detect
    @abstractmethod
    async def cdp_execute(self, command: str, params: Dict[str, Any] = None) -> Any:
        """Execute Chrome DevTools Protocol command."""
        pass
    
    async def apply_anti_detect(self, fingerprint: FingerprintConfig) -> bool:
        """Apply anti-detection measures."""
        try:
            # Disable WebRTC
            await self._disable_webrtc()
            
            # Set timezone
            if self.profile.timezone:
                await self._set_timezone(self.profile.timezone)
            
            # Set geolocation
            if self.profile.geolocation:
                await self._set_geolocation(self.profile.geolocation)
            
            # Inject fingerprint scripts
            await self._inject_fingerprint_scripts(fingerprint)
            
            return True
        except Exception as e:
            from loguru import logger
            logger.error(f"Failed to apply anti-detect: {e}")
            return False
    
    async def _disable_webrtc(self) -> bool:
        """Disable WebRTC to prevent IP leaks."""
        try:
            await self.cdp_execute(
                "Network.setWebRTCIPHandlingPolicy",
                {"policy": "disable_non_proxied_udp"}
            )
            return True
        except Exception:
            return False
    
    async def _set_timezone(self, timezone: str) -> bool:
        """Set browser timezone."""
        try:
            await self.cdp_execute(
                "Emulation.setTimezoneOverride",
                {"timezoneId": timezone}
            )
            return True
        except Exception:
            return False
    
    async def _set_geolocation(self, geolocation: Dict[str, float]) -> bool:
        """Set browser geolocation."""
        try:
            await self.cdp_execute(
                "Emulation.setGeolocationOverride",
                {
                    "latitude": geolocation["latitude"],
                    "longitude": geolocation["longitude"],
                    "accuracy": 100
                }
            )
            return True
        except Exception:
            return False
    
    async def _inject_fingerprint_scripts(self, fingerprint: FingerprintConfig) -> bool:
        """Inject scripts to modify fingerprint."""
        script = f"""
        (() => {{
            // Override navigator properties
            Object.defineProperty(navigator, 'platform', {{
                get: () => '{fingerprint.platform}'
            }});
            
            Object.defineProperty(navigator, 'vendor', {{
                get: () => '{fingerprint.vendor}'
            }});
            
            // Override WebGL
            const getParameter = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {{
                if (parameter === 37445) {{
                    return '{fingerprint.vendor}';
                }}
                if (parameter === 37446) {{
                    return '{fingerprint.renderer}';
                }}
                return getParameter(parameter);
            }};
            
            // Block WebRTC
            const RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
            if (RTCPeerConnection) {{
                window.RTCPeerConnection = function(...args) {{
                    const pc = new RTCPeerConnection(...args);
                    const createOffer = pc.createOffer.bind(pc);
                    pc.createOffer = function() {{
                        return createOffer().then(offer => {{
                            offer.sdp = offer.sdp.replace(/a=candidate:.*\\r\\n/g, '');
                            return offer;
                        }});
                    }};
                    return pc;
                }};
            }}
        }})();
        """
        
        try:
            await self.cdp_execute(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": script}
            )
            return True
        except Exception:
            return False
