"""
Post Filter Module
Filters posts based on various criteria before commenting.
"""

import re
import os
import sqlite3
from typing import List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from loguru import logger

from .post_fetcher import Post


@dataclass
class FilterConfig:
    """Configuration for post filtering."""
    # Engagement filters
    min_likes: int = 0
    max_likes: Optional[int] = None
    min_replies: int = 0
    max_replies: Optional[int] = None
    
    # Time filters
    max_age_hours: Optional[int] = 24  # Only posts newer than this
    
    # Content filters
    stop_words: List[str] = field(default_factory=list)
    required_words: List[str] = field(default_factory=list)
    skip_hashtags: List[str] = field(default_factory=list)
    required_hashtags: List[str] = field(default_factory=list)
    
    # Author filters
    skip_authors: List[str] = field(default_factory=list)  # Don't comment on these accounts
    skip_verified: bool = False  # Skip verified accounts
    
    # Content quality
    min_text_length: int = 10
    max_text_length: Optional[int] = 1000
    skip_media_only: bool = True  # Skip posts with only images/videos
    
    # Language (basic check)
    preferred_languages: List[str] = field(default_factory=lambda: ["ru", "en"])


class PostFilter:
    """
    Filters posts based on configurable criteria.
    
    Helps avoid commenting on:
    - Old posts
    - Low engagement posts
    - Inappropriate content
    - Already processed posts
    """
    
    def __init__(self, config: Optional[FilterConfig] = None):
        self.config = config or FilterConfig()
        self._processed_urls: Set[str] = set()
    
    def filter_posts(
        self,
        posts: List[Post],
        exclude_urls: Optional[Set[str]] = None
    ) -> List[Post]:
        """
        Filter posts based on configured criteria.
        
        Args:
            posts: List of posts to filter
            exclude_urls: Additional URLs to exclude
            
        Returns:
            Filtered list of posts
        """
        filtered = []
        exclude_urls = exclude_urls or set()
        
        for post in posts:
            result = self._check_post(post, exclude_urls)
            
            if result["passed"]:
                filtered.append(post)
            else:
                logger.debug(f"Filtered out post {post.url}: {result['reason']}")
        
        logger.info(f"Filtered {len(posts)} posts -> {len(filtered)} passed")
        return filtered
    
    def _check_post(self, post: Post, exclude_urls: Set[str]) -> dict:
        """Check a single post against all filters."""
        
        # Check if already processed
        if post.url in self._processed_urls:
            return {"passed": False, "reason": "already_processed"}
        
        if post.url in exclude_urls:
            return {"passed": False, "reason": "in_exclude_list"}
        
        # Engagement filters
        if post.likes < self.config.min_likes:
            return {"passed": False, "reason": f"too_few_likes ({post.likes})"}
        
        if self.config.max_likes and post.likes > self.config.max_likes:
            return {"passed": False, "reason": f"too_many_likes ({post.likes})"}
        
        if post.replies < self.config.min_replies:
            return {"passed": False, "reason": f"too_few_replies ({post.replies})"}
        
        if self.config.max_replies and post.replies > self.config.max_replies:
            return {"passed": False, "reason": f"too_many_replies ({post.replies})"}
        
        # Time filter
        if self.config.max_age_hours and post.posted_at:
            age = datetime.now() - post.posted_at
            if age > timedelta(hours=self.config.max_age_hours):
                return {"passed": False, "reason": f"too_old ({age.total_seconds() / 3600:.1f}h)"}
        
        # Author filters
        if post.author_username in self.config.skip_authors:
            return {"passed": False, "reason": f"skipped_author ({post.author_username})"}
        
        # Content length filters
        text_length = len(post.text)
        if text_length < self.config.min_text_length:
            return {"passed": False, "reason": f"text_too_short ({text_length})"}
        
        if self.config.max_text_length and text_length > self.config.max_text_length:
            return {"passed": False, "reason": f"text_too_long ({text_length})"}
        
        # Stop words check
        post_text_lower = post.text.lower()
        for stop_word in self.config.stop_words:
            if stop_word.lower() in post_text_lower:
                return {"passed": False, "reason": f"contains_stop_word ({stop_word})"}
        
        # Required words check
        if self.config.required_words:
            has_required = any(
                word.lower() in post_text_lower
                for word in self.config.required_words
            )
            if not has_required:
                return {"passed": False, "reason": "missing_required_words"}
        
        # Hashtag filters
        post_hashtags_lower = [h.lower() for h in post.hashtags]
        
        for skip_tag in self.config.skip_hashtags:
            if skip_tag.lower().lstrip('#') in post_hashtags_lower:
                return {"passed": False, "reason": f"skipped_hashtag ({skip_tag})"}
        
        if self.config.required_hashtags:
            has_required_tag = any(
                tag.lower().lstrip('#') in post_hashtags_lower
                for tag in self.config.required_hashtags
            )
            if not has_required_tag:
                return {"passed": False, "reason": "missing_required_hashtag"}
        
        # Media-only check
        if self.config.skip_media_only:
            # If post has very little text but likely has media
            if len(post.text.strip()) < 30 and not post.hashtags:
                return {"passed": False, "reason": "media_only_post"}
        
        # Language check (basic)
        if self.config.preferred_languages:
            lang = self._detect_language(post.text)
            if lang not in self.config.preferred_languages:
                return {"passed": False, "reason": f"wrong_language ({lang})"}
        
        return {"passed": True, "reason": None}
    
    def _detect_language(self, text: str) -> str:
        """
        Basic language detection.
        
        Returns:
            Language code ('ru', 'en', or 'other')
        """
        # Russian characters
        if re.search(r'[а-яА-ЯёЁ]', text):
            return 'ru'
        
        # English characters (basic check)
        if re.search(r'[a-zA-Z]', text):
            return 'en'
        
        return 'other'
    
    def mark_processed(self, url: str):
        """Mark a post URL as processed."""
        self._processed_urls.add(url)
    
    def is_processed(self, url: str) -> bool:
        """Check if a post URL has been processed."""
        return url in self._processed_urls
    
    def get_processed_count(self) -> int:
        """Get number of processed posts."""
        return len(self._processed_urls)
    
    def clear_processed(self):
        """Clear processed URLs cache."""
        self._processed_urls.clear()
        logger.info("Cleared processed posts cache")
    
    def get_stats(self) -> dict:
        """Get filter statistics."""
        return {
            "processed_posts": len(self._processed_urls),
            "config": {
                "min_likes": self.config.min_likes,
                "max_age_hours": self.config.max_age_hours,
                "stop_words_count": len(self.config.stop_words),
            }
        }


class GlobalCommentRegistry:
    """
    Global registry to prevent multiple accounts commenting on same post.
    
    Uses SQLite for persistence across processes.
    """
    
    def __init__(self, db_path: str = "config/task_queue.db"):
        # Use Documents/ThreadsBot
        base_dir = Path(os.path.expanduser("~")) / "Documents" / "ThreadsBot"
        self.db_path = base_dir / "task_queue.db"
        self._init_db()
    
    def _init_db(self):
        """Initialize database table."""
        import sqlite3
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS commented_posts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    post_url TEXT NOT NULL,
                    post_id TEXT,
                    account_id INTEGER NOT NULL,
                    comment_text TEXT,
                    commented_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(post_url, account_id)
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_post_url ON commented_posts(post_url)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_account ON commented_posts(account_id)
            """)
            
            # Clean old entries (older than 7 days)
            conn.execute("""
                DELETE FROM commented_posts 
                WHERE commented_at < datetime('now', '-7 days')
            """)
            
            conn.commit()
    
    def is_commented(self, post_url: str, account_id: Optional[int] = None) -> bool:
        """
        Check if a post has been commented on.
        
        Args:
            post_url: Post URL to check
            account_id: If provided, check only for this account.
                       If None, check for any account.
        """
        import sqlite3
        
        with sqlite3.connect(self.db_path) as conn:
            if account_id:
                cursor = conn.execute(
                    "SELECT 1 FROM commented_posts WHERE post_url = ? AND account_id = ?",
                    (post_url, account_id)
                )
            else:
                cursor = conn.execute(
                    "SELECT 1 FROM commented_posts WHERE post_url = ?",
                    (post_url,)
                )
            
            return cursor.fetchone() is not None
    
    def register_comment(
        self,
        post_url: str,
        account_id: int,
        post_id: Optional[str] = None,
        comment_text: Optional[str] = None
    ) -> bool:
        """Register a new comment."""
        import sqlite3
        
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """INSERT OR REPLACE INTO commented_posts 
                       (post_url, post_id, account_id, comment_text)
                       VALUES (?, ?, ?, ?)""",
                    (post_url, post_id, account_id, comment_text)
                )
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Failed to register comment: {e}")
            return False
    
    def get_account_stats(self, account_id: int) -> dict:
        """Get commenting statistics for an account."""
        import sqlite3
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """SELECT COUNT(*) FROM commented_posts 
                   WHERE account_id = ? 
                   AND commented_at > datetime('now', '-1 day')""",
                (account_id,)
            )
            today_count = cursor.fetchone()[0]
            
            cursor = conn.execute(
                "SELECT COUNT(*) FROM commented_posts WHERE account_id = ?",
                (account_id,)
            )
            total_count = cursor.fetchone()[0]
            
            return {
                "today": today_count,
                "total": total_count,
            }
    
    def get_all_commented_urls(self, since_hours: int = 168) -> Set[str]:
        """Get all commented URLs from recent period."""
        import sqlite3
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """SELECT DISTINCT post_url FROM commented_posts 
                   WHERE commented_at > datetime('now', '-{} hours')""".format(since_hours)
            )
            return {row[0] for row in cursor.fetchall()}


# Singleton
_registry: Optional[GlobalCommentRegistry] = None


def get_global_registry(db_path: str = "config/task_queue.db") -> GlobalCommentRegistry:
    """Get global comment registry singleton."""
    global _registry
    if _registry is None:
        _registry = GlobalCommentRegistry(db_path)
    return _registry