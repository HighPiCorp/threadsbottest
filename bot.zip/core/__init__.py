"""
Core Module
Main functionality for Threads Automation Bot.
"""

from .account_manager import (
    AccountManager,
    Account,
    ProxyConfig,
    get_account_manager,
)

from .openrouter_client import (
    OpenRouterClient,
    ModelConfig,
    get_openrouter_client,
    DEFAULT_MODELS,
)

from .engines import (
    BaseBrowserEngine,
    BrowserProfile,
    FingerprintConfig,
    NodriverEngine,
    UCEngine,
)

from .behavior import (
    move_mouse_human_like,
    move_to_element_human_like,
    click_element_human_like,
    type_text_human_like,
    type_text_human_like_uc,
    simulate_reading,
    human_delay,
    think_delay,
    reaction_delay,
)

from .security import (
    get_webrtc_blocker,
    get_fingerprint_factory,
    get_ip_monitor,
    BrowserFingerprint,
    GeoLocation,
)

# New modules
from .proxy_checker import (
    ProxyChecker,
    ProxyCheckResult,
    get_proxy_checker,
)

from .threads_auth import (
    ThreadsSession,
    AuthResult,
)

from .poster import (
    Poster,
    PostResult,
)

from .post_fetcher import (
    PostSearcher,
    Post,
)

from .post_filter import (
    PostFilter,
    FilterConfig,
    GlobalCommentRegistry,
    get_global_registry,
)

from .commenter import (
    Commenter,
    CommentGenerator,
    CommentResult,
)

from .scheduler import (
    AccountScheduler,
    GlobalScheduler,
    ScheduleConfig,
    TaskType,
    TaskResult,
    get_global_scheduler,
)

__all__ = [
    # Account Management
    "AccountManager",
    "Account",
    "ProxyConfig",
    "get_account_manager",
    
    # OpenRouter
    "OpenRouterClient",
    "ModelConfig",
    "get_openrouter_client",
    "DEFAULT_MODELS",
    
    # Engines
    "BaseBrowserEngine",
    "BrowserProfile",
    "FingerprintConfig",
    "NodriverEngine",
    "UCEngine",
    
    # Behavior
    "move_mouse_human_like",
    "move_to_element_human_like",
    "click_element_human_like",
    "type_text_human_like",
    "type_text_human_like_uc",
    "simulate_reading",
    "human_delay",
    "think_delay",
    "reaction_delay",
    
    # Security
    "get_webrtc_blocker",
    "get_fingerprint_factory",
    "get_ip_monitor",
    "BrowserFingerprint",
    "GeoLocation",
    
    # Proxy Checker
    "ProxyChecker",
    "ProxyCheckResult",
    "get_proxy_checker",
    
    # Threads Auth
    "ThreadsSession",
    "AuthResult",
    
    # Poster
    "Poster",
    "PostResult",
    
    # Post Fetcher
    "PostSearcher",
    "Post",
    
    # Post Filter
    "PostFilter",
    "FilterConfig",
    "GlobalCommentRegistry",
    "get_global_registry",
    
    # Commenter
    "Commenter",
    "CommentGenerator",
    "CommentResult",
    
    # Scheduler
    "AccountScheduler",
    "GlobalScheduler",
    "ScheduleConfig",
    "TaskType",
    "TaskResult",
    "get_global_scheduler",
]
