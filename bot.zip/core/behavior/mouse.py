"""
Mouse Behavior Module
Human-like mouse movement using Bezier curves.
"""

import asyncio
import random
import math
from typing import Tuple, List, Optional
from dataclasses import dataclass

from loguru import logger


@dataclass
class Point:
    """2D point representation."""
    x: float
    y: float
    
    def __add__(self, other: "Point") -> "Point":
        return Point(self.x + other.x, self.y + other.y)
    
    def __mul__(self, scalar: float) -> "Point":
        return Point(self.x * scalar, self.y * scalar)


def cubic_bezier(t: float, p0: Point, p1: Point, p2: Point, p3: Point) -> Point:
    """
    Calculate point on cubic Bezier curve.
    
    Args:
        t: Parameter from 0 to 1
        p0: Start point
        p1: First control point
        p2: Second control point
        p3: End point
    
    Returns:
        Point on curve at parameter t
    """
    one_minus_t = 1 - t
    
    return (
        p0 * (one_minus_t ** 3) +
        p1 * (3 * one_minus_t ** 2 * t) +
        p2 * (3 * one_minus_t * t ** 2) +
        p3 * (t ** 3)
    )


def generate_control_points(
    start: Point,
    end: Point,
    curvature: float = 0.5
) -> Tuple[Point, Point]:
    """
    Generate control points for Bezier curve.
    
    Args:
        start: Start point
        end: End point
        curvature: How curved the path should be (0-1)
    
    Returns:
        Tuple of (control_point_1, control_point_2)
    """
    # Calculate direction vector
    dx = end.x - start.x
    dy = end.y - start.y
    distance = math.sqrt(dx ** 2 + dy ** 2)
    
    if distance == 0:
        return start, end
    
    # Perpendicular direction for curve variation
    perp_x = -dy / distance
    perp_y = dx / distance
    
    # Random offset for natural look
    offset = random.uniform(-curvature, curvature) * distance * 0.3
    
    # Control points at 1/3 and 2/3 along the path
    cp1 = Point(
        start.x + dx * 0.3 + perp_x * offset,
        start.y + dy * 0.3 + perp_y * offset
    )
    
    # Second control point with different offset
    offset2 = random.uniform(-curvature, curvature) * distance * 0.2
    cp2 = Point(
        start.x + dx * 0.7 + perp_x * offset2,
        start.y + dy * 0.7 + perp_y * offset2
    )
    
    return cp1, cp2


def calculate_movement_speed(
    distance: float,
    min_speed: float = 300,  # pixels per second
    max_speed: float = 800
) -> float:
    """
    Calculate movement speed based on distance.
    
    Longer distances = faster movement (human behavior)
    """
    # Base speed increases with distance
    speed = min_speed + (distance / 1000) * (max_speed - min_speed)
    
    # Add randomness
    speed *= random.uniform(0.8, 1.2)
    
    # Clamp to range
    return max(min_speed, min(max_speed, speed))


def add_jitter(point: Point, intensity: float = 2.0) -> Point:
    """Add small random jitter to point (micro-corrections)."""
    jitter_x = random.uniform(-intensity, intensity)
    jitter_y = random.uniform(-intensity, intensity)
    return Point(point.x + jitter_x, point.y + jitter_y)


async def move_mouse_human_like(
    engine,
    target_x: int,
    target_y: int,
    duration: Optional[float] = None,
    curvature: float = 0.5
) -> None:
    """
    Move mouse to target position using human-like Bezier curve.
    
    Args:
        engine: Browser engine instance
        target_x: Target X coordinate
        target_y: Target Y coordinate
        duration: Movement duration (auto-calculated if None)
        curvature: Path curvature (0-1)
    """
    try:
        # Get current position
        current_pos = await engine.get_mouse_position()
        start = Point(current_pos[0], current_pos[1])
        end = Point(target_x, target_y)
        
        # Calculate distance
        dx = end.x - start.x
        dy = end.y - start.y
        distance = math.sqrt(dx ** 2 + dy ** 2)
        
        if distance < 5:
            # Very short distance - instant move
            await engine.cdp_execute("Input.dispatchMouseEvent", {
                "type": "mouseMoved",
                "x": target_x,
                "y": target_y
            })
            return
        
        # Calculate duration if not specified
        if duration is None:
            speed = calculate_movement_speed(distance)
            duration = distance / speed
        
        # Add randomness to duration
        duration *= random.uniform(0.9, 1.1)
        
        # Generate control points
        cp1, cp2 = generate_control_points(start, end, curvature)
        
        # Number of steps based on distance
        num_steps = max(10, int(distance / 10))
        step_duration = duration / num_steps
        
        logger.debug(f"Moving mouse from ({start.x:.0f}, {start.y:.0f}) to ({end.x:.0f}, {end.y:.0f}) in {duration:.2f}s")
        
        # Execute movement
        for i in range(num_steps + 1):
            t = i / num_steps
            
            # Get point on Bezier curve
            point = cubic_bezier(t, start, cp1, cp2, end)
            
            # Add jitter for realism (more jitter in middle of movement)
            jitter_intensity = 3.0 * math.sin(t * math.pi)
            point = add_jitter(point, jitter_intensity)
            
            # Dispatch mouse move event via CDP
            await engine.cdp_execute("Input.dispatchMouseEvent", {
                "type": "mouseMoved",
                "x": round(point.x),
                "y": round(point.y)
            })
            
            # Variable delay between steps
            delay_variation = random.uniform(0.8, 1.2)
            await asyncio.sleep(step_duration * delay_variation)
        
        # Final position (exact target)
        await engine.cdp_execute("Input.dispatchMouseEvent", {
            "type": "mouseMoved",
            "x": target_x,
            "y": target_y
        })
        
    except Exception as e:
        logger.error(f"Mouse movement failed: {e}")


async def move_to_element_human_like(
    engine,
    element,
    offset_x: Optional[int] = None,
    offset_y: Optional[int] = None,
    curvature: float = 0.5
) -> bool:
    """
    Move mouse to element with human-like behavior.
    
    Args:
        engine: Browser engine
        element: Target element
        offset_x: Optional X offset from element center
        offset_y: Optional Y offset from element center
        curvature: Path curvature
    
    Returns:
        True if successful
    """
    try:
        # Get element position
        if hasattr(element, 'mouse_move'):
            # nodriver element
            await element.mouse_move()
            return True
        
        # Get element bounds
        bounds = await engine.execute_script("""
            (element) => {
                const rect = element.getBoundingClientRect();
                return {
                    x: rect.left + rect.width / 2,
                    y: rect.top + rect.height / 2,
                    width: rect.width,
                    height: rect.height
                };
            }
        """, element)
        
        if not bounds:
            return False
        
        # Calculate target position
        target_x = bounds['x']
        target_y = bounds['y']
        
        # Add random offset within element
        if offset_x is None:
            offset_x = random.randint(-int(bounds['width'] * 0.3), int(bounds['width'] * 0.3))
        if offset_y is None:
            offset_y = random.randint(-int(bounds['height'] * 0.3), int(bounds['height'] * 0.3))
        
        target_x += offset_x
        target_y += offset_y
        
        # Move mouse
        await move_mouse_human_like(engine, round(target_x), round(target_y), curvature=curvature)
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to move to element: {e}")
        return False


async def click_element_human_like(
    engine,
    element,
    pre_click_delay: Tuple[float, float] = (0.1, 0.3),
    post_click_delay: Tuple[float, float] = (0.1, 0.2)
) -> bool:
    """
    Click element with human-like behavior.
    
    Args:
        engine: Browser engine
        element: Element to click
        pre_click_delay: Delay range before click (min, max)
        post_click_delay: Delay range after click (min, max)
    
    Returns:
        True if successful
    """
    try:
        from .timing import human_delay
        
        # Move to element first
        await move_to_element_human_like(engine, element)
        
        # Small pause before clicking
        await human_delay(*pre_click_delay)
        
        # Perform click
        if hasattr(element, 'click'):
            await element.click()
        else:
            # Get element position and click via CDP
            bounds = await engine.execute_script("""
                (element) => {
                    const rect = element.getBoundingClientRect();
                    return {
                        x: rect.left + rect.width / 2,
                        y: rect.top + rect.height / 2
                    };
                }
            """, element)
            
            if bounds:
                await engine.cdp_execute("Input.dispatchMouseEvent", {
                    "type": "mousePressed",
                    "x": bounds['x'],
                    "y": bounds['y'],
                    "button": "left",
                    "clickCount": 1
                })
                await asyncio.sleep(0.05)
                await engine.cdp_execute("Input.dispatchMouseEvent", {
                    "type": "mouseReleased",
                    "x": bounds['x'],
                    "y": bounds['y'],
                    "button": "left",
                    "clickCount": 1
                })
        
        # Small pause after clicking
        await human_delay(*post_click_delay)
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to click element: {e}")
        return False
