"""
Timing Module
Human-like delays using Gaussian (normal) distribution.
"""

import asyncio
import random
import math
from typing import Tuple, Optional

from loguru import logger


def gaussian_random(
    mean: float,
    std_dev: float,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None
) -> float:
    """
    Generate random number from Gaussian (normal) distribution.
    
    Args:
        mean: Center of distribution (average value)
        std_dev: Standard deviation (spread)
        min_val: Optional minimum value
        max_val: Optional maximum value
    
    Returns:
        Random value from Gaussian distribution
    """
    value = random.gauss(mean, std_dev)
    
    if min_val is not None:
        value = max(min_val, value)
    if max_val is not None:
        value = min(max_val, value)
    
    return value


def calculate_std_dev(min_val: float, max_val: float) -> float:
    """
    Calculate standard deviation from range.
    
    For a normal distribution, ~95% of values fall within 2 std devs of mean.
    We use this to estimate std dev from min/max range.
    """
    mean = (min_val + max_val) / 2
    range_size = max_val - min_val
    
    # 95% of values should be within range
    return range_size / 4


async def human_delay(
    min_seconds: float,
    max_seconds: float,
    distribution: str = "gaussian"
) -> None:
    """
    Pause execution with human-like delay.
    
    Args:
        min_seconds: Minimum delay
        max_seconds: Maximum delay
        distribution: 'gaussian' (default) or 'uniform'
    """
    if distribution == "uniform":
        delay = random.uniform(min_seconds, max_seconds)
    else:
        # Gaussian distribution
        mean = (min_seconds + max_seconds) / 2
        std_dev = calculate_std_dev(min_seconds, max_seconds)
        delay = gaussian_random(mean, std_dev, min_seconds, max_seconds)
    
    await asyncio.sleep(delay)


async def think_delay(complexity: str = "medium") -> None:
    """
    Simulate thinking time based on task complexity.
    
    Args:
        complexity: 'low', 'medium', 'high', or 'very_high'
    """
    delays = {
        "low": (0.5, 1.5),      # Simple decisions
        "medium": (1.0, 3.0),   # Normal interactions
        "high": (2.0, 5.0),     # Complex decisions
        "very_high": (3.0, 8.0) # Major decisions
    }
    
    min_delay, max_delay = delays.get(complexity, delays["medium"])
    await human_delay(min_delay, max_delay)


async def reaction_delay(reaction_type: str = "normal") -> None:
    """
    Simulate human reaction time.
    
    Args:
        reaction_type: 'fast', 'normal', 'slow'
    """
    # Human reaction times (in seconds)
    reactions = {
        "fast": (0.15, 0.3),      # Alert, expecting something
        "normal": (0.25, 0.5),    # Normal attention
        "slow": (0.4, 0.8)        # Distracted or tired
    }
    
    min_delay, max_delay = reactions.get(reaction_type, reactions["normal"])
    await human_delay(min_delay, max_delay)


async def typing_pause(position: int, text_length: int) -> None:
    """
    Simulate pause while typing.
    
    Longer pauses at punctuation, shorter in middle of words.
    
    Args:
        position: Current position in text
        text_length: Total text length
    """
    # Base pause
    base_min, base_max = 0.05, 0.15
    
    # Slightly longer at start and end
    if position < 3 or position > text_length - 3:
        base_min, base_max = 0.1, 0.25
    
    await human_delay(base_min, base_max)


async def scroll_pause() -> None:
    """Pause between scroll actions."""
    await human_delay(0.1, 0.4)


async def page_load_wait(
    min_wait: float = 1.0,
    max_wait: float = 3.0
) -> None:
    """
    Wait for page to "settle" after loading.
    
    Humans don't interact immediately when page loads.
    """
    await human_delay(min_wait, max_wait)


async def between_actions_delay(action_type: str = "normal") -> None:
    """
    Delay between different actions.
    
    Args:
        action_type: 'quick', 'normal', 'careful'
    """
    delays = {
        "quick": (0.2, 0.5),     # Rapid actions
        "normal": (0.5, 1.5),    # Normal pace
        "careful": (1.0, 2.5)    # Careful, deliberate actions
    }
    
    min_delay, max_delay = delays.get(action_type, delays["normal"])
    await human_delay(min_delay, max_delay)


class ActionTimer:
    """
    Timer for tracking and randomizing action timing.
    
    Helps maintain consistent but natural pacing across multiple actions.
    """
    
    def __init__(self):
        self.action_times = []
        self.last_action_time = None
    
    def record_action(self, action_name: str):
        """Record that an action was performed."""
        import time
        current_time = time.time()
        
        if self.last_action_time:
            time_since_last = current_time - self.last_action_time
            self.action_times.append({
                "action": action_name,
                "time_since_last": time_since_last
            })
        
        self.last_action_time = current_time
    
    def get_average_pace(self) -> float:
        """Get average time between actions."""
        if len(self.action_times) < 2:
            return 1.0
        
        times = [a["time_since_last"] for a in self.action_times[1:]]
        return sum(times) / len(times)
    
    def should_slow_down(self) -> bool:
        """Check if actions are too fast and should slow down."""
        if len(self.action_times) < 3:
            return False
        
        avg_pace = self.get_average_pace()
        return avg_pace < 0.5  # Too fast if under 0.5s average
    
    def should_speed_up(self) -> bool:
        """Check if actions are too slow and can speed up."""
        if len(self.action_times) < 3:
            return False
        
        avg_pace = self.get_average_pace()
        return avg_pace > 3.0  # Too slow if over 3s average
    
    async def adaptive_delay(self, base_min: float, base_max: float) -> None:
        """
        Delay that adapts based on recent action pace.
        
        If actions are too fast, adds extra delay.
        If actions are too slow, reduces delay slightly.
        """
        if self.should_slow_down():
            # Add extra delay
            await human_delay(base_min * 1.5, base_max * 1.5)
        elif self.should_speed_up():
            # Reduce delay slightly
            await human_delay(base_min * 0.8, base_max * 0.9)
        else:
            # Normal delay
            await human_delay(base_min, base_max)


# Convenience functions for common delays

async def short_delay() -> None:
    """Very short delay (0.1-0.3s)."""
    await human_delay(0.1, 0.3)


async def medium_delay() -> None:
    """Medium delay (0.5-1.5s)."""
    await human_delay(0.5, 1.5)


async def long_delay() -> None:
    """Long delay (2-5s)."""
    await human_delay(2, 5)


async def random_delay() -> None:
    """Random delay (0.3-3s)."""
    await human_delay(0.3, 3.0)
