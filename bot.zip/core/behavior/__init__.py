"""
Human Behavior Simulation Module

Provides realistic human-like interactions for browser automation.
"""

from .mouse import (
    move_mouse_human_like,
    move_to_element_human_like,
    click_element_human_like,
    Point,
    cubic_bezier,
)

from .keyboard import (
    type_text_human_like,
    type_text_human_like_uc,
    paste_text,
    clear_field_human_like,
    generate_typo,
)

from .reading import (
    simulate_reading,
    simulate_hover_reading,
    simulate_comment_reading,
    simulate_page_scan,
)

from .timing import (
    human_delay,
    think_delay,
    reaction_delay,
    typing_pause,
    scroll_pause,
    page_load_wait,
    between_actions_delay,
    short_delay,
    medium_delay,
    long_delay,
    random_delay,
    gaussian_random,
    ActionTimer,
)

__all__ = [
    # Mouse
    "move_mouse_human_like",
    "move_to_element_human_like",
    "click_element_human_like",
    "Point",
    "cubic_bezier",
    
    # Keyboard
    "type_text_human_like",
    "type_text_human_like_uc",
    "paste_text",
    "clear_field_human_like",
    "generate_typo",
    
    # Reading
    "simulate_reading",
    "simulate_hover_reading",
    "simulate_comment_reading",
    "simulate_page_scan",
    
    # Timing
    "human_delay",
    "think_delay",
    "reaction_delay",
    "typing_pause",
    "scroll_pause",
    "page_load_wait",
    "between_actions_delay",
    "short_delay",
    "medium_delay",
    "long_delay",
    "random_delay",
    "gaussian_random",
    "ActionTimer",
]
