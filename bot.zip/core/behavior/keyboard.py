"""
Keyboard Behavior Module
Human-like text input with typos and corrections.
"""

import asyncio
import random
from typing import Optional, Tuple

from loguru import logger


# Common typo mappings (adjacent keys on QWERTY)
ADJACENT_KEYS = {
    'a': 'sqwz',
    'b': 'vghn',
    'c': 'xdfv',
    'd': 'serfcx',
    'e': 'wsdr',
    'f': 'drtgvc',
    'g': 'ftyhbv',
    'h': 'gyujnb',
    'i': 'uok',
    'j': 'huikmn',
    'k': 'jiolm',
    'l': 'kop',
    'm': 'njk',
    'n': 'bhjm',
    'o': 'iklp',
    'p': 'ol',
    'q': 'wa',
    'r': 'edft',
    's': 'wadxz',
    't': 'rfgy',
    'u': 'yhji',
    'v': 'cfgb',
    'w': 'qase',
    'x': 'zsdc',
    'y': 'tghu',
    'z': 'asx',
    ' ': 'xcvbnm',
}


def generate_typo(char: str) -> str:
    """Generate a typo for a character (adjacent key)."""
    char_lower = char.lower()
    
    if char_lower in ADJACENT_KEYS:
        typo = random.choice(ADJACENT_KEYS[char_lower])
        # Preserve case
        if char.isupper():
            typo = typo.upper()
        return typo
    
    return char


def should_make_typo(position: int, text_length: int, typo_rate: float = 0.02) -> bool:
    """
    Decide whether to make a typo at this position.
    
    Args:
        position: Current character position
        text_length: Total text length
        typo_rate: Base typo probability (1-3% recommended)
    
    Returns:
        True if should make typo
    """
    # Don't make typos at very start or end
    if position < 2 or position > text_length - 2:
        return False
    
    # Don't make two typos in a row
    if random.random() < typo_rate:
        return True
    
    return False


def get_typing_delay(char: str, base_delay: Tuple[float, float] = (0.05, 0.15)) -> float:
    """
    Get typing delay for a character.
    
    Different characters have different typing speeds:
    - Space: faster
    - Punctuation: slower
    - Capital letters: slower (shift key)
    """
    min_delay, max_delay = base_delay
    
    if char == ' ':
        # Space is usually fast
        return random.uniform(min_delay * 0.7, max_delay * 0.8)
    
    if char in '.,!?;:\'"':
        # Punctuation requires more precision
        return random.uniform(min_delay * 1.2, max_delay * 1.5)
    
    if char.isupper():
        # Capital letters (shift key)
        return random.uniform(min_delay * 1.1, max_delay * 1.3)
    
    # Normal character
    return random.uniform(min_delay, max_delay)


async def type_text_human_like(
    engine,
    element,
    text: str,
    typo_rate: float = 0.02,
    base_delay: Tuple[float, float] = (0.05, 0.15)
) -> None:
    """
    Type text with human-like behavior using nodriver.
    
    Args:
        engine: Browser engine
        element: Input element
        text: Text to type
        typo_rate: Probability of making a typo (0.01-0.03 recommended)
        base_delay: Base typing delay range (min, max) in seconds
    """
    try:
        logger.debug(f"Typing text (length: {len(text)}, typo_rate: {typo_rate})")
        
        typo_made = False
        typo_position = -1
        
        for i, char in enumerate(text):
            # Check if we should make a typo
            if not typo_made and should_make_typo(i, len(text), typo_rate):
                # Make a typo
                typo_char = generate_typo(char)
                
                # Type the typo
                await element.send_keys(typo_char)
                await asyncio.sleep(get_typing_delay(typo_char, base_delay))
                
                # Realize the mistake (pause)
                await asyncio.sleep(random.uniform(0.2, 0.5))
                
                # Delete the typo
                await element.send_keys('\b')  # Backspace
                await asyncio.sleep(random.uniform(0.1, 0.2))
                
                # Type correct character
                await element.send_keys(char)
                
                typo_made = True
                typo_position = i
            else:
                # Type normal character
                await element.send_keys(char)
            
            # Delay before next character
            delay = get_typing_delay(char, base_delay)
            
            # Occasionally pause longer (thinking)
            if random.random() < 0.05:
                delay *= random.uniform(2, 4)
            
            await asyncio.sleep(delay)
        
        logger.debug("Finished typing")
        
    except Exception as e:
        logger.error(f"Typing failed: {e}")


async def type_text_human_like_uc(
    engine,
    element,
    text: str,
    typo_rate: float = 0.02,
    base_delay: Tuple[float, float] = (0.05, 0.15)
) -> None:
    """
    Type text with human-like behavior using undetected-chromedriver.
    
    Args:
        engine: Browser engine (UC)
        element: Input element
        text: Text to type
        typo_rate: Probability of making a typo
        base_delay: Base typing delay range
    """
    try:
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.keys import Keys
        
        logger.debug(f"Typing text (length: {len(text)}, typo_rate: {typo_rate})")
        
        actions = ActionChains(engine.driver)
        typo_made = False
        
        for i, char in enumerate(text):
            # Check if we should make a typo
            if not typo_made and should_make_typo(i, len(text), typo_rate):
                # Make a typo
                typo_char = generate_typo(char)
                
                # Type the typo
                actions.send_keys(typo_char)
                actions.pause(get_typing_delay(typo_char, base_delay))
                
                # Realize the mistake
                actions.pause(random.uniform(0.2, 0.5))
                
                # Delete the typo
                actions.send_keys(Keys.BACKSPACE)
                actions.pause(random.uniform(0.1, 0.2))
                
                # Type correct character
                actions.send_keys(char)
                
                typo_made = True
            else:
                # Type normal character
                actions.send_keys(char)
            
            # Delay before next character
            delay = get_typing_delay(char, base_delay)
            
            # Occasionally pause longer
            if random.random() < 0.05:
                delay *= random.uniform(2, 4)
            
            actions.pause(delay)
        
        # Execute all actions
        actions.perform()
        
        logger.debug("Finished typing")
        
    except Exception as e:
        logger.error(f"Typing failed: {e}")


async def paste_text(engine, element, text: str) -> None:
    """
    Paste text (Ctrl+V) - faster but less human-like.
    
    Use for non-critical fields like search boxes.
    """
    try:
        # Clear field first
        if hasattr(element, 'clear'):
            element.clear()
        
        # Type the text directly (no human simulation)
        await element.send_keys(text)
        
    except Exception as e:
        logger.error(f"Paste failed: {e}")


async def clear_field_human_like(engine, element) -> None:
    """
    Clear a text field with human-like behavior.
    
    Sometimes uses Ctrl+A + Delete, sometimes multiple Backspaces.
    """
    try:
        method = random.choice(['ctrl_a', 'backspaces', 'triple_click'])
        
        if method == 'ctrl_a':
            # Select all and delete
            if hasattr(engine, 'cdp_execute'):
                # nodriver
                await element.send_keys('\u0001')  # Ctrl+A
                await asyncio.sleep(0.1)
                await element.send_keys('\u007f')  # Delete
            else:
                # UC
                from selenium.webdriver.common.keys import Keys
                element.send_keys(Keys.CONTROL + 'a')
                await asyncio.sleep(0.1)
                element.send_keys(Keys.DELETE)
        
        elif method == 'backspaces':
            # Get text length and press backspace multiple times
            text = await engine.get_text(element) if hasattr(engine, 'get_text') else element.text
            length = len(text) if text else 20
            
            for _ in range(min(length + 5, 50)):
                await element.send_keys('\b')
                await asyncio.sleep(random.uniform(0.03, 0.08))
        
        else:  # triple_click
            # Triple click to select all, then type
            if hasattr(element, 'mouse_click'):
                await element.mouse_click()
                await element.mouse_click()
                await element.mouse_click()
            
            await asyncio.sleep(0.1)
            await element.send_keys('\u007f')  # Delete
        
    except Exception as e:
        logger.error(f"Clear field failed: {e}")
