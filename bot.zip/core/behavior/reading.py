"""
Reading Simulation Module
Simulates human reading behavior with scrolling and pauses.
"""

import asyncio
import random
from typing import Optional, Tuple

from loguru import logger

from .timing import human_delay


async def simulate_reading(
    engine,
    element=None,
    read_percentage: float = 0.8,
    scroll_behavior: str = "smooth"
) -> bool:
    """
    Simulate reading a post or article.
    
    Behavior pattern:
    1. Scroll down 60-80% of content
    2. Pause 2-5 seconds (reading)
    3. 40% chance: scroll back up 10-20%
    4. Pause 1-2 seconds
    5. Scroll to end
    
    Args:
        engine: Browser engine
        element: Optional specific element to read (if None, reads whole page)
        read_percentage: How much of content to read (0.6-0.9)
        scroll_behavior: 'smooth' or 'instant'
    
    Returns:
        True if simulation completed
    """
    try:
        logger.debug("Starting reading simulation")
        
        # Get page/element dimensions
        if element:
            dimensions = await engine.execute_script("""
                (element) => {
                    const rect = element.getBoundingClientRect();
                    return {
                        height: rect.height,
                        scrollHeight: element.scrollHeight || rect.height
                    };
                }
            """, element)
        else:
            dimensions = await engine.execute_script("""
                return {
                    height: window.innerHeight,
                    scrollHeight: document.body.scrollHeight
                };
            """)
        
        if not dimensions:
            return False
        
        content_height = dimensions.get('scrollHeight', 1000)
        viewport_height = dimensions.get('height', 800)
        
        # Calculate scroll positions
        total_scroll = content_height - viewport_height
        
        if total_scroll <= 0:
            # Content fits in viewport, just pause
            await human_delay(2, 4)
            return True
        
        # Phase 1: Initial scroll down (60-80% of content)
        initial_scroll = int(total_scroll * random.uniform(0.6, read_percentage))
        
        logger.debug(f"Phase 1: Scrolling to {initial_scroll}px")
        await _smooth_scroll(engine, initial_scroll, scroll_behavior)
        
        # Phase 2: Reading pause (2-5 seconds)
        read_time = random.uniform(2, 5)
        logger.debug(f"Phase 2: Reading for {read_time:.1f}s")
        await human_delay(read_time, read_time + 0.5)
        
        # Phase 3: Possible scroll back (40% chance)
        if random.random() < 0.4:
            scroll_back_amount = int(initial_scroll * random.uniform(0.1, 0.2))
            new_position = max(0, initial_scroll - scroll_back_amount)
            
            logger.debug(f"Phase 3: Scrolling back to {new_position}px")
            await _smooth_scroll(engine, new_position, scroll_behavior)
            
            # Phase 4: Second pause (1-2 seconds)
            second_pause = random.uniform(1, 2)
            logger.debug(f"Phase 4: Second pause for {second_pause:.1f}s")
            await human_delay(second_pause, second_pause + 0.3)
        
        # Phase 5: Scroll to end
        logger.debug("Phase 5: Scrolling to end")
        await _smooth_scroll(engine, total_scroll, scroll_behavior)
        
        # Final pause
        await human_delay(0.5, 1.5)
        
        logger.debug("Reading simulation completed")
        return True
        
    except Exception as e:
        logger.error(f"Reading simulation failed: {e}")
        return False


async def _smooth_scroll(engine, target_y: int, behavior: str = "smooth") -> None:
    """
    Smooth scroll to target Y position.
    
    Args:
        engine: Browser engine
        target_y: Target scroll position
        behavior: 'smooth' or 'instant'
    """
    try:
        if behavior == "instant":
            await engine.execute_script(f"window.scrollTo(0, {target_y})")
            return
        
        # Smooth scroll with multiple steps
        current_y = await engine.execute_script("return window.pageYOffset;")
        
        distance = target_y - current_y
        if abs(distance) < 10:
            await engine.execute_script(f"window.scrollTo(0, {target_y})")
            return
        
        # Number of steps based on distance
        num_steps = max(5, min(20, abs(distance) // 100))
        step_size = distance / num_steps
        
        for i in range(num_steps):
            new_y = current_y + step_size * (i + 1)
            await engine.execute_script(f"window.scrollTo(0, {int(new_y)})")
            
            # Variable delay between scrolls
            delay = random.uniform(0.03, 0.08)
            await asyncio.sleep(delay)
        
        # Ensure final position
        await engine.execute_script(f"window.scrollTo(0, {target_y})")
        
    except Exception as e:
        logger.error(f"Smooth scroll failed: {e}")


async def simulate_hover_reading(
    engine,
    element,
    min_duration: float = 1.0,
    max_duration: float = 3.0
) -> bool:
    """
    Simulate reading by hovering over element.
    
    Used for short content like comments or tweets.
    
    Args:
        engine: Browser engine
        element: Element to hover over
        min_duration: Minimum hover time
        max_duration: Maximum hover time
    
    Returns:
        True if successful
    """
    try:
        from .mouse import move_to_element_human_like
        
        # Move to element
        await move_to_element_human_like(engine, element)
        
        # Hover duration
        duration = random.uniform(min_duration, max_duration)
        
        logger.debug(f"Hover reading for {duration:.1f}s")
        await asyncio.sleep(duration)
        
        return True
        
    except Exception as e:
        logger.error(f"Hover reading failed: {e}")
        return False


async def simulate_comment_reading(
    engine,
    comment_elements: list,
    read_ratio: float = 0.7
) -> int:
    """
    Simulate reading multiple comments.
    
    Args:
        engine: Browser engine
        comment_elements: List of comment elements
        read_ratio: Ratio of comments to "read" (0.5-1.0)
    
    Returns:
        Number of comments "read"
    """
    try:
        num_to_read = max(1, int(len(comment_elements) * read_ratio))
        comments_to_read = random.sample(comment_elements, min(num_to_read, len(comment_elements)))
        
        read_count = 0
        
        for comment in comments_to_read:
            # Scroll comment into view
            await engine.scroll_to(comment)
            
            # Simulate reading
            success = await simulate_hover_reading(
                engine,
                comment,
                min_duration=1.5,
                max_duration=4.0
            )
            
            if success:
                read_count += 1
            
            # Small pause between comments
            await human_delay(0.3, 0.8)
        
        logger.debug(f"Read {read_count} comments")
        return read_count
        
    except Exception as e:
        logger.error(f"Comment reading failed: {e}")
        return 0


async def simulate_page_scan(
    engine,
    scan_duration: Tuple[float, float] = (3, 8)
) -> bool:
    """
    Quick page scan - scroll through without deep reading.
    
    Used for feed browsing.
    
    Args:
        engine: Browser engine
        scan_duration: Total scan time range
    
    Returns:
        True if successful
    """
    try:
        duration = random.uniform(*scan_duration)
        start_time = asyncio.get_event_loop().time()
        
        scroll_count = 0
        
        while asyncio.get_event_loop().time() - start_time < duration:
            # Random scroll amount
            scroll_amount = random.randint(300, 800)
            
            # Scroll
            await engine.scroll_by(0, scroll_amount)
            
            # Brief pause
            await human_delay(0.2, 0.6)
            
            scroll_count += 1
            
            # Occasionally pause longer (found something interesting)
            if random.random() < 0.2:
                await human_delay(1, 2)
        
        logger.debug(f"Page scan completed: {scroll_count} scrolls")
        return True
        
    except Exception as e:
        logger.error(f"Page scan failed: {e}")
        return False
