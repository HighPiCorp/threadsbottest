# Руководство по решению проблем

## Оглавление

1. [Общие проблемы](#общие-проблемы)
2. [Проблемы с браузером](#проблемы-с-браузером)
3. [Проблемы с прокси](#проблемы-с-прокси)
4. [Проблемы с OpenRouter](#проблемы-с-openrouter)
5. [Проблемы с аккаунтами](#проблемы-с-аккаунтами)
6. [Проблемы с антидетектом](#проблемы-с-антидетектом)

---

## Общие проблемы

### Ошибка "ModuleNotFoundError"

**Симптом:**
```
ModuleNotFoundError: No module named 'nodriver'
```

**Решение:**
```bash
# Переустановите зависимости
pip install -r requirements.txt --force-reinstall
```

### Ошибка "Permission denied"

**Симптом:**
```
PermissionError: [Errno 13] Permission denied
```

**Решение:**
1. Запустите PowerShell от имени администратора
2. Или переместите папку проекта в другое место (не Program Files)

---

## Проблемы с браузером

### Chrome не найден

**Проверка:**
```powershell
# Проверьте, установлен ли Chrome
Get-ItemProperty "HKLM:\Software\Google\Chrome\BLBeacon" -Name "version"
```

**Решение:**
```python
# В коде укажите путь к Chrome
import os
os.environ["CHROME_PATH"] = "C:\\Path\\To\\Chrome\\chrome.exe"
```

### Браузер открывается и сразу закрывается

**Причины:**
1. Конфликт с антивирусом
2. Повреждённый профиль Chrome

**Решение:**
```bash
# Очистите временные данные
rmdir /s /q %TEMP%\nodriver_*  # Windows
rm -rf /tmp/nodriver_*         # Linux/Mac
```

---

## Проблемы с прокси

### Прокси не работает

**Проверка:**
```powershell
# Проверьте прокси через curl
curl -x http://proxy:port https://ipinfo.io
```

**Диагностика в боте:**
```python
# Добавьте в код для проверки
from core.security import get_ip_monitor

monitor = get_ip_monitor()
geo = await monitor.get_ip_geolocation(proxy="http://your-proxy:port")
print(f"IP через прокси: {geo.ip}")
```

### Медленное соединение

**Оптимизация:**
1. Используйте прокси ближе к вашему местоположению
2. Проверьте скорость прокси:
   ```powershell
   Measure-Command { curl -x http://proxy:port https://google.com }
   ```

---

## Проблемы с OpenRouter

### Ошибка 401 (Unauthorized)

**Причина:** Неверный API ключ

**Решение:**
1. Проверьте ключ на [openrouter.ai/keys](https://openrouter.ai/keys)
2. Убедитесь, что ключ начинается с `sk-or-v1-`

### Ошибка 429 (Rate Limited)

**Причина:** Слишком много запросов

**Решение:**
- Бот автоматически переключает модель
- Добавьте задержку между запросами:
  ```python
  await human_delay(2, 5)  # 2-5 секунд паузы
  ```

### Ошибка таймаута

**Решение:**
```python
# Увеличьте таймаут в OpenRouterClient
client = OpenRouterClient(
    api_key="your-key",
    timeout=120  # Увеличьте с 60 до 120
)
```

---

## Проблемы с аккаунтами

### Забыл мастер-пароль

**⚠️ ВАЖНО:** Данные восстановить **невозможно**!

**Что делать:**
1. Удалите файл `config/accounts.enc`
2. Запустите `python main.py --setup` заново
3. Добавьте аккаунты снова

### Аккаунт не добавляется

**Проверьте:**
1. Правильность формата прокси
2. Уникальность username
3. Доступность файловой системы

---

## Проблемы с антидетектом

### Обнаружена автоматизация

**Признаки:**
- CAPTCHA появляется часто
- Аккаунт временно заблокирован
- Сообщение "Подозрительная активность"

**Решения:**

1. **Увеличьте задержки:**
   ```python
   # В core/behavior/timing.py
   DEFAULT_DELAY_MULTIPLIER = 2.0  # Увеличьте множитель
   ```

2. **Уменьшите активность:**
   ```json
   // В config/settings.json
   {
     "max_daily_posts": 3,
     "max_daily_comments": 10,
     "action_cooldown_minutes": 30
   }
   ```

3. **Используйте лучшие прокси**

### Утечка WebRTC

**Проверка:**
1. Откройте [browserleaks.com/webrtc](https://browserleaks.com/webrtc)
2. Проверьте, виден ли ваш реальный IP

**Решение:**
```python
# Убедитесь, что WebRTC блокер активирован
from core.security import get_webrtc_blocker

blocker = get_webrtc_blocker()
await blocker.apply(engine)

# Проверьте статус
result = await blocker.verify(engine)
print(f"WebRTC blocked: {result['blocked']}")
```

### Несоответствие часового пояса

**Проверка:**
```javascript
// В консоли браузера
new Date().toString()
Intl.DateTimeFormat().resolvedOptions().timeZone
```

**Решение:**
```python
# Установите правильный часовой пояс
from core.security import get_ip_monitor

monitor = get_ip_monitor()
geo = await monitor.get_ip_geolocation(proxy="your-proxy")
await monitor.apply_geolocation_to_browser(engine, geo)
```

---

## Сбор диагностической информации

Если нужна помощь, соберите следующую информацию:

```powershell
# 1. Версии
python --version
pip list | findstr -i "nodriver selenium pyqt"

# 2. Логи
Get-Content logs/bot.log -Tail 50

# 3. Конфигурация
Get-Content config/settings.json

# 4. Проверка IP
.\scripts\check_ip_leak.ps1
```

---

## Контакты

Если проблема не решена:

1. Создайте Issue с:
   - Описанием проблемы
   - Логами (logs/bot.log)
   - Версиями ПО
   - Шагами воспроизведения
