# Настройка Windows для Threads Automation Bot

## Подготовка системы

### 1. Обновление Windows

Убедитесь, что Windows обновлена:
```powershell
# Проверка обновлений
Install-Module PSWindowsUpdate -Force
Get-WindowsUpdate
```

### 2. Установка Python

**Вариант 1: С официального сайта**
1. Скачайте с [python.org](https://python.org)
2. **ВАЖНО:** Отметьте "Add Python to PATH"
3. Выберите "Customize installation"
4. Убедитесь, что выбрано:
   - pip
   - py launcher
   - Add Python to environment variables

**Вариант 2: Через Microsoft Store**
```powershell
winget install Python.Python.3.11
```

**Проверка установки:**
```powershell
python --version  # Должно показать 3.10+
pip --version
```

### 3. Настройка PowerShell

**Включение выполнения скриптов:**
```powershell
# Откройте PowerShell от имени администратора
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Установка полезных модулей:**
```powershell
Install-Module -Name PSReadLine -Force
```

## Установка бота

### 1. Создание рабочей папки

```powershell
# Создайте папку в удобном месте
New-Item -ItemType Directory -Path "C:\Tools\ThreadsBot" -Force
Set-Location "C:\Tools\ThreadsBot"
```

### 2. Клонирование репозитория

```powershell
# Если установлен Git
git clone https://github.com/yourusername/threads-automator.git .

# Или скачайте ZIP и распакуйте
```

### 3. Создание виртуального окружения

```powershell
# Создайте venv
python -m venv venv

# Активируйте
.\venv\Scripts\Activate.ps1

# Проверьте (должно появиться (venv) в начале строки)
```

### 4. Установка зависимостей

```powershell
# Обновите pip
python -m pip install --upgrade pip

# Установите зависимости
pip install -r requirements.txt

# Проверьте установку
pip list
```

## Настройка Chrome

### 1. Установка Chrome

```powershell
# Через winget
winget install Google.Chrome

# Или скачайте с google.com/chrome
```

### 2. Отключение автоматического обновления (опционально)

```powershell
# Отключение автообновления через реестр
$regPath = "HKLM:\SOFTWARE\Policies\Google\Update"
New-Item -Path $regPath -Force
Set-ItemProperty -Path $regPath -Name "AutoUpdateCheckPeriodMinutes" -Value 0
```

### 3. Создание отдельного профиля для бота

```powershell
# Создайте ярлык для Chrome с отдельным профилем
$chromePath = "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe"
$profilePath = "C:\Tools\ThreadsBot\chrome-profile"

# Запустите Chrome с новым профилем
Start-Process $chromePath -ArgumentList "--user-data-dir=`"$profilePath`""
```

## Настройка брандмауэра

### Разрешение исходящих соединений

```powershell
# Создайте правило для Python
New-NetFirewallRule -DisplayName "Threads Bot Python" `
    -Direction Outbound `
    -Program "C:\Tools\ThreadsBot\venv\Scripts\python.exe" `
    -Action Allow

# Создайте правило для Chrome
New-NetFirewallRule -DisplayName "Threads Bot Chrome" `
    -Direction Outbound `
    -Program "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe" `
    -Action Allow
```

## Настройка прокси

### Системные настройки прокси

```powershell
# Установка системного прокси (опционально)
$proxy = "http://proxy.example.com:8080"

# Для текущего пользователя
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" `
    -Name ProxyServer -Value $proxy
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" `
    -Name ProxyEnable -Value 1
```

### Проверка прокси

```powershell
# Создайте скрипт проверки
$testScript = @"
`$proxy = 'http://your-proxy:port'
`$wc = New-Object System.Net.WebClient
`$wc.Proxy = New-Object System.Net.WebProxy(`$proxy)
`$wc.DownloadString('https://ipinfo.io')
"@

$testScript | Out-File -FilePath "test-proxy.ps1"
.\test-proxy.ps1
```

## Автозапуск (опционально)

### Создание задачи в Планировщике

```powershell
# Создайте задачу для автозапуска
$action = New-ScheduledTaskAction `
    -Execute "C:\Tools\ThreadsBot\venv\Scripts\python.exe" `
    -Argument "C:\Tools\ThreadsBot\main.py --gui" `
    -WorkingDirectory "C:\Tools\ThreadsBot"

$trigger = New-ScheduledTaskTrigger -AtLogon

$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

Register-ScheduledTask -TaskName "Threads Bot" `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings
```

## Оптимизация производительности

### 1. Настройка приоритета процесса

```powershell
# Запустите бот, затем установите приоритет
$process = Get-Process -Name "python" | Where-Object { $_.MainWindowTitle -like "*Threads*" }
$process.PriorityClass = "AboveNormal"
```

### 2. Ограничение использования RAM

```powershell
# В config/settings.json
{
  "max_concurrent_accounts": 3,
  "browser_restart_interval_hours": 2,
  "memory_limit_mb": 4096
}
```

### 3. Очистка временных файлов

```powershell
# Создайте задачу очистки
$cleanupScript = @"
Get-ChildItem -Path `$env:TEMP -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Tools\ThreadsBot\logs" -File | Where-Object { `$_.CreationTime -lt (Get-Date).AddDays(-7) } | Remove-Item
"@

$cleanupScript | Out-File -FilePath "cleanup.ps1"

# Добавьте в Планировщик задач
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-File C:\Tools\ThreadsBot\cleanup.ps1"
$trigger = New-ScheduledTaskTrigger -Daily -At "3:00 AM"
Register-ScheduledTask -TaskName "Threads Bot Cleanup" -Action $action -Trigger $trigger
```

## Мониторинг

### Просмотр логов в реальном времени

```powershell
# Отслеживание логов
Get-Content -Path "logs/bot.log" -Wait -Tail 50

# Или используйте tail (если установлен)
tail -f logs/bot.log
```

### Мониторинг ресурсов

```powershell
# Процессы бота
Get-Process | Where-Object { $_.ProcessName -in @("python", "chrome") } |
    Select-Object Name, Id, CPU, WorkingSet |
    Format-Table -AutoSize

# Использование сети
Get-NetTCPConnection | Where-Object { $_.OwningProcess -in (Get-Process python).Id }
```

## Безопасность

### Шифрование файлов

```powershell
# Windows EFS для конфигурационных файлов
$certs = Get-ChildItem -Path "Cert:\CurrentUser\My" -DocumentEncryptionCert
if (-not $certs) {
    New-SelfSignedCertificate -DnsName "ThreadsBot" -CertStoreLocation "Cert:\CurrentUser\My" -KeyUsage DocumentEncryption
}

# Зашифруйте конфигурацию
$configFiles = Get-ChildItem -Path "config" -File
foreach ($file in $configFiles) {
    (Get-Item $file.FullName).Encrypt()
}
```

### Брандмауэр Windows

```powershell
# Просмотр правил
Get-NetFirewallRule | Where-Object { $_.DisplayName -like "*Threads*" }

# Удаление правила
Remove-NetFirewallRule -DisplayName "Threads Bot Python"
```

## Решение специфических проблем Windows

### Ошибка "DLL load failed"

```powershell
# Установите Visual C++ Redistributable
winget install Microsoft.VCRedist.2015+.x64
```

### Ошибка "Access is denied" для Chrome

```powershell
# Закройте все процессы Chrome
Get-Process chrome | Stop-Process -Force

# Или используйте диспетчер задач
```

### Долгий запуск первого раза

```powershell
# Windows Defender может сканировать файлы
# Добавьте исключение
Add-MpPreference -ExclusionPath "C:\Tools\ThreadsBot"
```

## Полезные команды

```powershell
# Быстрый перезапуск бота
function Restart-ThreadsBot {
    Get-Process python | Where-Object { $_.MainWindowTitle -like "*Threads*" } | Stop-Process -Force
    Start-Sleep 2
    Set-Location C:\Tools\ThreadsBot
    .\venv\Scripts\Activate.ps1
    python main.py --gui
}

# Проверка статуса
function Get-ThreadsBotStatus {
    $python = Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like "*Threads*" }
    $chrome = Get-Process chrome -ErrorAction SilentlyContinue
    
    [PSCustomObject]@{
        PythonRunning = [bool]$python
        ChromeProcesses = $chrome.Count
        Uptime = if ($python) { (Get-Date) - $python.StartTime } else $null
    }
}
```

---

Для дополнительной помощи обратитесь к [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
