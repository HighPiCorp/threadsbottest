# Threads Automation Bot - Register in Windows Startup
# This script adds the bot to Windows startup

param(
    [string]$BotPath = $PSScriptRoot,
    [switch]$Remove,
    [switch]$GUI
)

$ErrorActionPreference = "Stop"

# Colors
function Write-Info { param($Message) Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Success { param($Message) Write-Host "[PASS] $Message" -ForegroundColor Green }
function Write-Error { param($Message) Write-Host "[FAIL] $Message" -ForegroundColor Red }

Write-Host ""
Write-Host "========================================" -ForegroundColor Blue
Write-Host "  Startup Registration Tool" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""

# Resolve full path
$BotPath = Resolve-Path $BotPath | Select-Object -ExpandProperty Path
$MainScript = Join-Path $BotPath "main.py"
$VenvPython = Join-Path $BotPath "venv\Scripts\python.exe"

# Verify bot installation
if (-not (Test-Path $MainScript)) {
    Write-Error "Bot not found at $BotPath"
    Write-Host "Please run this script from the bot directory or specify -BotPath"
    exit 1
}

if (-not (Test-Path $VenvPython)) {
    Write-Error "Virtual environment not found at $VenvPython"
    Write-Host "Please create venv first: python -m venv venv"
    exit 1
}

# Startup folder path
$StartupFolder = [Environment]::GetFolderPath("Startup")
$ShortcutName = "Threads Automation Bot.lnk"
$ShortcutPath = Join-Path $StartupFolder $ShortcutName

if ($Remove) {
    # Remove from startup
    Write-Host "Removing from startup..." -ForegroundColor Yellow
    
    if (Test-Path $ShortcutPath) {
        Remove-Item $ShortcutPath -Force
        Write-Success "Removed from startup"
    } else {
        Write-Info "Not found in startup"
    }
    
    # Also check Task Scheduler
    $task = Get-ScheduledTask -TaskName "Threads Bot" -ErrorAction SilentlyContinue
    if ($task) {
        Unregister-ScheduledTask -TaskName "Threads Bot" -Confirm:$false
        Write-Success "Removed scheduled task"
    }
    
    exit 0
}

# Add to startup
Write-Host "Adding to Windows startup..." -ForegroundColor Cyan
Write-Host ""

Write-Host "Choose method:" -ForegroundColor Yellow
Write-Host "  1. Startup Folder (simple, user-level)"
Write-Host "  2. Task Scheduler (advanced, with delay options)"
Write-Host ""

$choice = Read-Host "Enter choice (1 or 2)"

switch ($choice) {
    "1" {
        # Startup Folder method
        Write-Host ""
        Write-Info "Creating startup shortcut..."
        
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
        
        $Shortcut.TargetPath = $VenvPython
        $Shortcut.Arguments = '"' + $MainScript + '"' + $(if ($GUI) { " --gui" } else { "" })
        $Shortcut.WorkingDirectory = $BotPath
        $Shortcut.IconLocation = "${env:SystemRoot}\System32\SHELL32.dll,14"
        $Shortcut.Description = "Threads Automation Bot v2.0"
        
        # Window style: 1=Normal, 7=Minimized
        $Shortcut.WindowStyle = 7
        
        $Shortcut.Save()
        
        Write-Success "Added to startup folder: $ShortcutPath"
        Write-Host ""
        Write-Host "The bot will start automatically when you log in." -ForegroundColor Green
        Write-Host "To remove, run: .\scripts\register_startup.ps1 -Remove" -ForegroundColor Yellow
    }
    
    "2" {
        # Task Scheduler method
        Write-Host ""
        Write-Info "Creating scheduled task..."
        
        # Check if running as admin
        $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        
        if (-not $isAdmin) {
            Write-Error "Task Scheduler method requires Administrator privileges"
            Write-Host "Please run PowerShell as Administrator and try again" -ForegroundColor Yellow
            exit 1
        }
        
        # Task settings
        $delay = Read-Host "Delay after login (in minutes, 0 for immediate)"
        if (-not [int]::TryParse($delay, [ref]$null)) { $delay = 0 }
        
        $withGui = Read-Host "Start with GUI? (y/n)"
        $guiFlag = if ($withGui -eq "y") { "--gui" } else { "" }
        
        # Create action
        $action = New-ScheduledTaskAction `
            -Execute $VenvPython `
            -Argument "`"$MainScript`" $guiFlag" `
            -WorkingDirectory $BotPath
        
        # Create trigger
        $triggerParams = @{ 
            AtLogon = $true
        }
        if ($delay -gt 0) {
            $triggerParams['Delay'] = New-TimeSpan -Minutes $delay
        }
        $trigger = New-ScheduledTaskTrigger @triggerParams
        
        # Create principal (run as current user)
        $principal = New-ScheduledTaskPrincipal `
            -UserId $env:USERNAME `
            -LogonType Interactive `
            -RunLevel Highest
        
        # Create settings
        $settings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -StartWhenAvailable `
            -MultipleInstances IgnoreNew
        
        # Register task
        try {
            Register-ScheduledTask `
                -TaskName "Threads Bot" `
                -Action $action `
                -Trigger $trigger `
                -Principal $principal `
                -Settings $settings `
                -Force `
                -ErrorAction Stop
            
            Write-Success "Scheduled task created successfully!"
            Write-Host ""
            Write-Host "Task details:" -ForegroundColor Cyan
            Write-Host "  Name: Threads Bot"
            Write-Host "  Trigger: At logon" + $(if ($delay -gt 0) { " (delay: $delay min)" } else { "" })
            Write-Host "  GUI: $(if ($guiFlag) { 'Yes' } else { 'No' })"
            Write-Host ""
            Write-Host "To manage: Open Task Scheduler → Task Scheduler Library → Threads Bot" -ForegroundColor Yellow
            Write-Host "To remove: .\scripts\register_startup.ps1 -Remove" -ForegroundColor Yellow
        }
        catch {
            Write-Error "Failed to create task: $_"
            exit 1
        }
    }
    
    default {
        Write-Error "Invalid choice"
        exit 1
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Blue
Write-Host "  Done!" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""
