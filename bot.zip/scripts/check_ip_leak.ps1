# Threads Automation Bot - IP Leak Check Script
# This script checks for IP and WebRTC leaks through the configured proxy

param(
    [string]$ProxyUrl = "",
    [string]$ChromePath = "",
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"

# Colors for output
function Write-Info { param($Message) Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Success { param($Message) Write-Host "[PASS] $Message" -ForegroundColor Green }
function Write-Warning { param($Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "[FAIL] $Message" -ForegroundColor Red }

Write-Host ""
Write-Host "========================================" -ForegroundColor Blue
Write-Host "  Threads Bot - IP Leak Check Tool" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""

# Check if Chrome is installed
if (-not $ChromePath) {
    $ChromePaths = @(
        "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "${env:LocalAppData}\Google\Chrome\Application\chrome.exe"
    )
    
    foreach ($path in $ChromePaths) {
        if (Test-Path $path) {
            $ChromePath = $path
            break
        }
    }
}

if (-not $ChromePath -or -not (Test-Path $ChromePath)) {
    Write-Error "Google Chrome not found. Please install Chrome or specify path with -ChromePath"
    exit 1
}

Write-Info "Chrome found: $ChromePath"

# Get real IP (without proxy)
Write-Info "Detecting your real IP address..."
try {
    $RealIP = (Invoke-RestMethod -Uri "https://api.ipify.org?format=json" -TimeoutSec 10).ip
    Write-Info "Your real IP: $RealIP"
} catch {
    Write-Warning "Could not detect real IP: $_"
    $RealIP = "Unknown"
}

# Build Chrome arguments
$ChromeArgs = @(
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-blink-features=AutomationControlled",
    "--disable-web-security",
    "--disable-features=IsolateOrigins,site-per-process",
    "--disable-site-isolation-trials"
)

if ($ProxyUrl) {
    $ChromeArgs += "--proxy-server=$ProxyUrl"
    $ChromeArgs += '--proxy-bypass-list=""'
    Write-Info "Using proxy: $ProxyUrl"
} else {
    Write-Warning "No proxy specified - checking direct connection"
}

# Test URLs
$TestUrls = @(
    @{ Name = "ipleak.net"; Url = "https://ipleak.net/" },
    @{ Name = "browserleaks.com/webrtc"; Url = "https://browserleaks.com/webrtc" },
    @{ Name = "pixelscan.net"; Url = "https://pixelscan.net/" }
)

Write-Host ""
Write-Info "Starting leak detection tests..."
Write-Host ""

$TestResults = @()

foreach ($Test in $TestUrls) {
    Write-Info "Testing: $($Test.Name)"
    
    # Create temporary user data directory
    $TempDir = [System.IO.Path]::GetTempPath() + [System.Guid]::NewGuid().ToString()
    New-Item -ItemType Directory -Path $TempDir -Force | Out-Null
    
    $ProcessArgs = @(
        "--user-data-dir=$TempDir"
    ) + $ChromeArgs + @(
        "--app=$($Test.Url)"
    )
    
    try {
        # Start Chrome
        $Process = Start-Process -FilePath $ChromePath -ArgumentList $ProcessArgs -PassThru
        
        Write-Info "Browser opened. Please check the results manually."
        Write-Info "Waiting 15 seconds for page to load..."
        
        Start-Sleep -Seconds 15
        
        # Check if we can extract any info
        # Note: This is limited without browser automation
        
        Write-Success "Test completed for $($Test.Name)"
        
        $TestResults += @{
            Site = $Test.Name
            Status = "Completed"
            ProcessId = $Process.Id
        }
        
        # Don't close browser - let user review
        Write-Info "Browser window left open for review. Close manually when done."
        
    } catch {
        Write-Error "Failed to test $($Test.Name): $_"
        $TestResults += @{
            Site = $Test.Name
            Status = "Failed"
            Error = $_.Exception.Message
        }
    }
    
    Write-Host ""
}

# Summary
Write-Host ""
Write-Host "========================================" -ForegroundColor Blue
Write-Host "  Test Summary" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""
Write-Info "Real IP: $RealIP"
Write-Info "Proxy: $(if ($ProxyUrl) { $ProxyUrl } else { 'None (Direct)' })"
Write-Host ""

foreach ($Result in $TestResults) {
    $StatusColor = if ($Result.Status -eq "Completed") { "Green" } else { "Red" }
    Write-Host "$($Result.Site): " -NoNewline
    Write-Host $Result.Status -ForegroundColor $StatusColor
}

Write-Host ""
Write-Host "IMPORTANT NOTES:" -ForegroundColor Yellow
Write-Host "  - Review each browser window for leak indicators"
Write-Host "  - Look for your real IP in WebRTC sections"
Write-Host "  - Check that only proxy IP is shown"
Write-Host "  - Close browser windows when done reviewing"
Write-Host ""

# Cleanup temp directories
Get-ChildItem -Path $env:TEMP -Directory | Where-Object { 
    $_.Name -match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' 
} | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

Write-Info "Cleanup completed"
Write-Host ""
