# Threads Automation Bot - Firewall Setup Instructions
# This script provides instructions for manual firewall configuration

Write-Host ""
Write-Host "========================================" -ForegroundColor Blue
Write-Host "  Firewall Setup Instructions" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""

Write-Host "This script will help you configure Windows Firewall for Threads Bot." -ForegroundColor Cyan
Write-Host ""

# Check if running as admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Warning "This script should be run as Administrator for best results."
    Write-Host "Right-click PowerShell and select 'Run as Administrator'" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host "STEP 1: Allow Python through firewall" -ForegroundColor Green
Write-Host "--------------------------------------"
Write-Host ""
Write-Host "Option A - Automatic (if running as admin):"
Write-Host ""

if ($isAdmin) {
    $pythonPath = (Get-Command python -ErrorAction SilentlyContinue).Source
    if (-not $pythonPath) {
        $pythonPath = Read-Host "Enter full path to python.exe (e.g., C:\Python311\python.exe)"
    }
    
    if (Test-Path $pythonPath) {
        try {
            New-NetFirewallRule -DisplayName "Threads Bot - Python" `
                -Direction Outbound `
                -Program $pythonPath `
                -Action Allow `
                -Profile Any `
                -ErrorAction Stop
            
            Write-Host "SUCCESS: Python rule created!" -ForegroundColor Green
        } catch {
            Write-Error "Failed to create rule: $_"
        }
    } else {
        Write-Error "Python not found at: $pythonPath"
    }
} else {
    Write-Host "  Run these commands as Administrator:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host '  $pythonPath = (Get-Command python).Source' -ForegroundColor Cyan
    Write-Host '  New-NetFirewallRule -DisplayName "Threads Bot - Python" -Direction Outbound -Program $pythonPath -Action Allow' -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Option B - Manual through GUI:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. Open Windows Defender Firewall" -ForegroundColor White
Write-Host "  2. Click 'Advanced settings'" -ForegroundColor White
Write-Host "  3. Click 'Outbound Rules'" -ForegroundColor White
Write-Host "  4. Click 'New Rule...'" -ForegroundColor White
Write-Host "  5. Select 'Program' → Browse to python.exe" -ForegroundColor White
Write-Host "  6. Select 'Allow the connection'" -ForegroundColor White
Write-Host "  7. Apply to all profiles" -ForegroundColor White
Write-Host "  8. Name it 'Threads Bot - Python'" -ForegroundColor White

Write-Host ""
Write-Host "STEP 2: Allow Chrome through firewall" -ForegroundColor Green
Write-Host "--------------------------------------"
Write-Host ""

$chromePaths = @(
    "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "${env:LocalAppData}\Google\Chrome\Application\chrome.exe"
)

$chromePath = $null
foreach ($path in $chromePaths) {
    if (Test-Path $path) {
        $chromePath = $path
        break
    }
}

if ($isAdmin -and $chromePath) {
    try {
        New-NetFirewallRule -DisplayName "Threads Bot - Chrome" `
            -Direction Outbound `
            -Program $chromePath `
            -Action Allow `
            -Profile Any `
            -ErrorAction Stop
        
        Write-Host "SUCCESS: Chrome rule created!" -ForegroundColor Green
    } catch {
        Write-Error "Failed to create Chrome rule: $_"
    }
} else {
    Write-Host "  Manual steps:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  1. In Windows Firewall, create new Outbound Rule" -ForegroundColor White
    Write-Host "  2. Select 'Program' → Browse to chrome.exe" -ForegroundColor White
    Write-Host "     (usually in C:\Program Files\Google\Chrome\Application\)" -ForegroundColor White
    Write-Host "  3. Select 'Allow the connection'" -ForegroundColor White
    Write-Host "  4. Name it 'Threads Bot - Chrome'" -ForegroundColor White
}

Write-Host ""
Write-Host "STEP 3: Verify rules" -ForegroundColor Green
Write-Host "--------------------------------------"
Write-Host ""

if ($isAdmin) {
    Write-Host "Current firewall rules for Threads Bot:" -ForegroundColor Cyan
    Get-NetFirewallRule | Where-Object { $_.DisplayName -like "*Threads*" } | 
        Select-Object DisplayName, Direction, Action, Enabled |
        Format-Table -AutoSize
} else {
    Write-Host "  Run this command to verify:" -ForegroundColor Yellow
    Write-Host '  Get-NetFirewallRule | Where-Object { $_.DisplayName -like "*Threads*" }' -ForegroundColor Cyan
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Blue
Write-Host "  Additional Security Recommendations" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""

Write-Host "1. Consider using a dedicated Windows user account for the bot"
Write-Host "2. Keep Windows Defender enabled for real-time protection"
Write-Host "3. Regularly update Python packages: pip list --outdated"
Write-Host "4. Monitor network connections while bot is running"
Write-Host ""

Write-Host "To remove rules later, run:" -ForegroundColor Yellow
Write-Host '  Remove-NetFirewallRule -DisplayName "Threads Bot - Python"' -ForegroundColor Cyan
Write-Host '  Remove-NetFirewallRule -DisplayName "Threads Bot - Chrome"' -ForegroundColor Cyan
Write-Host ""
