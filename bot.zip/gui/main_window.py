"""
Main Window Module
Primary GUI interface for Threads Automation Bot.
"""

import sys
import asyncio
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QTableWidget, QTableWidgetItem, QPushButton,
    QLabel, QLineEdit, QTextEdit, QComboBox, QSpinBox,
    QGroupBox, QFormLayout, QMessageBox, QFileDialog,
    QHeaderView, QMenu, QSystemTrayIcon, QStyle,
    QProgressBar, QCheckBox, QDialog, QDialogButtonBox,
    QListWidget, QListWidgetItem, QSplitter, QFrame,
    QScrollArea, QGridLayout, QTimeEdit, QInputDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QTime, QSettings
from PyQt6.QtGui import QAction, QIcon, QFont, QColor
from loguru import logger

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core import (
    get_account_manager,
    get_openrouter_client,
    get_proxy_checker,
    ProxyConfig,
    Account,
)


# ------------------------------------------------------------
#  Функция инициализации менеджера аккаунтов
# ------------------------------------------------------------
def initialize_account_manager(parent=None) -> bool:
    """
    Запрашивает мастер-пароль и инициализирует AccountManager.
    Возвращает True при успехе, иначе False (пользователь отменил или пароль неверен).
    """
    account_manager = get_account_manager()
    accounts_file = account_manager.accounts_file

    # Если файла с аккаунтами нет — предложить запустить мастер
    if not accounts_file.exists():
        reply = QMessageBox.question(
            parent,
            "First Launch",
            "No accounts found. Would you like to run the setup wizard?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            from gui.wizard import run_wizard
            # Запускаем мастер (он сам инициализирует менеджер и создаст файл)
            result = run_wizard()
            # Если мастер завершён успешно (код 1 == Accepted), считаем инициализацию успешной
            return result == 1
        return False

    # Файл есть — запрашиваем пароль
    password, ok = QInputDialog.getText(
        parent,
        "Master Password",
        "Enter master password to decrypt accounts:",
        QLineEdit.EchoMode.Password
    )
    if not ok or not password:
        return False

    # Пытаемся инициализировать
    if account_manager.initialize(password):
        return True
    else:
        QMessageBox.critical(
            parent,
            "Error",
            "Wrong password or corrupted data. Cannot initialize account manager."
        )
        return False
# ------------------------------------------------------------


class ProxyCheckThread(QThread):
    """Thread for checking proxy in background."""
    finished = pyqtSignal(dict)
    
    def __init__(self, proxy_config):
        super().__init__()
        self.proxy_config = proxy_config
    
    def run(self):
        try:
            import asyncio
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            checker = get_proxy_checker()
            result = loop.run_until_complete(checker.test_proxy(self.proxy_config))
            self.finished.emit(result.to_dict())
        except Exception as e:
            self.finished.emit({
                "success": False,
                "error_message": str(e)
            })


class AccountTable(QTableWidget):
    """Table widget for displaying accounts with proxy status."""
    
    account_edit_requested = pyqtSignal(int)
    account_test_requested = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setColumnCount(7)
        self.setHorizontalHeaderLabels([
            "ID", "Username", "Proxy", "Proxy Status", "Status", "Last Used", "Actions"
        ])
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
        
        self.accounts: List[Account] = []
        self.proxy_status: Dict[int, dict] = {}
    
    def update_accounts(self, accounts: List[Account], proxy_status: Dict[int, dict] = None):
        """Update table with account data."""
        self.accounts = accounts
        if proxy_status:
            self.proxy_status = proxy_status
        
        self.setRowCount(len(accounts))
        
        for row, account in enumerate(accounts):
            self.setItem(row, 0, QTableWidgetItem(str(account.id)))
            self.setItem(row, 1, QTableWidgetItem(account.username))
            
            proxy_text = "None"
            if account.proxy:
                proxy_text = f"{account.proxy.protocol}://{account.proxy.host}:{account.proxy.port}"
            self.setItem(row, 2, QTableWidgetItem(proxy_text))
            
            # Proxy status
            status_item = QTableWidgetItem()
            if account.id in self.proxy_status:
                status = self.proxy_status[account.id]
                if status.get("success"):
                    status_item.setText("✅ " + (status.get("country") or "OK"))
                    status_item.setForeground(QColor("green"))
                else:
                    status_item.setText("❌ Error")
                    status_item.setForeground(QColor("red"))
            else:
                status_item.setText("⏳ Unknown")
            self.setItem(row, 3, status_item)
            
            # Account status
            status = "Active" if account.is_active else "Inactive"
            status_item = QTableWidgetItem(status)
            status_item.setForeground(
                QColor("green") if account.is_active else QColor("red")
            )
            self.setItem(row, 4, status_item)
            
            last_used = account.last_used or "Never"
            self.setItem(row, 5, QTableWidgetItem(last_used))
            
            # Actions buttons
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(2, 2, 2, 2)
            
            edit_btn = QPushButton("Edit")
            edit_btn.setMaximumWidth(50)
            edit_btn.clicked.connect(lambda checked, a=account.id: self.account_edit_requested.emit(a))
            actions_layout.addWidget(edit_btn)
            
            test_btn = QPushButton("Test")
            test_btn.setMaximumWidth(50)
            test_btn.clicked.connect(lambda checked, a=account.id: self.account_test_requested.emit(a))
            actions_layout.addWidget(test_btn)
            
            self.setCellWidget(row, 6, actions_widget)
    
    def show_context_menu(self, position):
        """Show context menu for account row."""
        row = self.rowAt(position.y())
        if row < 0 or row >= len(self.accounts):
            return
        
        account = self.accounts[row]
        
        menu = QMenu(self)
        
        edit_action = QAction("Edit", self)
        edit_action.triggered.connect(lambda: self.account_edit_requested.emit(account.id))
        menu.addAction(edit_action)
        
        toggle_action = QAction(
            "Deactivate" if account.is_active else "Activate", self
        )
        toggle_action.triggered.connect(lambda: self.toggle_account(account))
        menu.addAction(toggle_action)
        
        menu.addSeparator()
        
        test_action = QAction("Test Browser", self)
        test_action.triggered.connect(lambda: self.account_test_requested.emit(account.id))
        menu.addAction(test_action)
        
        check_proxy_action = QAction("Check Proxy", self)
        check_proxy_action.triggered.connect(lambda: self.check_proxy(account))
        menu.addAction(check_proxy_action)
        
        menu.addSeparator()
        
        delete_action = QAction("Delete", self)
        delete_action.triggered.connect(lambda: self.delete_account(account))
        menu.addAction(delete_action)
        
        menu.exec(self.mapToGlobal(position))
    
    def toggle_account(self, account: Account):
        """Toggle account active status."""
        account_manager = get_account_manager()
        account_manager.update_account(
            account.id,
            is_active=not account.is_active
        )
        self.refresh()
    
    def check_proxy(self, account: Account):
        """Check proxy for account."""
        if not account.proxy:
            QMessageBox.information(self, "Info", "No proxy configured for this account")
            return
        
        self.proxy_status[account.id] = {"success": False, "checking": True}
        self.refresh()
        
        self.check_thread = ProxyCheckThread(account.proxy)
        self.check_thread.finished.connect(lambda result: self._on_proxy_check_finished(account.id, result))
        self.check_thread.start()
    
    def _on_proxy_check_finished(self, account_id: int, result: dict):
        """Handle proxy check completion."""
        self.proxy_status[account_id] = result
        self.refresh()
        
        if result.get("success"):
            msg = f"Proxy OK!\nIP: {result.get('external_ip')}\nLocation: {result.get('city')}, {result.get('country')}"
            QMessageBox.information(self, "Proxy Check", msg)
        else:
            QMessageBox.warning(self, "Proxy Check Failed", result.get('error_message', 'Unknown error'))
    
    def delete_account(self, account: Account):
        """Delete account after confirmation."""
        reply = QMessageBox.question(
            self,
            "Confirm Delete",
            f"Are you sure you want to delete account '{account.username}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            account_manager = get_account_manager()
            account_manager.delete_account(account.id)
            self.refresh()
    
    def refresh(self):
        """Refresh account list."""
        account_manager = get_account_manager()
        self.update_accounts(account_manager.get_all_accounts(), self.proxy_status)


class AddAccountDialog(QDialog):
    """Dialog for adding/editing account."""
    
    def __init__(self, account: Optional[Account] = None, parent=None):
        super().__init__(parent)
        self.account = account
        self.setWindowTitle("Edit Account" if account else "Add Account")
        self.setMinimumWidth(450)
        self.setup_ui()
        
        if account:
            self.load_account_data()
    
    def setup_ui(self):
        layout = QFormLayout(self)
        
        self.username_input = QLineEdit()
        layout.addRow("Username:", self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addRow("Password:", self.password_input)
        
        # Proxy section
        proxy_group = QGroupBox("Proxy Settings (Optional)")
        proxy_layout = QFormLayout()
        
        self.proxy_host = QLineEdit()
        self.proxy_host.setPlaceholderText("proxy.example.com")
        proxy_layout.addRow("Host:", self.proxy_host)
        
        self.proxy_port = QSpinBox()
        self.proxy_port.setRange(1, 65535)
        self.proxy_port.setValue(8080)
        proxy_layout.addRow("Port:", self.proxy_port)
        
        self.proxy_user = QLineEdit()
        proxy_layout.addRow("Username:", self.proxy_user)
        
        self.proxy_pass = QLineEdit()
        self.proxy_pass.setEchoMode(QLineEdit.EchoMode.Password)
        proxy_layout.addRow("Password:", self.proxy_pass)
        
        self.proxy_type = QComboBox()
        self.proxy_type.addItems(["http", "https", "socks4", "socks5"])
        proxy_layout.addRow("Protocol:", self.proxy_type)
        
        # Proxy check button
        self.check_proxy_btn = QPushButton("Check Proxy")
        self.check_proxy_btn.clicked.connect(self.check_proxy)
        proxy_layout.addRow(self.check_proxy_btn)
        
        self.proxy_status_label = QLabel("Status: Not checked")
        proxy_layout.addRow(self.proxy_status_label)
        
        proxy_group.setLayout(proxy_layout)
        layout.addRow(proxy_group)
        
        # Notes
        self.notes_input = QTextEdit()
        self.notes_input.setMaximumHeight(60)
        self.notes_input.setPlaceholderText("Persona context for AI generation...")
        layout.addRow("Notes:", self.notes_input)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)
    
    def load_account_data(self):
        """Load existing account data."""
        self.username_input.setText(self.account.username)
        self.password_input.setText(self.account.password)
        self.notes_input.setPlainText(self.account.notes or "")
        
        if self.account.proxy:
            self.proxy_host.setText(self.account.proxy.host or "")
            port = self.account.proxy.port if self.account.proxy.port is not None else 8080
            self.proxy_port.setValue(port)
            self.proxy_user.setText(self.account.proxy.username or "")
            self.proxy_pass.setText(self.account.proxy.password or "")
            self.proxy_type.setCurrentText(self.account.proxy.protocol or "http")
    
    def check_proxy(self):
        """Check proxy configuration."""
        if not self.proxy_host.text().strip():
            QMessageBox.warning(self, "Error", "Please enter proxy host")
            return
        
        proxy = ProxyConfig(
            host=self.proxy_host.text().strip(),
            port=self.proxy_port.value(),
            username=self.proxy_user.text().strip() or None,
            password=self.proxy_pass.text().strip() or None,
            protocol=self.proxy_type.currentText()
        )
        
        self.proxy_status_label.setText("Status: Checking...")
        self.check_proxy_btn.setEnabled(False)
        
        self.check_thread = ProxyCheckThread(proxy)
        self.check_thread.finished.connect(self._on_proxy_check_finished)
        self.check_thread.start()
    
    def _on_proxy_check_finished(self, result: dict):
        """Handle proxy check result."""
        self.check_proxy_btn.setEnabled(True)
        
        if result.get("success"):
            status_text = f"✅ OK - {result.get('city', 'Unknown')}, {result.get('country', 'Unknown')} ({result.get('external_ip', 'N/A')})"
            self.proxy_status_label.setStyleSheet("color: green;")
        else:
            status_text = f"❌ Failed - {result.get('error_message', 'Unknown error')}"
            self.proxy_status_label.setStyleSheet("color: red;")
        
        self.proxy_status_label.setText(f"Status: {status_text}")
    
    def save(self):
        """Save account."""
        from core.account_manager import Account, ProxyConfig
        
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()
        
        if not username or not password:
            QMessageBox.warning(self, "Error", "Username and password are required")
            return
        
        proxy = None
        if self.proxy_host.text().strip():
            proxy = ProxyConfig(
                host=self.proxy_host.text().strip(),
                port=self.proxy_port.value(),
                username=self.proxy_user.text().strip() or None,
                password=self.proxy_pass.text().strip() or None,
                protocol=self.proxy_type.currentText()
            )
        
        notes = self.notes_input.toPlainText().strip()
        
        account_manager = get_account_manager()
        
        if self.account:
            account_manager.update_account(
                self.account.id,
                username=username,
                password=password,
                proxy=proxy,
                notes=notes
            )
        else:
            account = Account(
                id=0,
                username=username,
                password=password,
                proxy=proxy,
                notes=notes,
                is_active=True
            )
            account_manager.add_account(account)
        
        self.accept()


class AccountsTab(QWidget):
    """Accounts management tab with proxy checking."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        self.add_btn = QPushButton("➕ Add Account")
        self.add_btn.clicked.connect(self.add_account)
        toolbar.addWidget(self.add_btn)
        
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        toolbar.addWidget(self.refresh_btn)
        
        self.check_all_btn = QPushButton("🔍 Check All Proxies")
        self.check_all_btn.clicked.connect(self.check_all_proxies)
        toolbar.addWidget(self.check_all_btn)
        
        toolbar.addStretch()
        
        layout.addLayout(toolbar)
        
        # Account table
        self.table = AccountTable()
        self.table.account_edit_requested.connect(self.edit_account)
        self.table.account_test_requested.connect(self.test_account)
        layout.addWidget(self.table)
        
        # Initial load
        self.refresh()
    
    def add_account(self):
        dialog = AddAccountDialog(parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh()
    
    def edit_account(self, account_id: int):
        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        if account:
            dialog = AddAccountDialog(account=account, parent=self)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                self.refresh()
    
    def test_account(self, account_id: int):
        QMessageBox.information(self, "Test", f"Browser test for account {account_id} would start here")
    
    def check_all_proxies(self):
        account_manager = get_account_manager()
        accounts = account_manager.get_all_accounts()
        for account in accounts:
            if account.proxy:
                self.table.check_proxy(account)
    
    def refresh(self):
        self.table.refresh()


# =============================================================================
#  ИСПРАВЛЕННЫЙ КЛАСС PostingTab (реальная генерация и публикация)
# =============================================================================
class PostingTab(QWidget):
    """Content posting tab with preview."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.generate_thread = None
        self.post_thread = None
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left panel - Settings
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)

        form = QFormLayout()

        self.account_combo = QComboBox()
        self.load_accounts()
        form.addRow("Account:", self.account_combo)

        self.topic_input = QLineEdit()
        self.topic_input.setPlaceholderText("Enter post topic...")
        form.addRow("Topic:", self.topic_input)

        self.tone_combo = QComboBox()
        self.tone_combo.addItems(["casual", "professional", "funny", "inspirational", "educational"])
        form.addRow("Tone:", self.tone_combo)

        left_layout.addLayout(form)

        # Action buttons
        buttons = QHBoxLayout()

        self.generate_btn = QPushButton("✨ Generate Content")
        self.generate_btn.clicked.connect(self.generate_content)
        buttons.addWidget(self.generate_btn)

        self.post_btn = QPushButton("📤 Post to Threads")
        self.post_btn.clicked.connect(self.post_content)
        self.post_btn.setEnabled(False)
        buttons.addWidget(self.post_btn)

        left_layout.addLayout(buttons)

        # Schedule settings
        schedule_group = QGroupBox("Schedule Settings")
        schedule_layout = QFormLayout()

        self.schedule_enabled = QCheckBox("Enable scheduled posting")
        schedule_layout.addRow(self.schedule_enabled)

        self.post_times = QLineEdit()
        self.post_times.setText("10:00, 15:00, 20:00")
        self.post_times.setPlaceholderText("Comma-separated times (e.g., 10:00, 15:00)")
        schedule_layout.addRow("Post times:", self.post_times)

        schedule_group.setLayout(schedule_layout)
        left_layout.addWidget(schedule_group)

        left_layout.addStretch()
        splitter.addWidget(left_panel)

        # Right panel - Preview
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        right_layout.addWidget(QLabel("Generated Content Preview:"))

        self.content_preview = QTextEdit()
        self.content_preview.setReadOnly(False)
        self.content_preview.setPlaceholderText("Click 'Generate Content' to create a post...")
        self.content_preview.setMinimumHeight(200)
        right_layout.addWidget(self.content_preview)

        self.char_count = QLabel("0 / 500 characters")
        right_layout.addWidget(self.char_count)

        splitter.addWidget(right_panel)
        splitter.setSizes([300, 400])

        layout.addWidget(splitter)

    def load_accounts(self):
        account_manager = get_account_manager()
        accounts = account_manager.get_active_accounts()
        self.account_combo.clear()
        for account in accounts:
            self.account_combo.addItem(
                f"{account.username} (ID: {account.id})",
                account.id
            )

    def generate_content(self):
        topic = self.topic_input.text().strip()
        if not topic:
            QMessageBox.warning(self, "Error", "Please enter a topic")
            return

        settings = QSettings("ThreadsBot", "Settings")
        api_key = settings.value("openrouter_key", "")
        if not api_key:
            QMessageBox.warning(
                self,
                "API Key Missing",
                "OpenRouter API key not configured. Please add it in Settings tab."
            )
            return

        client = get_openrouter_client(api_key)
        if not client:
            QMessageBox.critical(self, "Error", "Failed to initialize OpenRouter client")
            return

        self.generate_btn.setEnabled(False)
        self.generate_btn.setText("⏳ Generating...")

        class GenerateThread(QThread):
            finished = pyqtSignal(str)
            error = pyqtSignal(str)

            def __init__(self, client, topic, tone):
                super().__init__()
                self.client = client
                self.topic = topic
                self.tone = tone

            def run(self):
                try:
                    import asyncio
                    logger.debug("GenerateThread: starting generation")
                    try:
                        loop = asyncio.get_event_loop()
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                    result = loop.run_until_complete(
                        self.client.generate_post(self.topic, self.tone)
                    )
                    logger.debug(f"GenerateThread: result = {result}")
                    if result is not None:
                        self.finished.emit(result)
                    else:
                        self.error.emit("Failed to generate content (empty result)")
                except Exception as e:
                    logger.exception("GenerateThread exception")
                    self.error.emit(str(e))

        self.generate_thread = GenerateThread(
            client,
            topic,
            self.tone_combo.currentText()
        )
        self.generate_thread.finished.connect(self._on_generation_finished)
        self.generate_thread.error.connect(self._on_generation_error)
        self.generate_thread.start()
        logger.debug("GenerateThread started")

    def _on_generation_finished(self, content):
        """Handle successful generation."""
        logger.debug(f"_on_generation_finished called with content: {content}")
        if content is None:
            content = ""
        elif not isinstance(content, str):
            content = str(content)
        self.content_preview.setText(content)
        self.post_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)
        self.generate_btn.setText("✨ Generate Content")
        self.update_char_count()
        logger.debug("Content set to preview")

    def _on_generation_error(self, error_message):
        """Handle generation error."""
        logger.error(f"Generation error: {error_message}")
        if error_message is None:
            error_message = "Unknown error"
        QMessageBox.critical(self, "Generation Failed", f"Error: {error_message}")
        self.generate_btn.setEnabled(True)
        self.generate_btn.setText("✨ Generate Content")

    def post_content(self):
        content = self.content_preview.toPlainText().strip()
        if not content:
            QMessageBox.warning(self, "Error", "No content to post")
            return

        account_id = self.account_combo.currentData()
        account_name = self.account_combo.currentText()

        account_manager = get_account_manager()
        account = account_manager.get_account(account_id)
        if not account:
            QMessageBox.critical(self, "Error", "Account not found")
            return

        reply = QMessageBox.question(
            self,
            "Confirm Post",
            f"Post this content to {account_name}?\n\n{content[:100]}...",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        self.post_btn.setEnabled(False)
        self.post_btn.setText("⏳ Posting...")
        self.generate_btn.setEnabled(False)

        class PostThread(QThread):
            finished = pyqtSignal(bool, str, str)

            def __init__(self, account, content):
                super().__init__()
                self.account = account
                self.content = content

            def run(self):
                try:
                    import asyncio
                    from core.poster import Poster
                    from core.threads_auth import ThreadsSession
                    from core.engines.nodriver_engine import NodriverEngine, BrowserProfile

                    try:
                        loop = asyncio.get_event_loop()
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)

                    async def _post():
                        profile = BrowserProfile(
                            proxy=self.account.proxy.to_url() if self.account.proxy else None,
                            language="ru-RU"
                        )
                        engine = NodriverEngine(profile)
                        await engine.start()

                        session = ThreadsSession(self.account, engine)
                        settings = QSettings("ThreadsBot", "Settings")
                        api_key = settings.value("openrouter_key", "")
                        ai_client = get_openrouter_client(api_key) if api_key else None

                        poster = Poster(
                            account=self.account,
                            engine=engine,
                            ai_client=ai_client,
                            auth_session=session
                        )

                        result = await poster.create_post(content=self.content)
                        await engine.stop()
                        return result

                    result = loop.run_until_complete(_post())

                    if result and result.success:
                        self.finished.emit(True, "Post published successfully!", result.post_url or "")
                    else:
                        err_msg = result.error_message if result else "Unknown error"
                        self.finished.emit(False, f"Failed: {err_msg}", "")

                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    self.finished.emit(False, f"Error: {str(e)}", "")

        self.post_thread = PostThread(account, content)
        self.post_thread.finished.connect(self._on_post_finished)
        self.post_thread.start()

    def _on_post_finished(self, success, message, url):
        self.post_btn.setEnabled(True)
        self.post_btn.setText("📤 Post to Threads")
        self.generate_btn.setEnabled(True)

        if success:
            QMessageBox.information(self, "Success", f"{message}\nURL: {url}")
            self.content_preview.clear()
            self.post_btn.setEnabled(False)
        else:
            QMessageBox.critical(self, "Error", f"Posting failed: {message}")

    def update_char_count(self):
        text = self.content_preview.toPlainText()
        if text is None:
            text = ""
        count = len(text)
        self.char_count.setText(f"{count} / 500 characters")
# =============================================================================


class CommentingTab(QWidget):
    """Commenting settings and control tab."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        sources_group = QGroupBox("Search Sources")
        sources_layout = QFormLayout()
        
        self.keywords_input = QLineEdit()
        self.keywords_input.setPlaceholderText("Comma-separated keywords")
        sources_layout.addRow("Keywords:", self.keywords_input)
        
        self.hashtags_input = QLineEdit()
        self.hashtags_input.setPlaceholderText("Comma-separated hashtags (without #)")
        sources_layout.addRow("Hashtags:", self.hashtags_input)
        
        sources_group.setLayout(sources_layout)
        layout.addWidget(sources_group)
        
        filters_group = QGroupBox("Filters")
        filters_layout = QFormLayout()
        
        self.min_likes = QSpinBox()
        self.min_likes.setRange(0, 10000)
        self.min_likes.setValue(10)
        filters_layout.addRow("Min likes:", self.min_likes)
        
        self.max_age = QSpinBox()
        self.max_age.setRange(1, 168)
        self.max_age.setValue(24)
        self.max_age.setSuffix(" hours")
        filters_layout.addRow("Max post age:", self.max_age)
        
        self.stop_words = QLineEdit()
        self.stop_words.setPlaceholderText("spam, scam, etc.")
        filters_layout.addRow("Stop words:", self.stop_words)
        
        filters_group.setLayout(filters_layout)
        layout.addWidget(filters_group)
        
        limits_group = QGroupBox("Limits")
        limits_layout = QFormLayout()
        
        self.max_comments = QSpinBox()
        self.max_comments.setRange(1, 50)
        self.max_comments.setValue(5)
        limits_layout.addRow("Max per cycle:", self.max_comments)
        
        self.comment_style = QComboBox()
        self.comment_style.addItems(["engaging", "supportive", "questioning", "humorous"])
        limits_layout.addRow("Comment style:", self.comment_style)
        
        limits_group.setLayout(limits_layout)
        layout.addWidget(limits_group)
        
        self.run_btn = QPushButton("▶️ Run Comment Cycle")
        self.run_btn.clicked.connect(self.run_cycle)
        layout.addWidget(self.run_btn)
        
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)
        
        layout.addStretch()
    
    def run_cycle(self):
        QMessageBox.information(self, "Comment Cycle", "Commenting cycle would start here")


class StatsTab(QWidget):
    """Statistics and monitoring tab."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_stats)
        self.update_timer.start(5000)
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        ai_group = QGroupBox("AI Usage Statistics")
        ai_layout = QFormLayout()
        
        self.ai_requests = QLabel("0")
        ai_layout.addRow("Total requests:", self.ai_requests)
        
        self.ai_cache_hits = QLabel("0")
        ai_layout.addRow("Cache hits:", self.ai_cache_hits)
        
        self.ai_fallbacks = QLabel("0")
        ai_layout.addRow("Model fallbacks:", self.ai_fallbacks)
        
        ai_group.setLayout(ai_layout)
        layout.addWidget(ai_group)
        
        accounts_group = QGroupBox("Account Activity")
        accounts_layout = QVBoxLayout()
        
        self.stats_table = QTableWidget()
        self.stats_table.setColumnCount(5)
        self.stats_table.setHorizontalHeaderLabels([
            "Account", "Posts Today", "Comments Today", "Last Activity", "Status"
        ])
        accounts_layout.addWidget(self.stats_table)
        
        accounts_group.setLayout(accounts_layout)
        layout.addWidget(accounts_group)
        
        layout.addStretch()
    
    def update_stats(self):
        # TODO: Get real stats
        pass


class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Threads Automation Bot v2.0")
        self.setMinimumSize(1200, 800)
        self.setup_ui()
        self.setup_tray()
        self.load_settings()
    
    def setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        
        self.tabs = QTabWidget()
        self.tabs.addTab(AccountsTab(), "👤 Accounts")
        self.tabs.addTab(PostingTab(), "📝 Posting")
        self.tabs.addTab(CommentingTab(), "💬 Commenting")
        self.tabs.addTab(StatsTab(), "📊 Statistics")
        self.tabs.addTab(self.create_settings_tab(), "⚙️ Settings")
        
        layout.addWidget(self.tabs)
        self.statusBar().showMessage("Ready")
        
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        tools_menu = menubar.addMenu("Tools")
        check_ip_action = QAction("Check IP Leak", self)
        check_ip_action.triggered.connect(self.check_ip_leak)
        tools_menu.addAction(check_ip_action)
        
        test_ai_action = QAction("Test AI Key", self)
        test_ai_action.triggered.connect(self.test_ai_key)
        tools_menu.addAction(test_ai_action)
        
        help_menu = menubar.addMenu("Help")
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def create_settings_tab(self):
        widget = QWidget()
        layout = QFormLayout(widget)
        
        self.api_key_input = QLineEdit()
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_input.setPlaceholderText("sk-or-v1-...")
        layout.addRow("OpenRouter API Key:", self.api_key_input)
        
        test_key_btn = QPushButton("Test Key")
        test_key_btn.clicked.connect(self.test_ai_key)
        layout.addRow(test_key_btn)
        
        self.window_behavior = QComboBox()
        self.window_behavior.addItems(["Minimize after launch", "Arrange in grid", "Leave as is"])
        layout.addRow("Window Behavior:", self.window_behavior)
        
        self.restart_interval = QSpinBox()
        self.restart_interval.setRange(1, 24)
        self.restart_interval.setValue(4)
        self.restart_interval.setSuffix(" hours")
        layout.addRow("Browser Restart Interval:", self.restart_interval)
        
        save_btn = QPushButton("Save Settings")
        save_btn.clicked.connect(self.save_settings)
        layout.addRow(save_btn)
        
        return widget
    
    def setup_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon))
        tray_menu = QMenu()
        show_action = QAction("Show", self)
        show_action.triggered.connect(self.show)
        tray_menu.addAction(show_action)
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.quit)
        tray_menu.addAction(quit_action)
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.activated.connect(self.tray_activated)
    
    def tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show()
    
    def closeEvent(self, event):
        if self.tray_icon.isVisible():
            self.hide()
            self.tray_icon.showMessage(
                "Threads Bot",
                "Application minimized to tray",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )
            event.ignore()
        else:
            self.save_settings()
            event.accept()
    
    def check_ip_leak(self):
        import subprocess
        import os
        script_path = Path(__file__).parent.parent / "scripts" / "check_ip_leak.ps1"
        if script_path.exists():
            subprocess.Popen([
                "powershell.exe",
                "-ExecutionPolicy", "Bypass",
                "-File", str(script_path)
            ])
        else:
            QMessageBox.warning(self, "Error", "IP leak check script not found")
    
    def test_ai_key(self):
        api_key = self.api_key_input.text().strip()
        if not api_key:
            QMessageBox.warning(self, "Error", "Please enter an API key")
            return
        
        class TestThread(QThread):
            finished = pyqtSignal(dict)
            def __init__(self, api_key):
                super().__init__()
                self.api_key = api_key
            def run(self):
                try:
                    import asyncio
                    from core.openrouter_client import get_openrouter_client
                    client = get_openrouter_client(self.api_key)
                    try:
                        loop = asyncio.get_event_loop()
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                    result = loop.run_until_complete(client.test_api_key())
                    self.finished.emit(result)
                except Exception as e:
                    self.finished.emit({"success": False, "message": str(e)})
        
        self.test_thread = TestThread(api_key)
        self.test_thread.finished.connect(self._on_test_finished)
        self.test_thread.start()
        QMessageBox.information(self, "Testing", "Testing API key, please wait...")
    
    def _on_test_finished(self, result):
        if result.get("success"):
            QMessageBox.information(self, "Success", f"API key is valid!\n{result.get('message')}")
        else:
            QMessageBox.critical(self, "Error", f"Invalid API key: {result.get('message')}")
    
    def show_about(self):
        QMessageBox.about(
            self,
            "About Threads Automation Bot",
            """<h2>Threads Automation Bot v2.0</h2>
            <p>A powerful automation tool for Threads social network.</p>
            <p><b>Features:</b></p>
            <ul>
                <li>Multi-account management with proxy checking</li>
                <li>AI-powered content generation (OpenRouter)</li>
                <li>Human-like behavior simulation</li>
                <li>Advanced anti-detection</li>
                <li>Scheduled posting and commenting</li>
            </ul>
            <p>Use responsibly and in accordance with Threads' Terms of Service.</p>
            """
        )
    
    def load_settings(self):
        settings = QSettings("ThreadsBot", "Settings")
        self.api_key_input.setText(settings.value("openrouter_key", ""))
    
    def save_settings(self):
        settings = QSettings("ThreadsBot", "Settings")
        settings.setValue("openrouter_key", self.api_key_input.text())
        QMessageBox.information(self, "Success", "Settings saved")
    
    def quit(self):
        self.save_settings()
        self.tray_icon.hide()
        QApplication.quit()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Threads Automation Bot")
    app.setApplicationVersion("2.0.0")
    app.setOrganizationName("ThreadsBot")
    
    font = QFont("Segoe UI", 10)
    app.setFont(font)

    if not initialize_account_manager():
        return 1

    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())