"""
Setup Wizard Module
First-run configuration wizard for new users.
"""

import sys
from pathlib import Path
from typing import Optional

from PyQt6.QtWidgets import (
    QWizard, QWizardPage, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit,
    QFormLayout, QCheckBox, QComboBox, QSpinBox,
    QMessageBox, QProgressBar, QGroupBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent.parent))

from core import get_account_manager, get_openrouter_client


class WelcomePage(QWizardPage):
    """Welcome page of the wizard."""
    
    def __init__(self):
        super().__init__()
        self.setTitle("Welcome to Threads Automation Bot")
        self.setSubTitle("Let's get you set up in a few simple steps.")
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        welcome_text = """
        <h2>Welcome!</h2>
        <p>This wizard will help you set up Threads Automation Bot v2.0.</p>
        
        <p><b>What we'll do:</b></p>
        <ol>
            <li>Create a secure master password</li>
            <li>Configure your OpenRouter API key</li>
            <li>Add your first Threads account</li>
            <li>Test your setup</li>
        </ol>
        
        <p>Click <b>Next</b> to begin.</p>
        """
        
        label = QLabel(welcome_text)
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(label)
        
        layout.addStretch()


class MasterPasswordPage(QWizardPage):
    """Master password setup page."""
    
    def __init__(self):
        super().__init__()
        self.setTitle("Create Master Password")
        self.setSubTitle("This password encrypts all your account data.")
        self.setup_ui()
    
    def setup_ui(self):
        layout = QFormLayout(self)
        
        info = QLabel(
            "<p style='color: #d9534f;'><b>IMPORTANT:</b> If you forget this password, "
            "your data cannot be recovered!</p>"
        )
        info.setWordWrap(True)
        layout.addRow(info)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setPlaceholderText("Minimum 8 characters")
        layout.addRow("Master Password:", self.password_input)
        
        self.confirm_input = QLineEdit()
        self.confirm_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addRow("Confirm Password:", self.confirm_input)
        
        self.registerField("master_password*", self.password_input)
    
    def validatePage(self) -> bool:
        """Validate password input."""
        password = self.password_input.text()
        confirm = self.confirm_input.text()
        
        if len(password) < 8:
            QMessageBox.warning(
                self, "Invalid Password",
                "Password must be at least 8 characters long."
            )
            return False
        
        if password != confirm:
            QMessageBox.warning(
                self, "Password Mismatch",
                "Passwords do not match. Please try again."
            )
            return False
        
        return True


class OpenRouterPage(QWizardPage):
    """OpenRouter API configuration page."""
    
    def __init__(self):
        super().__init__()
        self.setTitle("Configure OpenRouter")
        self.setSubTitle("Set up AI content generation.")
        self.setup_ui()
    
    def setup_ui(self):
        layout = QFormLayout(self)
        
        info = QLabel(
            "<p>OpenRouter provides access to free AI models for content generation.</p>"
            "<p>Get your free API key at: "
            "<a href='https://openrouter.ai/keys'>openrouter.ai/keys</a></p>"
        )
        info.setWordWrap(True)
        info.setOpenExternalLinks(True)
        layout.addRow(info)
        
        self.api_key_input = QLineEdit()
        self.api_key_input.setPlaceholderText("sk-or-v1-...")
        layout.addRow("API Key:", self.api_key_input)
        
        # Skip option
        self.skip_checkbox = QCheckBox("Skip for now (you can add this later)")
        layout.addRow(self.skip_checkbox)
        
        self.registerField("openrouter_key", self.api_key_input)
    
    def validatePage(self) -> bool:
        """Validate API key."""
        if self.skip_checkbox.isChecked():
            return True
        
        api_key = self.api_key_input.text().strip()
        
        if not api_key:
            QMessageBox.warning(
                self, "API Key Required",
                "Please enter your OpenRouter API key or check 'Skip for now'."
            )
            return False
        
        if not api_key.startswith("sk-"):
            QMessageBox.warning(
                self, "Invalid API Key",
                "The API key doesn't look valid. It should start with 'sk-'."
            )
            return False
        
        return True


class AccountPage(QWizardPage):
    """First account setup page."""
    
    def __init__(self):
        super().__init__()
        self.setTitle("Add Your First Account")
        self.setSubTitle("Enter your Threads account credentials.")
        self.setup_ui()
    
    def setup_ui(self):
        layout = QFormLayout(self)
        
        info = QLabel(
            "<p>Enter your Threads login credentials.</p>"
            "<p>You can add more accounts later from the main window.</p>"
        )
        info.setWordWrap(True)
        layout.addRow(info)
        
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("your_username")
        layout.addRow("Username:", self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addRow("Password:", self.password_input)
        
        # Proxy section
        proxy_group = QGroupBox("Proxy Settings (Optional)")
        proxy_layout = QFormLayout()
        
        proxy_info = QLabel(
            "<p style='font-size: 11px;'>Using a proxy is highly recommended for "
            "account safety. Format: host:port</p>"
        )
        proxy_info.setWordWrap(True)
        proxy_layout.addRow(proxy_info)
        
        self.proxy_host = QLineEdit()
        self.proxy_host.setPlaceholderText("proxy.example.com")
        proxy_layout.addRow("Host:", self.proxy_host)
        
        self.proxy_port = QSpinBox()
        self.proxy_port.setRange(1, 65535)
        self.proxy_port.setValue(8080)
        proxy_layout.addRow("Port:", self.proxy_port)
        
        self.proxy_user = QLineEdit()
        proxy_layout.addRow("Username:", self.proxy_user)
        
        self.proxy_pass = QLineEdit()
        self.proxy_pass.setEchoMode(QLineEdit.EchoMode.Password)
        proxy_layout.addRow("Password:", self.proxy_pass)
        
        self.proxy_type = QComboBox()
        self.proxy_type.addItems(["HTTP", "HTTPS", "SOCKS4", "SOCKS5"])
        proxy_layout.addRow("Type:", self.proxy_type)
        
        proxy_group.setLayout(proxy_layout)
        layout.addRow(proxy_group)
        
        self.registerField("account_username*", self.username_input)
        self.registerField("account_password*", self.password_input)
    
    def validatePage(self) -> bool:
        """Validate account input."""
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()
        
        if not username:
            QMessageBox.warning(self, "Error", "Username is required.")
            return False
        
        if not password:
            QMessageBox.warning(self, "Error", "Password is required.")
            return False
        
        return True


class SummaryPage(QWizardPage):
    """Setup summary and completion page."""
    
    def __init__(self):
        super().__init__()
        self.setTitle("Setup Complete")
        self.setSubTitle("Your configuration has been saved.")
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        self.summary_label = QLabel("Saving your configuration...")
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)
        
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        layout.addWidget(self.progress)
        
        self.result_label = QLabel("")
        self.result_label.setWordWrap(True)
        layout.addWidget(self.result_label)
        
        layout.addStretch()
    
    def initializePage(self):
        """Called when page is shown - perform setup."""
        self.save_configuration()
    
    def save_configuration(self):
        """Save all configuration."""
        try:
            self.progress.setValue(10)
            
            # Get field values
            master_password = self.field("master_password")
            openrouter_key = self.field("openrouter_key")
            username = self.field("account_username")
            account_password = self.field("account_password")
            
            self.progress.setValue(30)
            
            # Initialize account manager
            account_manager = get_account_manager()
            if not account_manager.initialize(master_password):
                raise Exception("Failed to initialize account manager")
            
            self.progress.setValue(50)
            
            # Add account
            from core.account_manager import Account, ProxyConfig
            
            proxy = None
            proxy_host = self.wizard().page(3).proxy_host.text().strip()
            if proxy_host:
                proxy = ProxyConfig(
                    host=proxy_host,
                    port=self.wizard().page(3).proxy_port.value(),
                    username=self.wizard().page(3).proxy_user.text().strip() or None,
                    password=self.wizard().page(3).proxy_pass.text().strip() or None,
                    protocol=self.wizard().page(3).proxy_type.currentText().lower()
                )
            
            account = Account(
                id=0,
                username=username,
                password=account_password,
                proxy=proxy,
                is_active=True
            )
            
            self.progress.setValue(70)
            
            if not account_manager.add_account(account):
                raise Exception("Failed to add account")
            
            self.progress.setValue(90)
            
            # Initialize OpenRouter if key provided
            if openrouter_key:
                get_openrouter_client(openrouter_key)
            
            self.progress.setValue(100)
            
            # Show success message
            self.summary_label.setText("<h2>Setup Complete!</h2>")
            
            success_text = f"""
            <p><b>Configuration saved successfully!</b></p>
            
            <p><b>What's next:</b></p>
            <ul>
                <li>Click <b>Finish</b> to start the main application</li>
                <li>Add more accounts from the Accounts tab</li>
                <li>Configure posting settings</li>
                <li>Start automating!</li>
            </ul>
            
            <p><b>Important reminders:</b></p>
            <ul>
                <li>Use quality residential proxies for best results</li>
                <li>Start slowly with new accounts</li>
                <li>Monitor your accounts regularly</li>
            </ul>
            """
            
            self.result_label.setText(success_text)
            
        except Exception as e:
            logger.error(f"Setup failed: {e}")
            self.summary_label.setText("<h2 style='color: red;'>Setup Failed</h2>")
            self.result_label.setText(
                f"<p style='color: red;'>Error: {str(e)}</p>"
                "<p>Please try again or contact support.</p>"
            )


class SetupWizard(QWizard):
    """Setup wizard for first-run configuration."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Threads Automation Bot - Setup Wizard")
        self.setMinimumSize(600, 500)
        
        # Add pages
        self.addPage(WelcomePage())
        self.addPage(MasterPasswordPage())
        self.addPage(OpenRouterPage())
        self.addPage(AccountPage())
        self.addPage(SummaryPage())
        
        # Configure wizard
        self.setWizardStyle(QWizard.WizardStyle.ModernStyle)
        self.setOption(QWizard.WizardOption.HaveHelpButton, False)
        self.setOption(QWizard.WizardOption.HaveFinishButtonOnEarlyPages, False)
    
    def accept(self):
        """Handle wizard completion."""
        super().accept()


def run_wizard():
    """Run the setup wizard."""
    from PyQt6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    
    wizard = SetupWizard()
    wizard.show()
    
    return app.exec()


if __name__ == "__main__":
    sys.exit(run_wizard())
